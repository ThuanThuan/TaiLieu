/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Administrator
 */
public class TestLogiGear {

    public static void main(String[] args) {
        TestLogiGear a = new TestLogiGear();
//        a.reverse();
//        a.upperAt("   nGuYeN xUaN lAm");
//        a.convertToBinary();
//        System.out.println(a.binary(2));
//        a.testRun();
//        a.tamGiacDeu2();
//        a.tamGiacVuongCan1();
        a.tamGiacVuongCan2();
    }

    public void reverse() {
        int a = 4321;
        int b = 0;
        while (a != 0) {
            b = b * 10 + a % 10;
            a = a / 10;
        }
        System.out.println("b = " + b);
    }

    public void upperAt(String name) {
        name = name.trim().toLowerCase();
        String temp[] = name.split(" ");
        name = ""; // ? ^-^
        for (int i = 0; i < temp.length; i++) {
            name += String.valueOf(temp[i].charAt(0)).toUpperCase() + temp[i].substring(1);
            if (i < temp.length - 1) // ? ^-^
            {
                name += " ";
            }
        }
        System.out.println(name);
    }

    public void convertToBinary() {
        int a = 10;
        int b;
        String s = "";
        while (a != 0) {
            b = a % 2;
            s += b + "";
            a = a / 2;
        }
        StringBuffer sb = new StringBuffer();
        sb.append(s);
        sb.reverse();
        System.out.println("s = " + sb.toString());
    }
    String s = "";

    String binary(int n) {
        if (n % 2 != 0) {
            s = "0";
        } else {
            s = "1";
        }
        if (n < 2) {
            return s;
        }
        return binary(n / 2) + s;
    }

    void testRun() {
        int i;
        for (i = 100; i <= 100; --i) {
            System.out.println(i);
        }
        int x = (11 & 12) | (13 | 14);
        System.out.println(x);
    }

    void tamGiacDeu1() {
        int n, i, j;
        n = 5;   // khai bao so hang.
        System.out.println("Ve tam giac sao deu:\n\n");
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (j = 1; j <= i; j++) {
                System.out.print(j + " ");
            }
            System.out.print("\n");
        }
    }

    void tamGiacDeu2() {
        int n, i, j;
        n = 5;   // khai bao so hang.
        System.out.print("Ve tam giac sao deu:\n\n");
        for (i = 1; i <= n; i++) {
            System.out.print(i);
        }
        System.out.println("");
        for (i = 1; i <= n; i++) {
            for (j = 1; j < i; j++) {
                System.out.print(" ");
            }
            for (j = i; j <= n; j++) {
                System.out.print("*");
            }
            System.out.print("\n");
        }
    }

    void tamGiacVuongCan1() {
        int n, i, j;
        n = 5;
        System.out.print("Ve tam giac sao vuong can:\n\n");
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.print("\n");
        }
    }

    void tamGiacVuongCan2() {
        int n, i, j;
        n = 5;
        System.out.print("Ve tam giac sao vuong can:\n\n");
        for (i = 0; i < n; i++) {
            for (j = 0; j < i; j++) {
                System.out.print("  ");
            }
            for (j = i; j < n; j++) {
                System.out.print(" *");
            }
            System.out.print("\n");
        }
    }

}
