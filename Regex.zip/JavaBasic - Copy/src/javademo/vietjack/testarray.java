package javademo.vietjack;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class testarray {

    public static void main(String[] args) throws Exception {
        b28 bai = new b28();
        bai.write28();
        bai.read28();
    }
}

class b28 {

    DataOutputStream dos;
    DataInputStream dis;
    int[] i = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    public void write28() throws IOException {

        try {
            dos = new DataOutputStream(new FileOutputStream(
                    "D:\\2___Hoc Tap\\1__Programming Language\\Java\\NetBeansProjects1\\JavaBasic - Copy\\outfilename.txt"));
        } catch (IOException e) {
            e.getStackTrace();
        }
        try {
//            System.out.println("Writing Integer : " + i);
            for (int j = 0; j < 10; j++) {
                if (i[j] % 2 == 0) {
                    dos.writeInt(i[j]);
                }
            }
        } catch (Exception e) {
        }
        dos.close();
    }

    public void read28() throws IOException {
        try {
            dis = new DataInputStream(new FileInputStream(
                    "D:\\2___Hoc Tap\\1__Programming Language\\Java\\NetBeansProjects1\\JavaBasic - Copy\\outfilename.txt"));
        } catch (FileNotFoundException e) {
        }
        try {
            for (int j = 0; j < 10; j++) {
                i[j] = dis.readInt();
                System.out.println("Read Integer : " + i[j]);
            }
        } catch (IOException e) {
        }
        dis.close();
    }
}
