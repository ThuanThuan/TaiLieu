/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo.vietjack;

/**
 *
 * @author Administrator
 */
public class Java_Method_Continue {

    public static void main(String[] args) {
        StringBuffer searchstr = new StringBuffer(
                "hello how are you. ");
        int length = searchstr.length();
        int count = 0;
        for (int i = 0; i < length; i++) {
            if (searchstr.charAt(i) != 'h') {
                continue;
            }
            count++;
//            searchstr.setCharAt(i, 'h');
        }
        System.out.println("Found " + count
                + " h's in the string.");
        System.out.println(searchstr);
    }
}
