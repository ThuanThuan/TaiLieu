package javademo.vietjack;

public class Java_String_Split {

    public static void main(String args[]) {
        String str = "jan-feb-march-april";
        String[] temp;
        String delimeter = "-";
        temp = str.split(delimeter);
        for (int i = 0; i < temp.length; i++) {
            System.out.println(temp[i]);
        }
        System.out.println("------------------------");
        str = "jan.feb.march";
        delimeter = "\\.";
        temp = str.split(delimeter);
        for (int i = 0; i < temp.length; i++) {
            System.out.println(temp[i]);
            System.out.println(i);
            temp = str.split(delimeter, 2);
            for (int j = 0; j < temp.length; j++) {
                System.out.println(temp[j]);
                System.out.println("-");
            }
            System.out.println("---");
        }
    }
}
