/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo.vietjack;

/**
 *
 * @author Administrator
 */
public class Java_String_StringBuffer {

    public static void main(String[] args) {
        String string = "abcdef";
        String reverse = new StringBuffer(string).
                reverse().toString();
        System.out.println("\nString before reverse:" + string);
        System.out.println("String after reverse:    " + reverse);
    }
}
