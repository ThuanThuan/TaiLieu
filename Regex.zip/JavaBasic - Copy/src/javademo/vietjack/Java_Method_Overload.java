/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo.vietjack;

/**
 *
 * @author Administrator
 */
public class Java_Method_Overload {

    public static void main(String[] args) {
        MyClass t = new MyClass(1);
        t.info();
        t.info("overloaded method");
        new MyClass();
    }
}

class MyClass {

    int height;

    MyClass() {
        System.out.println("bricks");
        height = 0;
    }

    MyClass(int i) {
        System.out.println("Building new House that is "
                + i + " feet tall");
        height = i;
    }

    void info() {
        System.out.println("House is " + height
                + " feet tall");
    }

    void info(String s) {
        System.out.println(s + ": House is "
                + height + " feet tall");
    }
}
