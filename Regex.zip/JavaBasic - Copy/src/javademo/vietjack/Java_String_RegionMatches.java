/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javademo.vietjack;

/**
 *
 * @author Administrator
 */
public class Java_String_RegionMatches {

    public static void main(String[] args) {
        String first_str = "Welcome to Microsoft";
        String second_str = "I work with Microsoft";
        boolean match = first_str.regionMatches(11, second_str, 12, 9);
        System.out.println("first_str[11 -19] == " + "second_str[12 - 21]:-" + match);
    }
}
