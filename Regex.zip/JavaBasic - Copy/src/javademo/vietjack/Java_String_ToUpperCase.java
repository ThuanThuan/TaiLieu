package javademo.vietjack;

public class Java_String_ToUpperCase {

    public static void main(String[] args) {
        String str = "string abc touppercase ";
        String strUpper = str.toUpperCase();
        System.out.println("Original String: " + str);
        System.out.println("String changed to upper case: "
                + strUpper);
    }
}
