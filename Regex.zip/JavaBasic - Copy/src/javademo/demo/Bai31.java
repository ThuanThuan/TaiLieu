package javademo.demo;

import java.io.BufferedReader;
import java.io.FileWriter;

//Read & Write Using Binary Streams in Java
public class Bai31 {

}

class b31 {

    FileWriter fw;
    String str;
//	BufferReader br;

}
