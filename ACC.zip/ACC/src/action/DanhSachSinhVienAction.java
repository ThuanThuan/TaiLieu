package action;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Khoa;
import model.bean.SinhVien;
import model.bo.KhoaBO;
import model.bo.SinhVienBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachSinhVienForm;

/**
 * SinhVienAction.java
 *
 * Version 1.0
 *
 * Date: Jan 21, 2015
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * Jan 21, 2015        	DaiLV2          Create
 */

public class DanhSachSinhVienAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachSinhVienForm danhSachSinhVienForm = (DanhSachSinhVienForm) form;
		
		//lay danh sach cac khoa
		KhoaBO khoaBO = new KhoaBO();
		ArrayList<Khoa> listKhoa = khoaBO.getListKhoa();
		danhSachSinhVienForm.setListKhoa(listKhoa);
		
		//lay danh sach sinh vien
		ArrayList<SinhVien> listSinhVien;
		SinhVienBO sinhVienBO = new SinhVienBO();
		String searchText = danhSachSinhVienForm.getSearchText();
		String page = danhSachSinhVienForm.getPage() != null ? danhSachSinhVienForm.getPage() : "1";
		
		if(searchText==null || searchText.length()==0){
			listSinhVien = sinhVienBO.getListSinhVien(page);
		} else {
			searchText = searchText.trim();
			byte[] bt = searchText.getBytes(StandardCharsets.ISO_8859_1);
			searchText = new String(bt,StandardCharsets.UTF_8);
			listSinhVien = sinhVienBO.getListSinhVien(searchText,page);
		}
		danhSachSinhVienForm.setListSinhVien(listSinhVien);
		
		int recordsPerPage = 5;
		int noOfRecords = sinhVienBO.getNoOfRecords();
		int noOfPages = (int) Math.ceil((double)noOfRecords / recordsPerPage);
		
		danhSachSinhVienForm.setCurrentPage(Integer.parseInt(page));
		danhSachSinhVienForm.setNoOfPages(noOfPages);
		danhSachSinhVienForm.setSearchText(searchText);
		
		return mapping.findForward("dsSinhVien");
	}
}

