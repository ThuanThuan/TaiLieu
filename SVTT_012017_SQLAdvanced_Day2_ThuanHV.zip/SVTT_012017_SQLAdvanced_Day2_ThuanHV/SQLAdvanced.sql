﻿Create Database QLBHDT
use QLBHDT

Create table KHACHHANG(
MaKH nvarchar(10) primary key,
TenKH nvarchar(50),
Email nvarchar(50),
SoDT int,
DiaChi nvarchar(50)
)

Create table DMSANPHAM(
MaDM nvarchar(10) primary key,
TenDanhMuc nvarchar(50),
MoTa nvarchar(50)
)

Create table SANPHAM(
MaSP nvarchar(10) primary key,
MaDM nvarchar(10) References DMSANPHAM,
TenSP nvarchar(50),
GiaTien int,
SoLuong int,
XuatXu nvarchar(50)
)

Create table THANHTOAN(
MaTT nvarchar(10) primary key,
PhuongThucThanhToan nvarchar(50)
)

Create table DONHANG(
MaDH nvarchar(10) primary key,
MaKH nvarchar(10) references KHACHHANG,
MaTT nvarchar(10) references THANHTOAN,
NgayDat Date
)

Create table CHITIETDONHANG(
MaDH nvarchar(10) references DONHANG,
MaSP nvarchar(10) references SANPHAM,
SoLuong int,
TongTien int
)

--Cau1:
--a) Tạo một khung nhìn có tên là V_KhachHang để thấy được thông tin của tất cả các đơn hàng có ngày đặt hàng nhỏ hơn 
--ngày 06/15/2015 của những khách hàng có địa chỉ là "Da Nang". 
Alter view V_KhachHang
as
select MaDH,DONHANG.MaKH,MaTT,NgayDat from DONHANG,KHACHHANG
where DiaChi = 'Da Nang' and NgayDat < '2015-06-15' and KHACHHANG.MaKH=DONHANG.MaKH

select * from V_KhachHang

--b) Thông qua khung nhìn V_KhachHang thực hiện việc cập nhật ngày đặt hàng thành 06/15/2015 đối với những khách hang
-- đặt hàng vào ngày 06/15/2014.

Update V_KhachHang
set NgayDat = '2015-06-15'
where NgayDat = '2015-05-15'

--Cau2:
--a) Thủ tục Sp_1: Dùng để xóa thông tin của những sản phẩm có mã sản phẩm được truyền vào như một tham số của thủ tục
Create proc sp_DelProduct
@MaSP nvarchar(10)
as
	begin
		if not exists(select * from SANPHAM where MaSP = @MaSP)
		begin
			print'Ma SP khong ton tai'
			Return
		end
	Delete from SANPHAM where MaSP=@MaSP
end

exec sp_DelProduct 'SP004'

--b)Thủ tục Sp_2: Dùng để bổ sung thêm bản ghi mới
--vào bảng CHITIETDONHANG (Sp_2 phải thực hiện kiểm tra tính hợp lệ của dữ liệu được bổ sung là không trùng khóa chính
--và đảm bảo toàn vẹn tham chiếu đến các bảng có liên quan).

Alter proc sp_AddCTDonHang
(@MaDH nvarchar(10),
@MaSP nvarchar(10),
@SoLuong int,
@TongTien int)
as begin
	declare @MaHDTemp nvarchar(10)
	declare @MaSPTemp nvarchar(10)
	select @MaHDTemp = MaDH, @MaSPTemp=MaSP from CHITIETDONHANG
	if not exists (select * from DONHANG where MaDH = @MaDH)
		begin
			print'Ma DH khong ton tai'
			return
		end
	else if not exists(select * from SANPHAM where MaSP = @MaSP)
		begin
			print'Ma SP khong ton tai'
			return
		end
	else if (@MaHDTemp = @MaDH or @MaSPTemp = @MaSP)
		begin
			print'Ma SP, ma DH da ton tai'
			return
		end
	insert into CHITIETDONHANG values(@MaDH,@MaSP,@SoLuong,@TongTien)
end

exec sp_AddCTDonHang 'DH001','SP001','50','120000'

--Cau 3:
--a) Trigger_1: Khi thực hiện đăng ký mới một đơn đặt hàng cho khách hàng thì cập nhật lại số lượng sản phẩm trong bảng sản phẩm
--(tức là số lượng sản phẩm còn lại sau khi đã bán). Bẫy sự kiện chỉ xử lý 1 bản ghi. 

Alter Trigger tr_CheckOrder
on CHITIETDONHANG
for insert
as
begin
	declare @SoLuong int
	declare @MaSP nvarchar(10)
	select @MaSP = MaSP, @SoLuong= SoLuong from inserted
	if(@SoLuong < (Select SoLuong from SANPHAM))	
		begin
			update SANPHAM set SANPHAM.SoLuong = SANPHAM.SoLuong - inserted.SoLuong
			from SANPHAM inner join inserted on SANPHAM.MaSP=inserted.MaSP
		end
	else
		begin
			print 'Kho Khong Du So Luong San Pham'
			rollback transaction
		end
end

insert into CHITIETDONHANG values ('DH001','SP003','50','15000000')

--b) Trigger_2: Khi cập nhập lại số lượng sản phẩm mà khách hàng đã đặt hàng, kiểm tra xem số lượng cập nhật có phù hợp hay không
--(số lượng phải lớn hơn 1 và nhỏ hơn 100). Nếu dữ liệu hợp lệ thì cho phép cập nhật, nếu không thì hiển thị thông báo
--"số lượng sản phẩm được đặt hàng phải nằm trong khoảng giá trị từ 1 đến 100" và thực hiện quay lui giao tác.

Alter Trigger tr_CheckAmount
on CHITIETDONHANG
for update
as
begin
	declare @SoLuong int
	select @SoLuong= SoLuong from inserted
	if(@SoLuong<1 or @SoLuong >100)
		begin
			print'So luong khong hop le'
			rollback transaction
		end
end

update CHITIETDONHANG set SoLuong = 150 where MaDH = 'DH001' and MaSP = 'SP003' 

--Cau4:Tạo hàm do người dùng định nghĩa (user-defined function) để tính điểm thưởng cho khách hàng của tất cả các lần đặt hàng
--trong năm 2014, mã khách hàng sẽ được truyền vào thông qua tham số đầu vào của hàm. Cụ thể như sau:

---Nếu tổng số tiền khách hàng đã trả cho tất cả các lần mua hàng dưới 2.000.000,
--thì trả về kết quả là khách hàng được nhận 20 điểm thưởng
---Nếu tổng số tiền khách hàng đã trả cho tất cả các lần mua hàng từ 2.000.000 trở đi, thì trả về kết quả là
--khách hàng được nhận 50 điểm thưởng. 

Alter function fncPoint(@MaKH nchar(10))
returns int
as
begin
	declare @DiemThuong int
	declare @TongTien int
	select @TongTien = sum(TongTien) from CHITIETDONHANG,DONHANG,KHACHHANG
	where CHITIETDONHANG.MaDH=DONHANG.MaDH and YEAR(NgayDat) = '2014' and @MaKH = DONHANG.MaKH
	if(@TongTien <2000000)
		begin
			select @DiemThuong = 20
		end
	else if(@TongTien >2000000)
		begin
			select @DiemThuong = 50
		end
	return (@DiemThuong)
end

select dbo.fncPoint('KH01')

--Câu 5: Tạo thủ tục Sp_SanPham tìm những sản phẩm đã từng được khách hàng đặt mua để xóa thông tin về
--những sản phẩm đó trong bảng SANPHAM và xóa thông tin những đơn hàng có liên quan đến những sản phẩm đó
--(tức là phải xóa những bản ghi trong bảng DONHANG và CHITIETDONHANG có liên quan đến các sản phẩm đó). 

Alter proc For_TranFind
as
begin 
	declare contro Cursor
	for select CHITIETDONHANG.MaSP, CHITIETDONHANG.MaDH from DONHANG,CHITIETDONHANG
	open contro
	declare @MaSP nvarchar(10)
	declare @MaDH nvarchar(10)
	Fetch next from contro
	into @MaSP,@MaDH
	while @@FETCH_STATUS = 0
	begin
		Delete from CHITIETDONHANG where CHITIETDONHANG.MaDH = @MaDH and CHITIETDONHANG.MaSP= @MaSP
		if not exists(select MaDH from CHITIETDONHANG where MaDH = @MaDH) delete from DONHANG where MaDH = @MaDH
		if not exists(select MaSP from CHITIETDONHANG where MaSP = @MaSP) delete from SANPHAM where MaSP = @MaSP
		Fetch next from contro
		into @MaSP,@MaDH
	end
	Close contro
	deallocate contro
end

exec For_TranFind