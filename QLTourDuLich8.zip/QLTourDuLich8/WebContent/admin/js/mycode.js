$(document).ready(function() {
   tab();
});
function tab() {
    $('.hideitem').hide();

}