package model.bean;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * BaiVietQuyND.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class BaiVietQuyND {
	private int maBV;
	private int danhMuc;
	private String khuVuc;
	private String diaChiBaiViet;
	private String nguoiDang;
	private String tieuDe;

	private String mota;
	private String noiDung;
	private String loaiBaiViet;
	private Date ngayDang;
	private int luotXem,maKhuVuc;
	private int luotThich,maDanhMuc;
	private int luotKhongThich;
	private float danhGiaTrungBinh;
	private String anh1;
	private String anh2;
	private String anh3;
	private String kinhDo;
	private String viDo;

	
	
	public int getMaBV() {
		return maBV;
	}

	public void setMaBV(int maBV) {
		this.maBV = maBV;
	}

	public int getDanhMuc() {
		return danhMuc;
	}

	public void setDanhMuc(int danhMuc) {
		this.danhMuc = danhMuc;
	}

	public String getKinhDo() {
		return kinhDo;
	}

	public void setKinhDo(String kinhDo) {
		this.kinhDo = kinhDo;
	}

	public String getViDo() {
		return viDo;
	}

	public void setViDo(String viDo) {
		this.viDo = viDo;
	}

	public int getMaKhuVuc() {
		return maKhuVuc;
	}

	public void setMaKhuVuc(int maKhuVuc) {
		this.maKhuVuc = maKhuVuc;
	}

	public int getMaDanhMuc() {
		return maDanhMuc;
	}

	public void setMaDanhMuc(int maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}

	
	public String getKhuVuc() {
		return khuVuc;
	}

	public void setKhuVuc(String khuVuc) {
		this.khuVuc = khuVuc;
	}

	public String getDiaChiBaiViet() {
		return diaChiBaiViet;
	}

	public void setDiaChiBaiViet(String diaChiBaiViet) {
		this.diaChiBaiViet = diaChiBaiViet;
	}

	public String getNguoiDang() {
		return nguoiDang;
	}

	public void setNguoiDang(String nguoiDang) {
		this.nguoiDang = nguoiDang;
	}

	public String getLoaiBaiViet() {
		return loaiBaiViet;
	}

	public void setLoaiBaiViet(String loaiBaiViet) {
		this.loaiBaiViet = loaiBaiViet;
	}

	public String getTieuDe() {
		return tieuDe;
	}

	public void setTieuDe(String tieuDe) {
		this.tieuDe = tieuDe;
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public String getNoiDung() {
		return noiDung;
	}

	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}

	public String getNgayDang() {
		if(ngayDang!=null){
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd-MM-yyyy");
			String dateConvert = simpleDateFormat.format(ngayDang);
			return dateConvert;
			}
			else
				return "";
	}

	public void setNgayDang(Date ngayDang) {
		this.ngayDang = ngayDang;
	}

	public int getLuotXem() {
		return luotXem;
	}

	public void setLuotXem(int luotXem) {
		this.luotXem = luotXem;
	}

	public int getLuotThich() {
		return luotThich;
	}

	public void setLuotThich(int luotThich) {
		this.luotThich = luotThich;
	}

	public int getLuotKhongThich() {
		return luotKhongThich;
	}

	public void setLuotKhongThich(int luotKhongThich) {
		this.luotKhongThich = luotKhongThich;
	}

	public float getDanhGiaTrungBinh() {
		return danhGiaTrungBinh;
	}

	public void setDanhGiaTrungBinh(float danhGiaTrungBinh) {
		this.danhGiaTrungBinh = danhGiaTrungBinh;
	}

	public String getAnh1() {
		return anh1;
	}

	public void setAnh1(String anh1) {
		this.anh1 = anh1;
	}

	public String getAnh2() {
		return anh2;
	}

	public void setAnh2(String anh2) {
		this.anh2 = anh2;
	}

	public String getAnh3() {
		return anh3;
	}

	public void setAnh3(String anh3) {
		this.anh3 = anh3;
	}

	
}
