package model.bean;
/**
 * BinhLuan.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class BinhLuan {
	private int maBinhLuan;
	private int idBaiViet;
	private String tenNguoiBinhLuan;
	private String anhDaiDien;
	private String ngayBinhLuan;
	private String noiDungBinhLuan;
	private String email;
	private int maTour;
	private String maTK;
	private String anh;
	private String tenTour;
   
	
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	public String getAnh() {
		return anh;
	}
	public void setAnh(String anh) {
		this.anh = anh;
	}
	public String getMaTK() {
		return maTK;
	}
	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}
	public int getMaTour() {
		return maTour;
	}
	public void setMaTour(int maTour) {
		this.maTour = maTour;
	}
	
	public int getMaBinhLuan() {
		return maBinhLuan;
	}
	public void setMaBinhLuan(int maBinhLuan) {
		this.maBinhLuan = maBinhLuan;
	}
	public int getIdBaiViet() {
		return idBaiViet;
	}
	public void setIdBaiViet(int idBaiViet) {
		this.idBaiViet = idBaiViet;
	}
	public String getTenNguoiBinhLuan() {
		return tenNguoiBinhLuan;
	}
	public void setTenNguoiBinhLuan(String tenNguoiBinhLuan) {
		this.tenNguoiBinhLuan = tenNguoiBinhLuan;
	}
	public String getAnhDaiDien() {
		return anhDaiDien;
	}
	public void setAnhDaiDien(String anhDaiDien) {
		this.anhDaiDien = anhDaiDien;
	}
	public String getNgayBinhLuan() {
		return ngayBinhLuan;
	}
	public void setNgayBinhLuan(String ngayBinhLuan) {
		this.ngayBinhLuan = ngayBinhLuan;
	}
	public String getNoiDungBinhLuan() {
		return noiDungBinhLuan;
	}
	public void setNoiDungBinhLuan(String noiDungBinhLuan) {
		this.noiDungBinhLuan = noiDungBinhLuan;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
