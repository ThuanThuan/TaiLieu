package model.bean;
/**
 * KhuyenMai.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class KhuyenMai {
   private int maKhuyenMai;
   private String tenKhuyenMai;
   private String hinhThucKhuyenMai;

public int getMaKhuyenMai() {
	return maKhuyenMai;
}
public void setMaKhuyenMai(int maKhuyenMai) {
	this.maKhuyenMai = maKhuyenMai;
}
public String getTenKhuyenMai() {
	return tenKhuyenMai;
}
public void setTenKhuyenMai(String tenKhuyenMai) {
	this.tenKhuyenMai = tenKhuyenMai;
}
public String getHinhThucKhuyenMai() {
	return hinhThucKhuyenMai;
}
public void setHinhThucKhuyenMai(String hinhThucKhuyenMai) {
	this.hinhThucKhuyenMai = hinhThucKhuyenMai;
}
   

}
