package model.bean;
/**
 * DanhSachTour.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class DanhSachTour {
	private String matour;
	private String danhMuc;
	private String maKhuyenMai;
	private String tenTour;
	private String diemKhoiHanh;
	private String thoiGian;
	private String phuongTien;
	private String lichTrinh;
	private String hinhThuc;
	private int giaTour;
	private String hinhAnh1;
	private String hinhAnh2;
	private String hinhAnh3;
	private String Email;
	private int gia1;
	private int gia2;
	private String moTa;
    private int giaTourSau;
    private String anh;
    private String diemDen;
    private String lichTrinh1;
    private String lichTrinh2;
    private String lichTrinh3;
    private String lichTrinh4;
    private String lichTrinh5;
    private String lichTrinh6;
    private String lichTrinh7;
    private String lichTrinh8;
    private String lichTrinh9;
    
    
    
    
	
	public String getLichTrinh6() {
		return lichTrinh6;
	}
	public void setLichTrinh6(String lichTrinh6) {
		this.lichTrinh6 = lichTrinh6;
	}
	public String getLichTrinh7() {
		return lichTrinh7;
	}
	public void setLichTrinh7(String lichTrinh7) {
		this.lichTrinh7 = lichTrinh7;
	}
	public String getLichTrinh8() {
		return lichTrinh8;
	}
	public void setLichTrinh8(String lichTrinh8) {
		this.lichTrinh8 = lichTrinh8;
	}
	public String getLichTrinh9() {
		return lichTrinh9;
	}
	public void setLichTrinh9(String lichTrinh9) {
		this.lichTrinh9 = lichTrinh9;
	}
	public String getLichTrinh1() {
		return lichTrinh1;
	}
	public void setLichTrinh1(String lichTrinh1) {
		this.lichTrinh1 = lichTrinh1;
	}
	public String getLichTrinh2() {
		return lichTrinh2;
	}
	public void setLichTrinh2(String lichTrinh2) {
		this.lichTrinh2 = lichTrinh2;
	}
	public String getLichTrinh3() {
		return lichTrinh3;
	}
	public void setLichTrinh3(String lichTrinh3) {
		this.lichTrinh3 = lichTrinh3;
	}
	public String getLichTrinh4() {
		return lichTrinh4;
	}
	public void setLichTrinh4(String lichTrinh4) {
		this.lichTrinh4 = lichTrinh4;
	}
	public String getLichTrinh5() {
		return lichTrinh5;
	}
	public void setLichTrinh5(String lichTrinh5) {
		this.lichTrinh5 = lichTrinh5;
	}
	public String getDiemDen() {
		return diemDen;
	}
	public void setDiemDen(String diemDen) {
		this.diemDen = diemDen;
	}
	public String getAnh() {
		return anh;
	}
	public void setAnh(String anh) {
		this.anh = anh;
	}
	public int getGiaTourSau() {
		return giaTourSau;
	}
	public void setGiaTourSau(int giaTourSau) {
		this.giaTourSau = giaTourSau;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	public int getGia1() {
		return gia1;
	}
	public void setGia1(int gia1) {
		this.gia1 = gia1;
	}
	public int getGia2() {
		return gia2;
	}
	public void setGia2(int gia2) {
		this.gia2 = gia2;
	}
	
	public String getMatour() {
		return matour;
	}
	public void setMatour(String matour) {
		this.matour = matour;
	}
	public String getDanhMuc() {
		return danhMuc;
	}
	public void setDanhMuc(String danhMuc) {
		this.danhMuc = danhMuc;
	}
	public String getMaKhuyenMai() {
		return maKhuyenMai;
	}
	public void setMaKhuyenMai(String maKhuyenMai) {
		this.maKhuyenMai = maKhuyenMai;
	}
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	public String getDiemKhoiHanh() {
		return diemKhoiHanh;
	}
	public void setDiemKhoiHanh(String diemKhoiHanh) {
		this.diemKhoiHanh = diemKhoiHanh;
	}
	public String getThoiGian() {
		return thoiGian;
	}
	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}
	public String getPhuongTien() {
		return phuongTien;
	}
	public void setPhuongTien(String phuongTien) {
		this.phuongTien = phuongTien;
	}
	
	public String getLichTrinh() {
		return lichTrinh;
	}
	public void setLichTrinh(String lichTrinh) {
		this.lichTrinh = lichTrinh;
	}
	public String getHinhThuc() {
		return hinhThuc;
	}
	public void setHinhThuc(String hinhThuc) {
		this.hinhThuc = hinhThuc;
	}
	
	public int getGiaTour() {
		return giaTour;
	}
	public void setGiaTour(int giaTour) {
		this.giaTour = giaTour;
	}
	public String getHinhAnh1() {
		return hinhAnh1;
	}
	public void setHinhAnh1(String hinhAnh1) {
		this.hinhAnh1 = hinhAnh1;
	}
	public String getHinhAnh2() {
		return hinhAnh2;
	}
	public void setHinhAnh2(String hinhAnh2) {
		this.hinhAnh2 = hinhAnh2;
	}
	public String getHinhAnh3() {
		return hinhAnh3;
	}
	public void setHinhAnh3(String hinhAnh3) {
		this.hinhAnh3 = hinhAnh3;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
}
