package model.bean;
/**
 * HoatDong.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class HoatDong {
	private String maTK;
	private int maBV;
	private float danhGia;
	private int thich;
	private int khongThich;

	public String getMaTK() {
		return maTK;
	}

	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}

	public int getMaBV() {
		return maBV;
	}

	public void setMaBV(int maBV) {
		this.maBV = maBV;
	}

	public float getDanhGia() {
		return danhGia;
	}

	public void setDanhGia(float danhGia) {
		this.danhGia = danhGia;
	}

	public int getThich() {
		return thich;
	}

	public void setThich(int thich) {
		this.thich = thich;
	}

	public int getKhongThich() {
		return khongThich;
	}

	public void setKhongThich(int khongThich) {
		this.khongThich = khongThich;
	}

}
