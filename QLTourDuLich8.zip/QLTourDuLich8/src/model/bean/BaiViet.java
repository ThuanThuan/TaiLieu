package model.bean;

import java.util.Date;

/**
 * BaiViet.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class BaiViet {
	private int maBaiViet;
	private int maDanhMuc;
	private String diaChiBaiViet;
	private String maTK;
	private String tieuDeBaiViet;
	private String moTa;
	private String noiDung;
	private Date ngayDang;
	private int luotXem;
	private int luotThich;
	private int luotKhongThich;
	private float danhGiaTrungBinh;
	private String anh1;
	private String anh2;
	private String anh3;
	private String thanhVien;
	private String diaDiem;
	private String duyet;
	private String kinhDo;
	private String viDo;
	
	
	public int getMaBaiViet() {
		return maBaiViet;
	}
	public void setMaBaiViet(int maBaiViet) {
		this.maBaiViet = maBaiViet;
	}
	public int getMaDanhMuc() {
		return maDanhMuc;
	}
	public void setMaDanhMuc(int maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}
	public String getDiaChiBaiViet() {
		return diaChiBaiViet;
	}
	public void setDiaChiBaiViet(String diaChiBaiViet) {
		this.diaChiBaiViet = diaChiBaiViet;
	}
	public String getMaTK() {
		return maTK;
	}
	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}
	public String getTieuDeBaiViet() {
		return tieuDeBaiViet;
	}
	public void setTieuDeBaiViet(String tieuDeBaiViet) {
		this.tieuDeBaiViet = tieuDeBaiViet;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public Date getNgayDang() {
		return ngayDang;
	}
	public void setNgayDang(Date ngayDang) {
		this.ngayDang = ngayDang;
	}
	public int getLuotXem() {
		return luotXem;
	}
	public void setLuotXem(int luotXem) {
		this.luotXem = luotXem;
	}
	public int getLuotThich() {
		return luotThich;
	}
	public void setLuotThich(int luotThich) {
		this.luotThich = luotThich;
	}
	public int getLuotKhongThich() {
		return luotKhongThich;
	}
	public void setLuotKhongThich(int luotKhongThich) {
		this.luotKhongThich = luotKhongThich;
	}
	public float getDanhGiaTrungBinh() {
		return danhGiaTrungBinh;
	}
	public void setDanhGiaTrungBinh(float danhGiaTrungBinh) {
		this.danhGiaTrungBinh = danhGiaTrungBinh;
	}
	public String getAnh1() {
		return anh1;
	}
	public void setAnh1(String anh1) {
		this.anh1 = anh1;
	}
	public String getAnh2() {
		return anh2;
	}
	public void setAnh2(String anh2) {
		this.anh2 = anh2;
	}
	public String getAnh3() {
		return anh3;
	}
	public void setAnh3(String anh3) {
		this.anh3 = anh3;
	}
	public String getThanhVien() {
		return thanhVien;
	}
	public void setThanhVien(String thanhVien) {
		this.thanhVien = thanhVien;
	}
	public String getDiaDiem() {
		return diaDiem;
	}
	public void setDiaDiem(String diaDiem) {
		this.diaDiem = diaDiem;
	}
	public String getDuyet() {
		return duyet;
	}
	public void setDuyet(String duyet) {
		this.duyet = duyet;
	}
	public String getKinhDo() {
		return kinhDo;
	}
	public void setKinhDo(String kinhDo) {
		this.kinhDo = kinhDo;
	}
	public String getViDo() {
		return viDo;
	}
	public void setViDo(String viDo) {
		this.viDo = viDo;
	}
	
}
