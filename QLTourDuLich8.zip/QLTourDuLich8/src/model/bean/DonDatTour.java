package model.bean;

/**
 * DonDatTour.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DonDatTour {
	private int maDatTour;
	private int maTour;
	private String tenTour;
	private int soNguoiLon;
	private int soTreEm;
	private String thoiGianKhoiHanh;
	private int tongSoTien;
	private String hoTenNguoiDat;
	private String soDienThoai;
	private String email;
	private String yeuCau;
	private String maTK;
	private String tenTK;
	private String diemKhoiHanh;
	private String phuongTien;
	private String thoiGian;
	private String hinhThuc;
	private String queQuan;
	private String diemDen;
	private String tinhTrang;
	private int giaTourSau;
	private int giaTour;
	private int giaTienTreEm;
	private int giaTienNguoiLon;
	
	
	
	
	
	public int getGiaTienTreEm() {
		return giaTienTreEm;
	}
	public void setGiaTienTreEm(int giaTienTreEm) {
		this.giaTienTreEm = giaTienTreEm;
	}
	public int getGiaTienNguoiLon() {
		return giaTienNguoiLon;
	}
	public void setGiaTienNguoiLon(int giaTienNguoiLon) {
		this.giaTienNguoiLon = giaTienNguoiLon;
	}
	public int getGiaTour() {
		return giaTour;
	}
	public void setGiaTour(int giaTour) {
		this.giaTour = giaTour;
	}
	public int getGiaTourSau() {
		return giaTourSau;
	}
	public void setGiaTourSau(int giaTourSau) {
		this.giaTourSau = giaTourSau;
	}
	public String getTinhTrang() {
		return tinhTrang;
	}
	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	public String getDiemDen() {
		return diemDen;
	}
	public void setDiemDen(String diemDen) {
		this.diemDen = diemDen;
	}
	public String getQueQuan() {
		return queQuan;
	}
	public void setQueQuan(String queQuan) {
		this.queQuan = queQuan;
	}
	public String getDiemKhoiHanh() {
		return diemKhoiHanh;
	}
	public void setDiemKhoiHanh(String diemKhoiHanh) {
		this.diemKhoiHanh = diemKhoiHanh;
	}
	public String getPhuongTien() {
		return phuongTien;
	}
	public void setPhuongTien(String phuongTien) {
		this.phuongTien = phuongTien;
	}
	public String getThoiGian() {
		return thoiGian;
	}
	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}
	public String getHinhThuc() {
		return hinhThuc;
	}
	public void setHinhThuc(String hinhThuc) {
		this.hinhThuc = hinhThuc;
	}
	public int getMaDatTour() {
	return maDatTour;
	}
	public void setMaDatTour(int maDatTour) {
	this.maDatTour = maDatTour;
	}
	
	public int getMaTour() {
		return maTour;
	}
	public void setMaTour(int maTour) {
		this.maTour = maTour;
	}
	public String getTenTour() {
	return tenTour;
	}
	public void setTenTour(String tenTour) {
	this.tenTour = tenTour;
	}
	public int getSoNguoiLon() {
	return soNguoiLon;
	}
	public void setSoNguoiLon(int soNguoiLon) {
	this.soNguoiLon = soNguoiLon;
	}
	public int getSoTreEm() {
	return soTreEm;
	}
	public void setSoTreEm(int soTreEm) {
	this.soTreEm = soTreEm;
	}
	public String getThoiGianKhoiHanh() {
	return thoiGianKhoiHanh;
	}
	public void setThoiGianKhoiHanh(String thoiGianKhoiHanh) {
	this.thoiGianKhoiHanh = thoiGianKhoiHanh;
	}
	public int getTongSoTien() {
	return tongSoTien;
	}
	public void setTongSoTien(int tongSoTien) {
	this.tongSoTien = tongSoTien;
	}
	public String getHoTenNguoiDat() {
	return hoTenNguoiDat;
	}
	public void setHoTenNguoiDat(String hoTenNguoiDat) {
	this.hoTenNguoiDat = hoTenNguoiDat;
	}
	public String getSoDienThoai() {
	return soDienThoai;
	}
	public void setSoDienThoai(String soDienThoai) {
	this.soDienThoai = soDienThoai;
	}
	public String getEmail() {
	return email;
	}
	public void setEmail(String email) {
	this.email = email;
	}
	public String getYeuCau() {
	return yeuCau;
	}
	public void setYeuCau(String yeuCau) {
	this.yeuCau = yeuCau;
	}
	public String getMaTK() {
	return maTK;
	}
	public void setMaTK(String maTK) {
	this.maTK = maTK;
	}
	public String getTenTK() {
	return tenTK;
	}
	public void setTenTK(String tenTK) {
	this.tenTK = tenTK;
}
}
