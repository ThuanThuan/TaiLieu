package model.bo;

import java.util.ArrayList;

import model.bean.KhuyenMai;
import model.dao.KhuyenMaiDAO;
/**
 * KhuyenMaiBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class KhuyenMaiBO {
	KhuyenMaiDAO khuyenMaiDAO = new KhuyenMaiDAO();
      public ArrayList<KhuyenMai> getListKhuyenMai(){
         return khuyenMaiDAO.getListKhuyenMai();
      }
      public ArrayList<KhuyenMai> getDanhSachKhuyenMai(String txtFind){
    	  return khuyenMaiDAO.getDanhSachKhuyenMai(txtFind);
      }
      public boolean themKhuyenMai(String tenKhuyenMai,String hinhThucKhuyenMai) {
    	  return khuyenMaiDAO.themKhuyenMai( tenKhuyenMai, hinhThucKhuyenMai);
    
      }
      public boolean deleteKhuyenMai(int maKhuyenMai){
    	  return khuyenMaiDAO.deleteKhuyenMai(maKhuyenMai);
      }
      public KhuyenMai getThongTinKhuyenMai(int maKhuyenMai){
    	  return khuyenMaiDAO.getThongTinKhuyenMai(maKhuyenMai);
      }
      public boolean capNhatKhuyenMai(int maKhuyenMai,
  			String tenKhuyenMai,String hinhThucKhuyenMai) {
    	  return khuyenMaiDAO.capNhatKhuyenMai(maKhuyenMai, tenKhuyenMai, hinhThucKhuyenMai);
      }
      public String getTenKhuyenMai(int maKhuyenMai) {
    	  return khuyenMaiDAO.getTenKhuyenMai(maKhuyenMai);
      }
}
