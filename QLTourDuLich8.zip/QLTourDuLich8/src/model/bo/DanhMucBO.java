package model.bo;

import java.util.ArrayList;

import model.bean.DanhMuc;
import model.bean.DanhMucTour;
import model.dao.DanhMucDAO;
/**
 * DanhMucBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DanhMucBO {
	DanhMucDAO dDAO=new DanhMucDAO();
	public ArrayList<DanhMucTour> getListDM() {
		// TODO Auto-generated method stub
		return dDAO.getListDM();
	}
	public  ArrayList<DanhMucTour> getDanhMuc(String maDanhMuc) {
		// TODO Auto-generated method stub
		return dDAO.getDanhMuc(maDanhMuc);
	}
	DanhMucDAO danhMucDAO = new DanhMucDAO();
	public ArrayList<DanhMuc> getListDanhMuc() {
		// TODO Auto-generated method stub
		return danhMucDAO.getListDanhMuc();
	}
	public ArrayList<DanhMuc> getDanhSachDanhMuc(String txtFind){
		return danhMucDAO.getDanhSachDanhMuc(txtFind);
	}
	public boolean themDanhMucMonAnMoi(String tenMonMoi,String moTaDanhMuc) {
		return danhMucDAO.themDanhMucMonAnMoi(tenMonMoi, moTaDanhMuc, moTaDanhMuc);
	}

	/**
	 * xÃ³a danh má»¥c mÃ³n Äƒn Ä‘Æ°á»£c chá»�n tá»« quáº£n trá»‹ viÃªn
	 * 
	 * @param maDanhMuc
	 * @return true/false
	 */

	public boolean deleteDanhMucMonAn(int tenDanhMuc) {
		return danhMucDAO.deleteDanhMucMonAn(tenDanhMuc);
	}

	/**
	 * láº¥y tÃªn danh má»¥c mÃ³n Äƒn
	 * 
	 * @param maMonAnChinhSua
	 * @return tenMonAn
	 */

	public String getTenMonAn(int maMonAnChinhSua) {
		return danhMucDAO.getTenMonAn(maMonAnChinhSua);
	}

	/**
	 * Cáº­p nháº­t tÃªn danh má»¥c mÃ³n Äƒn
	 * 
	 * @param maMonAnChinhSua
	 *            ,tenMonAnMoi
	 * @return true/false
	 */

	public boolean capNhatTenMonAn(int maMonAnChinhSua, String tenMonAnMoi,String moTaDanhMuc) {
		return danhMucDAO.capNhatTenMonAn(maMonAnChinhSua, tenMonAnMoi,moTaDanhMuc);
	}
	public DanhMuc getThongTinDanhMuc(int maDanhMuc){
		return danhMucDAO.getThongTinDanhMuc(maDanhMuc);
	}
} 
