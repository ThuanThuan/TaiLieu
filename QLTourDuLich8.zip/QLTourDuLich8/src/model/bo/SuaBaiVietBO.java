package model.bo;

import model.bean.BaiViet;
import model.dao.SuaBaiVietDAO;
/**
 * SuaBaiVietBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaBaiVietBO {
	SuaBaiVietDAO suaBaiVietDAO = new SuaBaiVietDAO();
	public BaiViet getsuaBaiViet(int maBaiViet) {
		// TODO Auto-generated method stub
		return suaBaiVietDAO.getsuaBaiViet(maBaiViet);
	}

}
