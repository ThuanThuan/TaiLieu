package model.bo;

import java.util.ArrayList;

import model.bean.DanhSachTour;
import model.bean.DonDatTour;
import model.dao.DonDatTourDAO;
/**
 * DonDatTourBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DonDatTourBO {
	DonDatTourDAO donDatTourDAO = new DonDatTourDAO();
	public ArrayList<DonDatTour> getDonDatTour(String txtFind) {
		return  donDatTourDAO.getDonDatTour(txtFind);
	}
	public ArrayList<DonDatTour> getDonDatTourMoi(String txtFind){
		return donDatTourDAO.getDonDatTourMoi(txtFind);
	}
	public boolean deleteDatTour(int maDatTour) {
		return donDatTourDAO.deleteDatTour(maDatTour);
	}
	public DonDatTour getThongTinTour(int maDatTour){
		return donDatTourDAO.getThongTinTour(maDatTour);
	}
	public boolean updateDonDatTour(int maDatTour,int maTour,int soNguoiLon,int soTreEm,String thoiGianKhoiHanh,int tongSoTien,String hoTenNguoiDat,String sDT,String email,String yeuCau) {
		return donDatTourDAO.updateDonDatTour(maDatTour, maTour, soNguoiLon, soTreEm, thoiGianKhoiHanh, tongSoTien, hoTenNguoiDat, sDT, email, yeuCau);
	}
	public boolean themDonDatTour(int maTour,int soNguoiLon,int soTreEm,String thoiGianKhoiHanh,int tongSoTien,String hoTenNguoiDat,String soDienThoai,String email,String yeuCau,String maTK,String queQuan,String tinhTrang){
		return donDatTourDAO.themDonDatTour(maTour, soNguoiLon, soTreEm, thoiGianKhoiHanh, tongSoTien, hoTenNguoiDat, soDienThoai, email, yeuCau, maTK,queQuan,tinhTrang);
	}
	public ArrayList<DanhSachTour> getTourDuLich(int maTour) {
		// TODO Auto-generated method stub
		
		return donDatTourDAO.getTourDuLich(maTour);
	}
	public ArrayList<DonDatTour> getDonDatTour(int maDatTour){
		return donDatTourDAO.getDonTourDuLich(maDatTour);
	}
	public ArrayList<DonDatTour> getDonDatTour() {
		// TODO Auto-generated method stub
		return donDatTourDAO.getDonTourDuLich();
	}
	public ArrayList<DonDatTour> getDonTourDuLichTaiKhoan(String maTK) {
		return donDatTourDAO.getDonTourDuLichTaiKhoan(maTK);
	}
	public boolean updateDonDatTour1(String tinhTrang,int maDatTour) {
		return donDatTourDAO.updateDonDatTour1(tinhTrang, maDatTour);
	}
	public DanhSachTour getTourDuLich1(int maTour) {
		return donDatTourDAO.getTourDuLich1(maTour);
	}
	
}
	

