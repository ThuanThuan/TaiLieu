package model.bo;

import java.util.ArrayList;

import model.bean.TourDuLich;
import model.dao.TourDAO;
/**
 * TourBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class TourBO {
     TourDAO tourDAO = new TourDAO();
     public ArrayList<TourDuLich> getListTourDuLich(String txtFind){
    	 return tourDAO.getListTourDuLich(txtFind);
     }
     public  ArrayList<TourDuLich> getListTourDuLichMoi(String txtFind){
    	 return tourDAO.getListTourDuLichMoi(txtFind);
     }
     public boolean themTourDuLich(int maDanhMuc,int maKhuyenMai,String tenTour,String diemKhoiHanh,String thoiGian,String phuongTien,String lichTrinh,String hinhThuc,int giaTour,String hinhAnh1,String hinhAnh2,String hinhAnh3,String email,String moTa,String diemDen,int giaTourSau){
    	 return tourDAO.themTourDuLich( maDanhMuc, maKhuyenMai, tenTour, diemKhoiHanh, thoiGian, phuongTien, lichTrinh, hinhThuc, giaTour, hinhAnh1, hinhAnh2, hinhAnh3, email,moTa,diemDen,giaTourSau);
     }
     public boolean deleteTourDuLich(int maTour){
    	 return tourDAO.deleteTourDuLich(maTour);
     }
     public TourDuLich getThongTinTour(int maTour){
    	 return tourDAO.getThongTinTour(maTour);
     }
     public boolean updateTourDuLich(int maTour,int maDanhMuc,int maKhuyenMai,String tenTour,String diemKhoiHanh,String thoiGian,String phuongTien,String lichTrinh,String hinhThuc,int giaTour,String hinhAnh1,String hinhAnh2,String hinhAnh3,String email,String moTa,String diemDen,int giaTourSau){
    	 return tourDAO.updateTourDuLich(maTour, maDanhMuc, maKhuyenMai, tenTour, diemKhoiHanh, thoiGian, phuongTien, lichTrinh, hinhThuc, giaTour, hinhAnh1, hinhAnh2, hinhAnh3, email,moTa,diemDen,giaTourSau);
     }
     public ArrayList<TourDuLich> getTenTour(String txtFind) {
    	 return tourDAO.getTenTour(txtFind);
     }
}
