package model.bo;

import model.bean.BaiViet;
import model.dao.DuyetBaiVietDAO;
/**
 * DuyetBaiVietBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DuyetBaiVietBO {
	DuyetBaiVietDAO duyetBaiVietDAO = new DuyetBaiVietDAO();
	public BaiViet getduyetBaiViet(int maBaiViet) {
		// TODO Auto-generated method stub
		return duyetBaiVietDAO.getduyetBaiViet(maBaiViet);
	}
}
