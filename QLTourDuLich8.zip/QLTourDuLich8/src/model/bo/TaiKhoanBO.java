package model.bo;

import java.util.ArrayList;

import model.bean.TaiKhoan;
import model.dao.TaiKhoanDAO;
/**
 * TaiKhoanBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class TaiKhoanBO {
	TaiKhoanDAO taiKhoanDAO = new TaiKhoanDAO();

	/**
	 * get danh sÃ¡ch tÃ i khoáº£n theo Ä‘iá»�u kiá»‡n cho trÆ°á»›c
	 * @param txtFind
	 * @return ArrayList<TaiKhoan>
	 */
	
	public ArrayList<TaiKhoan> getDanhSachTaiKhoan(String txtFind) {
		return taiKhoanDAO.getDanhSachTaiKhoan(txtFind);
	}

	/**
	 * xÃ³a tÃ i khoáº£n Ä‘Æ°á»£c chá»�n tá»« quáº£n trá»‹ viÃªn
	 * @param taiKhoan
	 * @return true/false
	 */
	
	public boolean deleteTaiKhoan(String taiKhoan) {
		return taiKhoanDAO.deleteTaiKhoan(taiKhoan);
	}

	/**
	 * reset máº­t kháº©u máº·t Ä‘á»‹nh cá»§a ngÆ°á»�i dÃ¹ng
	 * @param taiKhoan
	 * @return true/false
	 */
	
	public boolean resetTaiKhoan(String taiKhoan) {
		return taiKhoanDAO.resetTaiKhoan(taiKhoan);
	}

	/**
	 * kiá»ƒm tra tá»“n táº¡i cá»§a tÃ i khoáº£n trong database
	 * @param user
	 * @param pass
	 * @param i
	 * @return TaiKhoan
	 */
	
	public TaiKhoan kiemTraTaiKhoan(String user, String pass, int i) {
		if (user == null || pass == null)
			return null;
		else if (user != null && user.trim().equals(""))
			return null;
		else if (pass != null && pass.trim().equals(""))
			return null;
		else
			return taiKhoanDAO.kiemTraTaiKhoan(user, pass, i);
	}
	
	public TaiKhoan kiemTraThanhVien(String user, String pass){
		return taiKhoanDAO.kiemTraThanhVien(user, pass);
	}

	/**
	 * cáº­p nháº­t thÃ´ng tin
	 * @param taiKhoan
	 * @param hoTen
	 * @param diaChi
	 * @param dienThoai
	 * @return true/false
	 */
	
	public boolean upDateThongTin(String taiKhoan, String hoTen, String diaChi,
			String dienThoai) {
		return taiKhoanDAO.upDateThongTin(taiKhoan, hoTen, diaChi, dienThoai);
	}

	/**
	 * Ä‘á»•i máº­t kháº©u tÃ i khoáº£n thÃ nh viÃªn
	 * @param taiKhoan
	 * @param matKhau
	 * @return true/false
	 */
	
	public boolean doiMatKhau(String taiKhoan, String matKhau) {
		return taiKhoanDAO.doiMatKhau(taiKhoan, matKhau);
	}
	
	/**
	 * Dang Ky
	 * @param maTK
	 * @param matKhau
	 * @param loaiTaiKhoan
	 * @param hoTen
	 * @param email
	 * @param diaChi
	 * @param ngaySinh
	 * @param gioiTinh
	 * @param soDienThoai
	 * @param soThich
	 * @param tinhTrang
	 * @param anh
	 * @param ngayThamGia
	 * @return true/false
	 */
	public boolean dangKy(String maTK,String matKhau,String hoTen,String email,String diaChi,String ngaySinh,int gioiTinh,String soDienThoai,String soThich,int tinhTrang,String anh,String ngayThamGia){
		return taiKhoanDAO.dangKy(maTK, matKhau, hoTen, email, diaChi, ngaySinh, gioiTinh, soDienThoai, soThich, tinhTrang, anh, ngayThamGia);
	}

}
