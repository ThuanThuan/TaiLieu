package model.bo;

import model.bean.TaiKhoan;
import model.dao.DataDAO;
/**
 * DataBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DataBO {
	DataDAO data=new DataDAO();

	public TaiKhoan getTaiKhoanHienTai(String tenDangNhap) {
		// TODO Auto-generated method stub
		return data.getTaiKhoanHienTai(tenDangNhap);
	}

}
