package model.bo;

import model.dao.ThemMoiBaiVietDAO;
/**
 * ThemMoiBaiVietBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemMoiBaiVietBO {
	ThemMoiBaiVietDAO themMoiBaiVietDAO = new ThemMoiBaiVietDAO();
	public boolean themMoiBaiViet( String textTieuDeBaiViet,
			 int maDanhMuc, String textDiaChi, String textMoTa,
			String textEditor, String anh1,String anh2,String anh3) {
		// TODO Auto-generated method stub
		return themMoiBaiVietDAO.themMoiBaiViet(textTieuDeBaiViet,
				 maDanhMuc,textDiaChi,textMoTa,
				textEditor,anh1,anh2,anh3);
	}

}
