package model.bo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import model.bean.TaiKhoan;
import model.dao.ExecuteDAO;
/**
 * ExecuteBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ExecuteBO {
	ExecuteDAO execute=new ExecuteDAO();

	public boolean kiemTraDangNhap(String tenDangNhap, String matKhau) {
		// TODO Auto-generated method stub
		return execute.kiemTraDangNhap(tenDangNhap,matKhau);
	}

	public boolean capNhatMatKhau(String matKhauMoi, String tenDangNhap) {
		// TODO Auto-generated method stub
		return execute.capNhatMatKhau(matKhauMoi,tenDangNhap);
	}

	public boolean capNhatThongTin(String hoTen, String tenDangNhap,
			String email, String diaChi, String ngaySinh, int gioiTinh,
			String soDienThoai, String soThich, String anh) {
		// TODO Auto-generated method stub
		return execute.capNhatThongTin(hoTen,tenDangNhap,email,diaChi,ngaySinh,gioiTinh,soDienThoai,soThich,anh);
	}

	public boolean dangKyTaiKhoan(String hoTen, String matKhau,
			String tenDangNhap, String email, String diaChi, String ngaySinh,
			String gioiTinh, String soDienThoai, String soThich, String anh) {
		// TODO Auto-generated method stub
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		String ngayThamGia = dateformat.format(new Date());
		return execute.dangKytaiKhoan(hoTen,matKhau,tenDangNhap,email,diaChi,ngaySinh,gioiTinh,soDienThoai,soThich,anh,ngayThamGia);
	}
	public void xoaBV(int maBV) {
		// TODO Auto-generated method stub
		 execute.xoaBV(maBV);;
	}

	

}
