package model.bo;

import model.dao.UpdateBaiVietDAO;
/**
 * UpdateBaiVietBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class UpdateBaiVietBO {
	UpdateBaiVietDAO updateBaiVietDAO = new UpdateBaiVietDAO();
	public boolean updateBaiViet(int maBaiViet, String textTieuDeBaiViet,
			int maDanhMuc, String textDiaChi, String textMoTa,
			String textEditor, String anh1,String anh2,String anh3) {
		// TODO Auto-generated method stub
		return updateBaiVietDAO.updateBaiViet(maBaiViet,textTieuDeBaiViet,
				 maDanhMuc, textDiaChi,textMoTa,textEditor,anh1,anh2,anh3) ;
	}
}
