package model.bo;

import java.util.ArrayList;

import model.bean.BaiViet;
import model.bean.BinhLuan;
import model.dao.BaiVietDAO;
/**
 * BaiVietBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class BaiVietBO {
	BaiVietDAO baiVietDAO = new BaiVietDAO();
	public ArrayList<BaiViet> getListBaiViet(String txtFind) {
		// TODO Auto-generated method stub
		return baiVietDAO.getListBaiViet(txtFind);
	}
	public ArrayList<BaiViet> getListBaiVietMoi(String txtFind) {
		// TODO Auto-generated method stub
		return baiVietDAO.getListBaiVietMoi(txtFind);
	}
	public boolean getDuyetBaiViet(String duyet, int maBaiViet) {
		// TODO Auto-generated method stub
		return baiVietDAO.getDuyetBaiViet(duyet,maBaiViet);
	}
	public ArrayList<BinhLuan> getListBinhLuan(int maBaiViet) {
		// TODO Auto-generated method stub
		return baiVietDAO.getListBinhLuan(maBaiViet);
	}
	public ArrayList<BaiViet> getListBaiVietTour(String txtFind) {
		// TODO Auto-generated method stub
		return baiVietDAO.getListBaiVietTour(txtFind);
	}
	public ArrayList<BaiViet> getListBaiVietKhachSan(String txtFind) {
		// TODO Auto-generated method stub
		return baiVietDAO.getListBaiVietKhachSan(txtFind);
	}
	public ArrayList<BaiViet> getListBaiVietTourKM(String txtFind) {
		// TODO Auto-generated method stub
		return baiVietDAO.getListBaiVietTourKM(txtFind);
	}

}
