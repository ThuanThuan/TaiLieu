package model.bo;

import java.util.ArrayList;

import model.bean.ThongKe;
import model.dao.ThongKeDAO;
/**
 * ThongKeBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThongKeBO {
ThongKeDAO thongKeDAO = new ThongKeDAO();
	
	public ArrayList<ThongKe> getListTourHotTheoNgay(String ngayBatDau, String ngayKetThuc){
		return thongKeDAO.getListTourHotTheoNgay(ngayBatDau, ngayKetThuc);
	}
	
	public ArrayList<ThongKe> getListDoanhThuTheoNgay(String ngayBatDau, String ngayKetThuc) {
		// TODO Auto-generated method stub
		return thongKeDAO.getListDoanhThuTheoNgay(ngayBatDau, ngayKetThuc);
	}
	
	public ArrayList<ThongKe> getListDiemKhoiHanhTheoNgay(String ngayBatDau, String ngayKetThuc){
		return thongKeDAO.getListDiemKhoiHanhTheoNgay(ngayBatDau, ngayKetThuc);
	}
	
	public ArrayList<ThongKe> getListSoLuongDatTheoNgay(String ngayBatDau, String ngayKetThuc) {
		return thongKeDAO.getListSoLuongDatTheoNgay(ngayBatDau, ngayKetThuc);
	}
}
