package model.bo;

import model.dao.DeleteBaiVietDAO;
/**
 * DeleteBaiVietBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DeleteBaiVietBO {
	DeleteBaiVietDAO deleteBaiVietDAO = new DeleteBaiVietDAO();
	public boolean deleteBaiViet(int maBaiViet) {
		// TODO Auto-generated method stub
		return deleteBaiVietDAO.deleteBaiViet(maBaiViet);
	}
	public boolean deleteBaiVietMoi(int maBaiViet) {
		// TODO Auto-generated method stub
		return deleteBaiVietDAO.deleteBaiVietMoi(maBaiViet);
	}
	public boolean deleteBinhLuan(int idBinhLuan) {
		// TODO Auto-generated method stub
		return deleteBaiVietDAO.deleteBinhLuan(idBinhLuan);
	}
}
