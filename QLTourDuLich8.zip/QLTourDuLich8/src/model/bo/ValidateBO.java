package model.bo;
import java.util.regex.*;
/**
 * ValidateBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ValidateBO {
	public boolean checkNumber(String value){
		try {
			Integer.valueOf(value);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
	public int checkNumberLenght(String value,int lenght){
		if(checkNumber(value))
			if(value.length()<lenght)
				return 1;
			else if(value.length()==lenght)
				return 2;
			else return 3;
		else return 0;
	}
    public boolean checkEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        Pattern p = Pattern.compile(ePattern);
        Matcher m = p.matcher(email);
        return m.matches();
 }
    public boolean checkDate(String date){
    	String ePattern = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";
        Pattern p = Pattern.compile(ePattern);
        Matcher matcher = p.matcher(date);
        
        if(matcher.matches()){
    
   	 matcher.reset();
    
   	 if(matcher.find()){
    
                String day = matcher.group(1);
   	     String month = matcher.group(2);
   	     int year = Integer.parseInt(matcher.group(3));
    
   	     if (day.equals("31") && 
   		  (month.equals("4") || month .equals("6") || month.equals("9") ||
                     month.equals("11") || month.equals("04") || month .equals("06") ||
                     month.equals("09"))) {
   			return false; // only 1,3,5,7,8,10,12 has 31 days
   	     } else if (month.equals("2") || month.equals("02")) {
                     //leap year
   		  if(year % 4==0){
   			  if(day.equals("30") || day.equals("31")){
   				  return false;
   			  }else{
   				  return true;
   			  }
   		  }else{
   		         if(day.equals("29")||day.equals("30")||day.equals("31")){
   				  return false;
   		         }else{
   				  return true;
   			  }
   		  }
   	      }else{				 
   		return true;				 
   	      }
   	   }else{
       	      return false;
   	   }		  
        }else{
   	  return false;
        }			    
    }
    public static void main(String[] args) {
		ValidateBO val=new ValidateBO();
		System.out.println(val.checkDate("29/02/2000"));
	}
}
