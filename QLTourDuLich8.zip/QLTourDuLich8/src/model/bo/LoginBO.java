package model.bo;

import model.dao.LoginDAO;
/**
 * LoginBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class LoginBO {
	
	
	LoginDAO lgDAO=new LoginDAO();
	
	public boolean checkLogin(String userName, String passWord) {
		// TODO Auto-generated method stub
		return lgDAO.checkLogin(userName,passWord);
	}

}
