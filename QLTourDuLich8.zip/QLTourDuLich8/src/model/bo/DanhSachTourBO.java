package model.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.bean.BinhLuan;
import model.bean.DanhSachTour;
import model.bean.TaiKhoan;
import model.dao.DanhSachTourDAO;
/**
 * DanhSachTourBO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DanhSachTourBO {
	DanhSachTourDAO dsDAO=new DanhSachTourDAO();
	public ArrayList<DanhSachTour> getListTour() {
		// TODO Auto-generated method stub
		return dsDAO.getListTour();
	}
	public ArrayList<DanhSachTour> getListTopTour() {
		// TODO Auto-generated method stub
		return dsDAO.getListTopTour();
	}
	public ArrayList<DanhSachTour> getListTour(String ddanh,int gia1,int gia2,String thoiGian) throws SQLException {
		// TODO Auto-generated method stub
		return dsDAO.getListTour(ddanh,gia1,gia2,thoiGian);
	}
	public ArrayList<DanhSachTour> getListCT(String maTour) {
		// TODO Auto-generated method stub
		return dsDAO.getListCT(maTour);
	}
	public int getSoSaoDanhGia(String maTKNguoiDung, int maTour) {
		return dsDAO.getSoSaoDanhGia(maTKNguoiDung, maTour);
	}
	public void setSoSaoDanhGia(String maTKNguoiDung, String maTour, int soSao) {
		 dsDAO.setSoSaoDanhGia(maTKNguoiDung, maTour, soSao);
	}
	public void setThichBaiViet(String maTK, String maTour) {
		dsDAO.setThichBaiViet(maTK, maTour);
	}
	public void setKhongThichBaiViet(String maTK, String maTour) {
		dsDAO.setKhongThichBaiViet(maTK, maTour);
	}
	public boolean kiemTraHoatDong(String maTK, String maTour) {
		return dsDAO.kiemTraHoatDong(maTK, maTour);
	}
	public boolean themBinhLuan(String maTK,String maTour,String noiDungBinhLuan){
		return dsDAO.themBinhLuan(maTK, maTour, noiDungBinhLuan);
		 
	}
	public ArrayList<BinhLuan> getListBinhLuan(String maTour){
		return dsDAO.getListBinhLuan(maTour);
	}
	public ArrayList<DanhSachTour> getListTourTN(String maDM) {
		// TODO Auto-generated method stub
		return dsDAO.getListTourTN(maDM);
	}
	public ArrayList<BinhLuan> getListBinhLuanMoiNhat(String maTour){
		return dsDAO.getListBinhLuanMoiNhat(maTour);
	}
	public ArrayList<BinhLuan> getListBinhLuanCuNhat(String maTour){
		return dsDAO.getListBinhLuanCuNhat(maTour);
	}
	
	public DanhSachTour getThongTinTour(){
		return dsDAO.getThongTinTour();
	}
	public ArrayList<BinhLuan> lisBinhLuan(){
		return dsDAO.lisBinhLuan();
	}
	public boolean deleteBinhLuan(int maBinhLuan) {
		return dsDAO.deleteBinhLuan(maBinhLuan);
	}
	public ArrayList<BinhLuan> getDanhSachBinhLuan(String txtFind) {
		return dsDAO.getDanhSachBinhLuan(txtFind);
	}
	public ArrayList<TaiKhoan> getListTaiKhoan(String tenDangNhap) {
		// TODO Auto-generated method stub
		return dsDAO.getListTaiKhoan(tenDangNhap);
	}

}
