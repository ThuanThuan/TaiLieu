package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;









import model.bean.DanhMuc;
import model.bean.KhuyenMai;
/**
 * KhuyenMaiDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class KhuyenMaiDAO {
	DataBaseDAO db = new DataBaseDAO();
	public ArrayList<KhuyenMai> getListKhuyenMai() {
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		ArrayList<KhuyenMai> list = new ArrayList<KhuyenMai>();
		KhuyenMai listKhuyenMai;
		String sql = "SELECT MaKhuyenMai,TenKhuyenMai,HinhThucKhuyenMai FROM KHUYENMAI";

		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()){
				listKhuyenMai = new KhuyenMai();
				listKhuyenMai.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				listKhuyenMai.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
				listKhuyenMai.setHinhThucKhuyenMai(rs.getString("HinhThucKhuyenMai"));
				list.add(listKhuyenMai);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}
		return null;
	}
	public ArrayList<KhuyenMai> getDanhSachKhuyenMai(String txtFind) {
		txtFind = FormatData.FormatInputData(txtFind);
		String sql = "select * from KHUYENMAI where  MaKhuyenMai like N'%"+txtFind
			+"' or TenKhuyenMai like N'%"+txtFind+"%'";
		ResultSet rs = db.getResultSet(sql);
		ArrayList<KhuyenMai> list = null;
		try {
			list = new ArrayList<KhuyenMai>();
			while(rs.next()){
				KhuyenMai khuyenMai = new KhuyenMai();
				khuyenMai.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				khuyenMai.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
				khuyenMai.setHinhThucKhuyenMai(rs.getString("HinhThucKhuyenMai"));
				list.add(khuyenMai);
			}
		} catch (SQLException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
		return list;
	}
	
	public boolean themKhuyenMai(String tenKhuyenMai,String hinhThucKhuyenMai) {

		String sql="insert into KHUYENMAI(TenKhuyenMai,HinhThucKhuyenMai) values(N'"+tenKhuyenMai+"',N'"+hinhThucKhuyenMai+"')";
		try {
			System.out.println(""+sql);
			return db.updateData(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
		}		
		return false;
	}
	
	public int getMaxID(String columName, String tableName){
		String sql="select "+columName+" "+ 
				" from "+tableName+" " +
				" where "+columName+" >= all (select "+columName+" from "+ tableName+")";
		ResultSet rs=db.getResultSet(sql);
		try {
			int max=0;
			while(rs.next()){
				max=Integer.valueOf(rs.getString(1));				
			}
			return max;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return -1;
	}
	public boolean deleteKhuyenMai(int maKhuyenMai) {
		return db.updateData("delete from KHUYENMAI where MaKhuyenMai='"+maKhuyenMai+"'");
}
	
	public KhuyenMai getThongTinKhuyenMai(int maKhuyenMai){
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		KhuyenMai listKhuyenMai = new KhuyenMai();
		String sql = "SELECT * FROM KHUYENMAI WHERE MaKhuyenMai = '"+ maKhuyenMai+"'";
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listKhuyenMai.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				listKhuyenMai.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
				listKhuyenMai.setHinhThucKhuyenMai(rs.getString("HinhThucKhuyenMai"));
				
			}
			return listKhuyenMai;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
	/**
	 * Cập nhật tên danh mục món ăn
	 * @param maMonAnChinhSua,tenMonAnMoi
	 * @return true/false
	 */
	
	public boolean capNhatKhuyenMai(int maKhuyenMai,
			String tenKhuyenMai,String hinhThucKhuyenMai) {
		String sql="update KHUYENMAI set TenKhuyenMai=N'"+tenKhuyenMai+"',HinhThucKhuyenMai=N'"+hinhThucKhuyenMai+"' " +
				" where MaKhuyenMai='"+maKhuyenMai+"'";
		return db.updateData(sql);
	}
	public String getTenKhuyenMai(int maKhuyenMai) {
		String sql="select MaKhuyenMai,TenKhuyenMai,HinhThucKhuyenMai from KHUYENMAI where MaKhuyenMai="+maKhuyenMai+"";
		ResultSet rs= db.getResultSet(sql);
		ArrayList<KhuyenMai> list = null;
		try {
			list = new ArrayList<KhuyenMai>();
			while(rs.next()){
				KhuyenMai khuyenMai = new KhuyenMai();
				khuyenMai.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				khuyenMai.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
				khuyenMai.setHinhThucKhuyenMai(rs.getString("HinhThucKhuyenMai"));
				list.add(khuyenMai);
			}
		}catch(Exception e){
				return null;
			}
		return sql;
		
	}
}
