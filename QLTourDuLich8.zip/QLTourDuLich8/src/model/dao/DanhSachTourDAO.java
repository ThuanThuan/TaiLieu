package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.BinhLuan;
import model.bean.DanhMuc;
import model.bean.DanhSachTour;
import model.bean.Pagination;
import model.bean.TaiKhoan;
/**
 * DanhSachTourDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class DanhSachTourDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=MockProject3";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	
private BaseDAO mInitConnection;
	
	public DanhSachTourDAO(){
		mInitConnection= new BaseDAO();
		mInitConnection.getconnection();
	}
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}
	public ArrayList<DanhSachTour> getListTour() {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select TOP 21 * from TOURDULICH");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setMoTa(rs.getString("MoTa"));
				danhSachTour.setLichTrinh(rs.getString("LichTrinh"));
				
				danhSachTour.setPhuongTien(rs.getString("PhuongTien"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				danhSachTour.setDiemDen(rs.getString("DiemDen"));
				
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DanhSachTour> getListTopTour() {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select TOP 5 t.MaTour,t.TenTour,t.DiemKhoiHanh,t.GiaTour,t.HinhAnh1,t.GiaTourSau,t.MaKhuyenMai,(sum(SoNguoiLon+SoTreEm)) as soLuongDat from DATTOURDULICH dt,TOURDULICH t where dt.MaTour=t.MaTour and YEAR(ThoiGianKhoiHanh) = YEAR(GETDATE()) group by t.MaTour,t.TenTour,t.DiemKhoiHanh,t.GiaTour,t.HinhAnh1,t.GiaTourSau,t.MaKhuyenMai order by SoLuongDat desc"
);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DanhSachTour> getListTour(String ddanh,int gia1,int gia2,String thoiGian) throws SQLException {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from TOURDULICH where TenTour like ? and GiaTour>='"+gia1+"' and ThoiGian LIKE ? ");
	
		ResultSet rs = null;
		try {
			PreparedStatement pstmt = connection.prepareStatement(sql);
			pstmt.setString(1, "%"+ ddanh + "%");
			pstmt.setString(2, "%"+ thoiGian + "%");
			System.out.print(sql);
			rs = pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				danhSachTour.setDiemDen(rs.getString("DiemDen"));
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DanhSachTour> getListTour2(String ddanh) {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from TOURDULICH where tenTour like '%s%' ");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				danhSachTour.setDiemDen(rs.getString("DiemDen"));
			
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DanhSachTour> getListCT(String maTour) {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from TOURDULICH where MaTour='"+maTour+"' ");
		System.out.print(sql);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		try {
			String a[]=new String[10];
			
			while (rs.next()) {
				
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setMoTa(rs.getString("MoTa"));
				danhSachTour.setLichTrinh(rs.getString("LichTrinh"));
				 a=rs.getString("LichTrinh").split("-");
			
				if(a.length==1){
					danhSachTour.setLichTrinh1(a[0]);
				}
				if(a.length==2){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
				}
				if(a.length==3){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
				}
				if(a.length==4){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
					danhSachTour.setLichTrinh4(a[3]);
				}
				if(a.length==5){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
					danhSachTour.setLichTrinh4(a[3]);
					danhSachTour.setLichTrinh5(a[4]);
				}
				if(a.length==6){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
					danhSachTour.setLichTrinh4(a[3]);
					danhSachTour.setLichTrinh5(a[4]);
					danhSachTour.setLichTrinh6(a[5]);
				}
				if(a.length==7){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
					danhSachTour.setLichTrinh4(a[3]);
					danhSachTour.setLichTrinh5(a[4]);
					danhSachTour.setLichTrinh6(a[5]);
					danhSachTour.setLichTrinh7(a[6]);
				}
				if(a.length==8){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
					danhSachTour.setLichTrinh4(a[3]);
					danhSachTour.setLichTrinh5(a[4]);
					danhSachTour.setLichTrinh6(a[5]);
					danhSachTour.setLichTrinh7(a[6]);
					danhSachTour.setLichTrinh7(a[7]);
				}
				if(a.length==9){
					danhSachTour.setLichTrinh1(a[0]);
					danhSachTour.setLichTrinh2(a[1]);
					danhSachTour.setLichTrinh3(a[2]);
					danhSachTour.setLichTrinh4(a[3]);
					danhSachTour.setLichTrinh5(a[4]);
					danhSachTour.setLichTrinh6(a[5]);
					danhSachTour.setLichTrinh7(a[6]);
					danhSachTour.setLichTrinh7(a[7]);
					danhSachTour.setLichTrinh7(a[8]);
				}
				
				
				
				danhSachTour.setPhuongTien(rs.getString("PhuongTien"));
				danhSachTour.setThoiGian(rs.getString("ThoiGian"));
				danhSachTour.setHinhThuc(rs.getString("HinhThuc"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				danhSachTour.setDiemDen(rs.getString("DiemDen"));
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public int getSoSaoDanhGia(String maTKNguoiDung, int maTour) {
		String sql="select DanhGia from HOATDONG where " +
				" (MaTK='"+maTKNguoiDung+"') and (MaTour="+maTour+")";
		System.out.println(sql);
		ResultSet rs= mInitConnection.executeQuery(sql);
		try {
			while(rs.next()){
				//System.out.println(""+Integer.parseInt(rs.getString(1).substring(0,rs.getString(1).indexOf('.'))));		
				return Integer.valueOf(rs.getString(1).substring(0,rs.getString(1).indexOf('.')));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return 0;
	}
	public void setSoSaoDanhGia(String maTKNguoiDung, String maTour, int soSao) {
		String sqlCheck="select DanhGia from HOATDONG where " +
				" (MaTK='"+maTKNguoiDung+"') and (MaTour="+maTour+")";
		System.out.println(sqlCheck);
		ResultSet rsCheck=mInitConnection.executeQuery(sqlCheck);
		try {
			if(rsCheck.next()){
				String sqlUpdate="update HOATDONG set DanhGia="+soSao+" where " +
						"(MaTK='"+maTKNguoiDung+"') and (MaTour="+maTour+")";
				System.out.println(sqlUpdate);
				String sqlUpdate1="update TOURDULICH set DanhGiaTrungBinh=(select avg(DanhGia) from HoatDong where MaTour='"+maTour+"' ) where MaTour='"+maTour+"'";
				System.out.println(sqlUpdate1);
				mInitConnection.executeUpdate(sqlUpdate);
				mInitConnection.executeUpdate(sqlUpdate1);
			}
			else{
				String sqlInsertNew="insert into HOATDONG values (" +
						"'"+maTKNguoiDung+"'" +
						","+maTour+"" +
						","+soSao+",0,0)";
				System.out.println(sqlInsertNew);
				String sqlUpdate1="update TOURDULICH set DanhGiaTrungBinh=(select avg(DanhGia) from HoatDong where MaTour='"+maTour+"' ) where MaTour='"+maTour+"'";
				System.out.println(sqlInsertNew);
				mInitConnection.executeUpdate(sqlInsertNew);
				System.out.println(sqlUpdate1);
				mInitConnection.executeUpdate(sqlUpdate1);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	public void setThichBaiViet(String maTK, String maTour) {
		String sqlCheck="select * from HOATDONG where (" +
				" MaTK='"+maTK+"') and (MaTour="+maTour+")";
		ResultSet rsCheck=mInitConnection.executeQuery(sqlCheck);
		try {
			if(!rsCheck.next()){
				String sqlInsertNew="insert into HOATDONG values(" +
						"'"+maTK+"'" +
						","+maTour+" " +
						",0,1,0)";
				mInitConnection.executeUpdate(sqlInsertNew);
				String sqlUpdateBaiViet="update TOURDULICH set LuotThich=LuotThich +1 " +
						" where (maTour="+maTour+")";
				System.out.println(sqlUpdateBaiViet);
				mInitConnection.executeUpdate(sqlUpdateBaiViet);
			}
			else{
				int thich=rsCheck.getInt(5);
				System.out.println("thicccch"+thich);
				if(thich==1){
					String SqlUpdate="update HOATDONG set Thich=0 where " +
							" (MaTK='"+maTK+"') and (MaTour="+maTour+")";
					mInitConnection.executeUpdate(SqlUpdate);
					System.out.println(SqlUpdate);
					String sqlUpdateBaiViet="update TOURDULICH set LuotThich=LuotThich -1 " +
							" where (MaTour="+maTour+")";
					System.out.println(sqlUpdateBaiViet);
					mInitConnection.executeUpdate(sqlUpdateBaiViet);
				}
				else{
					String sqlUpdate="update HOATDONG set Thich=1, KhongThich=0 where " +
							"(MaTK='"+maTK+"') and (MaTour="+maTour+")";
					mInitConnection.executeUpdate(sqlUpdate);
					String sqlUpdateBaiViet="update TOURDULICH set LuotThich=LuotThich +1 " +
							" where (MaTour="+maTour+")";
					mInitConnection.executeUpdate(sqlUpdateBaiViet);
				}
				
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		
	}
	public void setKhongThichBaiViet(String maTK, String maTour) {
		String sqlCheck="select * from HOATDONG where (" +
				" MaTK='"+maTK+"') and (MaTour="+maTour+")";
		ResultSet rsCheck=mInitConnection.executeQuery(sqlCheck);
		try {
			if(!rsCheck.next()){
				String sqlInsertNew="insert into HOATDONG values(" +
						"'"+maTK+"'" +
						","+maTour+" " +
						",0,0,1)";
				mInitConnection.executeUpdate(sqlInsertNew);
				System.out.println("sql" + sqlInsertNew);
				String sqlUpdateBaiViet="update TOURDULICH set LuotKhongThich=LuotKhongThich +1 " +
						" where (maTour="+maTour+")";
				System.out.println("sql" + sqlUpdateBaiViet);
				mInitConnection.executeUpdate(sqlUpdateBaiViet);
			}
			else{
				int khongthich=rsCheck.getInt(6);
				System.out.println("thicccch"+khongthich);
				if(khongthich==1){
					String SqlUpdate="update HOATDONG set Thich=0 where " +
							" (MaTK='"+maTK+"') and (MaTour="+maTour+")";
					mInitConnection.executeUpdate(SqlUpdate);
					String sqlUpdateBaiViet="update TOURDULICH set LuotKhongThich=LuotKhongThich -1 " +
							" where (MaTour="+maTour+")";
					System.out.println(sqlUpdateBaiViet);
					mInitConnection.executeUpdate(sqlUpdateBaiViet);
				}
				else{
					String sqlUpdate="update HOATDONG set Thich=0, KhongThich=1 where " +
							"(MaTK='"+maTK+"') and (MaTour="+maTour+")";
					mInitConnection.executeUpdate(sqlUpdate);
					String sqlUpdateBaiViet="update TOURDULICH set LuotKhongThich=LuotKhongThich +1 " +
							" where (MaTour="+maTour+")";
					System.out.println(sqlUpdateBaiViet);
					mInitConnection.executeUpdate(sqlUpdateBaiViet);
				}
				
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		
	}
	public boolean kiemTraHoatDong(String maTK, String maTour) {
		String sql="select * from HOATDONG where " +
				" (MaTK='"+maTK+"') and (MaTour="+maTour+")";
		ResultSet rs= mInitConnection.executeQuery(sql);
		try {
			if(!rs.next()){
				return false;
			}
			else{
				int thich=rs.getInt(5);
				int khongThich=rs.getInt(6);
				if(thich==0 && khongThich==0){
					return false;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return true;
	}
	
	public boolean themBinhLuan(String maTK,String maTour,String noiDungBinhLuan){
		
		String sql =("Insert into BINHLUAN(MaTK,MaTour,NoiDungBinhLuan,NgayBinhLuan) values(N'"+maTK+"',N'"+maTour+"',N'"+noiDungBinhLuan+"',GETDATE())");
		System.out.println(sql);
		try {
			mInitConnection.executeUpdate(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
		}		
		return true;
	}
	public ArrayList<BinhLuan> getListBinhLuan(String maTour){
		connect();
		String sql=	String.format("select bl.*,tk.anh from BINHLUAN bl inner join TAIKHOAN as tk on bl.MaTK= tk.MaTK where MaTour='"+maTour+"' order by MaBinhLuan DESC ");
		System.out.println(sql);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<BinhLuan> list = new ArrayList<BinhLuan>();
		BinhLuan binhLuan;
		try {
			while(rs.next()){
				binhLuan = new BinhLuan();
				binhLuan.setMaBinhLuan(rs.getInt("MaBinhLuan"));
				binhLuan.setMaTK(rs.getString("MaTK"));
				binhLuan.setMaTour(rs.getInt("MaTour"));
				binhLuan.setNoiDungBinhLuan((FormatData.FormatOutputData(rs.getString("NoiDungBinhLuan"))));
				binhLuan.setNgayBinhLuan(rs.getString("NgayBinhLuan"));
				binhLuan.setAnh(rs.getString("Anh"));
				list.add(binhLuan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<BinhLuan> getListBinhLuanMoiNhat( String maTour){
		connect();
		String sql=	String.format("select top 1 * from BINHLUAN where MaTour='"+maTour+"' order by MaBinhLuan DESC ");
		System.out.println(sql);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<BinhLuan> list = new ArrayList<BinhLuan>();
		BinhLuan binhLuan;
		try {
			while(rs.next()){
				binhLuan = new BinhLuan();
				binhLuan.setMaBinhLuan(rs.getInt("MaBinhLuan"));
				binhLuan.setMaTK(rs.getString("MaTK"));
				binhLuan.setMaTour(rs.getInt("MaTour"));
				binhLuan.setNoiDungBinhLuan((FormatData.FormatOutputData(rs.getString("NoiDungBinhLuan"))));
				binhLuan.setNgayBinhLuan(rs.getString("NgayBinhLuan"));
				list.add(binhLuan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<BinhLuan> getListBinhLuanCuNhat(String maTour){
		connect();
		String sql=	String.format("select top 1 * from BINHLUAN where MaTour='"+maTour+"' order by MaBinhLuan ASC ");
		System.out.println(sql);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<BinhLuan> list = new ArrayList<BinhLuan>();
		BinhLuan binhLuan;
		try {
			while(rs.next()){
				binhLuan = new BinhLuan();
				binhLuan.setMaBinhLuan(rs.getInt("MaBinhLuan"));
				binhLuan.setMaTK(rs.getString("MaTK"));
				binhLuan.setMaTour(rs.getInt("MaTour"));
				binhLuan.setNoiDungBinhLuan((FormatData.FormatOutputData(rs.getString("NoiDungBinhLuan"))));
				binhLuan.setNgayBinhLuan(rs.getString("NgayBinhLuan"));
				list.add(binhLuan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DanhSachTour> getListTourTN(String maDM) {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from TOURDULICH where MaDanhMuc='"+maDM+"'");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setMoTa(rs.getString("MoTa"));
				danhSachTour.setLichTrinh(rs.getString("LichTrinh"));
	
				
				danhSachTour.setPhuongTien(rs.getString("PhuongTien"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				danhSachTour.setDiemDen(rs.getString("DiemDen"));
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
		
	}

	public DanhSachTour getThongTinTour(){
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		DanhSachTour danhSachTour = new DanhSachTour();
		String sql = "SELECT * FROM TOURDULICH ";
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				danhSachTour = new DanhSachTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setMoTa(rs.getString("MoTa"));
				danhSachTour.setLichTrinh(rs.getString("LichTrinh"));
				
				
				danhSachTour.setPhuongTien(rs.getString("PhuongTien"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				danhSachTour.setDiemDen(rs.getString("DiemDen"));
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
	public ArrayList<BinhLuan> lisBinhLuan(){
		connect();
		String sql=	String.format("select bl.*,tk.HoTen,t.TenTour from BinhLuan bl inner join TaiKhoan as tk on bl.MaTK=tk.MaTK join TOURDULICH as t on bl.MaTour=t.MaTour");
		System.out.println("sql:" + sql);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<BinhLuan> list = new ArrayList<BinhLuan>();
		BinhLuan binhLuan;
		
		try {
			while(rs.next()){
				binhLuan = new BinhLuan();
				binhLuan.setMaBinhLuan(rs.getInt("MaBinhLuan"));
				binhLuan.setMaTK(rs.getString("MaTK"));
				binhLuan.setTenNguoiBinhLuan(rs.getString("HoTen"));
				binhLuan.setNoiDungBinhLuan(rs.getString("NoiDungBinhLuan"));
				binhLuan.setNgayBinhLuan(rs.getString("NgayBinhLuan"));
				binhLuan.setTenTour(rs.getString("TenTour"));
				binhLuan.setMaTour(rs.getInt("MaTour"));
				list.add(binhLuan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<BinhLuan> getDanhSachBinhLuan(String txtFind) {
		DataBaseDAO db = new DataBaseDAO();
		txtFind = FormatData.FormatInputData(txtFind);
		String sql = "select bl.*,tk.HoTen,t.TenTour from BinhLuan bl inner join TaiKhoan as tk on bl.MaTK=tk.MaTK join TOURDULICH as t on bl.MaTour=t.MaTour where tk.HoTen like N'%"+txtFind+"%' or t.TenTour like N'%"+txtFind+"%'";
		ResultSet rs = db.getResultSet(sql);
		ArrayList<BinhLuan> list = new ArrayList<BinhLuan>();
		try {
			
			while(rs.next()){
				BinhLuan binhLuan = new BinhLuan();
				binhLuan.setMaBinhLuan(rs.getInt("MaBinhLuan"));
				binhLuan.setMaTK(rs.getString("MaTK"));
				binhLuan.setTenNguoiBinhLuan(rs.getString("HoTen"));
				binhLuan.setNoiDungBinhLuan(rs.getString("NoiDungBinhLuan"));
				binhLuan.setNgayBinhLuan(rs.getString("NgayBinhLuan"));
				binhLuan.setTenTour(rs.getString("TenTour"));
				binhLuan.setMaTour(rs.getInt("MaTour"));
				list.add(binhLuan);
			}
		} catch (SQLException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
		return list;
	}
	public boolean deleteBinhLuan(int maBinhLuan) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "Delete From BinhLuan WHERE MaBinhLuan ='" + maBinhLuan+ "'";
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	public ArrayList<TaiKhoan> getListTaiKhoan(String tenDangNhap) {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select  * from TAIKHOAN where MaTK='"+tenDangNhap+"'");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<TaiKhoan> list = new ArrayList<TaiKhoan>();
		TaiKhoan TaiKhoan;
		
		try {
			while(rs.next()){
				TaiKhoan = new TaiKhoan();
				TaiKhoan.setLoaiTaiKhoan(rs.getInt("LoaiTaiKhoan"));
				list.add(TaiKhoan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
