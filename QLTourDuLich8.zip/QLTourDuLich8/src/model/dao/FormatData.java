package model.dao;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * FormatData.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017       	DatDN          Create
 */

public class FormatData {
	
	/**
	 * Format data đầu vào
	 * @param data
	 * @return String
	 */
	
	public static String FormatInputData(String data) {
		try {
			if (data != null) {
				return data.replace("'", "!@1").replace("--", "!@2").replace(
						"\\", "!@3").replace(";", "!@4");
			} else {
				return "";
			}
		} catch (Exception e) {
			return data;
		}
	}

	/**
	 * Format data đầu ra
	 * @param data
	 * @return String
	 */
	
	public static String FormatOutputData(String data) {
		try {
			if (data != null) {
				return data.replace("!@1", "'").replace("!@2", "--").replace(
						"!@3", "\\").replace("!@4", ";");
			} else {
				return "";
			}
		} catch (Exception e) {
			return data;
		}
	}

	/**
	 * Chuẩn hóa bảo mật MD5
	 * @param msg
	 * @return String
	 */
	
	public static String FormatMD5(String msg) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(msg.getBytes());
			byte byteData[] = md.digest();
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < byteData.length; i++) {
				sb.append(Integer.toString((byteData[i] & 0xfd) + 0x100, 16)
						.substring(1));
			}
			return sb.toString();
		} catch (Exception ex) {
			return "";
		}
	}

	/**
	 * Format data sang UTF-8
	 * @param isoString
	 * @return String
	 */
	
	public static String toUTF8(String isoString) {
		String utf8String = null;
		try {
			if (isoString != null) {
				byte[] stringByteISO = isoString.getBytes("ISO-8859-1");
				utf8String = new String(stringByteISO, "UTF-8");
			}
		} catch (UnsupportedEncodingException e) {
			utf8String = isoString;
		} catch (Exception e) {
			utf8String = isoString;
		}
		return utf8String;
	}
	
	//ThuanHV
		/**
		 * Format ngay thang
		 */
		public static final DateFormat sdf = new SimpleDateFormat("yyyy/mm/dd");
		
		/**
		 * Kiem tra dinh dang email
		 * @param s
		 * @return
		 */
		public static boolean notVaildEmail(String s){
			//if(notVaild(s)) return true;
			String format = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
					+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"; 
			if(!(s.matches(format))) {
				return true;
			}
			return false;
		}

		/**
		 * Ham kiem tra xem xau co bao gom chi chu so hay khong
		 * @param s
		 * @return boolean
		 */
		public static boolean notVaildNumber(String s){
			if(notVaild(s)) return true;
			String regex = "[0-9]+"; 
			if(s.matches(regex)) return false;
			return true;
		}

	       /**
	       * kiem tra rong
	       * @param s
	       * @return
	       */
	       public static boolean notVaild(String s){
	              if(s==null || s.length()==0) return true;
	              return false;
	       }

}
