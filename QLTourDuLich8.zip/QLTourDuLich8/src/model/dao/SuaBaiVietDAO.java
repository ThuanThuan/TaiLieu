package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.bean.BaiViet;
/**
 * SuaBaiVietDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaBaiVietDAO {
	public BaiViet getsuaBaiViet(int maBaiViet) {
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		BaiViet baiViet = new BaiViet();
		String sql = "SELECT * FROM BAIVIET WHERE MaBV = '"+ maBaiViet+"'";
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				baiViet.setMaDanhMuc( rs.getInt("MaDanhMuc"));
				baiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
				baiViet.setDiaChiBaiViet(rs.getString("DiaChiBaiViet"));
				baiViet.setMoTa(rs.getString("MoTa"));
				baiViet.setNoiDung(rs.getString("NoiDung"));
				baiViet.setAnh1(rs.getString("HinhAnh1"));
				baiViet.setAnh2(rs.getString("HinhAnh2"));
				baiViet.setAnh3(rs.getString("HinhAnh3"));
			}
			return baiViet;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
}
