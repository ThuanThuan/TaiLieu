package model.dao;

import java.sql.Statement;
/**
 * DeleteBaiVietDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DeleteBaiVietDAO {
	public boolean deleteBaiViet(int maBaiViet) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "Delete From BAIVIET WHERE MaBV ='" + maBaiViet
						+ "'";
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public boolean deleteBaiVietMoi(int maBaiViet) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "Delete From BAIVIET WHERE MaBV ='" + maBaiViet
						+ "'";
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public boolean deleteBinhLuan(int idBinhLuan) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "Delete From BINHLUAN WHERE MaBL ='" + idBinhLuan
						+ "'";
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
}

