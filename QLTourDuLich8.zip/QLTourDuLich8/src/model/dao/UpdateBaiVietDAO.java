package model.dao;

import java.sql.Statement;
import java.text.SimpleDateFormat;
/**
 * UpdateBaiVietDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class UpdateBaiVietDAO {
	public boolean updateBaiViet(int maBaiViet, String textTieuDeBaiViet,
		 int maDanhMuc, String textDiaChi, String textMoTa,
			String textEditor, String anh1,String anh2, String anh3) {
		DataBaseDatDN db = new DataBaseDatDN();
	
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql= "update BAIVIET set TieuDe =N'"+textTieuDeBaiViet+"',MaDanhMuc ='"+maDanhMuc+"',DiaChiBaiViet=N'"+textDiaChi+"'," +
						"Mota= N'"+textMoTa+"', NoiDung = N'"+textEditor+"',HinhAnh1 = N'"+anh1+"',HinhAnh2 = N'"+anh2+"',HinhAnh3 = N'"+anh3+"'"
								+ " WHERE MaBV = '"+maBaiViet+"'" ;
				
				System.out.print("SQL: "+sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
}
