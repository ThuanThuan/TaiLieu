package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import model.bean.TaiKhoan;

/**
 * TaiKhoanDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class TaiKhoanDAO {
	DataBaseDAO db = new DataBaseDAO();

	/**
	 * get danh sÃƒÂ¡ch tÃƒÂ i khoÃ¡ÂºÂ£n theo Ã„â€˜iÃ¡Â»ï¿½u kiÃ¡Â»â€¡n cho trÃ†Â°Ã¡Â»â€ºc
	 * @param txtFind
	 * @return ArrayList<TaiKhoan>
	 */
	
	public ArrayList<TaiKhoan> getDanhSachTaiKhoan(String txtFind) {
		txtFind = FormatData.FormatInputData(txtFind);
		String sql = "select * from TAIKHOAN where TinhTrang!=-1 and ( MaTK='"
				+ txtFind + "' or HoTen like N'%" + txtFind + "%' or Email='"
				+ txtFind + "' or DiaChi like N'%" + txtFind
				+ "%' or SoThich like N'%" + txtFind
				+ "%' ) order by NgayThamGia desc";
		ResultSet rs = db.getResultSet(sql);
		ArrayList<TaiKhoan> list = null;
		try {
			list = new ArrayList<TaiKhoan>();
			while (rs.next()) {
				TaiKhoan taiKhoan = new TaiKhoan();
				taiKhoan.setMaTK(FormatData.FormatOutputData(rs
						.getString("MaTK")));
				taiKhoan.setMatKhau(rs.getString("MatKhau"));
				taiKhoan.setLoaiTaiKhoan(rs.getInt("LoaiTaiKhoan"));
				taiKhoan.setHoTen(rs.getString("HoTen"));
				taiKhoan.setEmail(rs.getString("Email"));
				taiKhoan.setDiaChi(rs.getString("DiaChi"));
				String gioiTinh;
				if(rs.getInt("GioiTinh")==0){
				 gioiTinh="Nam";
				}else{
					gioiTinh="Nữ";
				}
				taiKhoan.setGioiTinh(gioiTinh);
				taiKhoan.setSoDienThoai(rs
						.getString("SoDienThoai"));
				taiKhoan.setSoThich(rs
						.getString("SoThich"));
				taiKhoan.setTinhTrang(rs.getInt("TinhTrang"));
				list.add(taiKhoan);
			}
		} catch (SQLException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
		return list;
	}

	/**
	 * xÃƒÂ³a tÃƒÂ i khoÃ¡ÂºÂ£n Ã„â€˜Ã†Â°Ã¡Â»Â£c chÃ¡Â»ï¿½n tÃ¡Â»Â« quÃ¡ÂºÂ£n trÃ¡Â»â€¹ viÃƒÂªn
	 * @param taiKhoan
	 * @return true/false
	 */
	
	public boolean deleteTaiKhoan(String taiKhoan) {
		return db.updateData("update TAIKHOAN set TinhTrang=-1 where MaTK='"
				+ taiKhoan + "'");
	}

	/**
	 * reset mÃ¡ÂºÂ­t khÃ¡ÂºÂ©u mÃ¡ÂºÂ·t Ã„â€˜Ã¡Â»â€¹nh cÃ¡Â»Â§a ngÃ†Â°Ã¡Â»ï¿½i dÃƒÂ¹ng
	 * @param taiKhoan
	 * @return true/false
	 */
	
	public boolean resetTaiKhoan(String taiKhoan) {
		return db
				.updateData("update TAIKHOAN set MatKhau='12345678' where MaTK='"
						+ taiKhoan + "'");
	}

	/**
	 * kiÃ¡Â»Æ’m tra tÃ¡Â»â€œn tÃ¡ÂºÂ¡i cÃ¡Â»Â§a tÃƒÂ i khoÃ¡ÂºÂ£n trong database
	 * @param user
	 * @param pass
	 * @param i
	 * @return TaiKhoan
	 */
	
	public TaiKhoan kiemTraTaiKhoan(String user, String pass, int i) {
		user = FormatData.FormatInputData(user);
		pass = FormatData.FormatInputData(pass);

		String sql = "select * from TAIKHOAN where TinhTrang !=-1 and MaTK='"
				+ user + "' and MatKhau='" + pass + "' and LoaiTaiKhoan='" + i
				+ "'";

		ResultSet rs = db.getResultSet(sql);
		try {
			if (rs.next()) {
				TaiKhoan taiKhoan = new TaiKhoan();
				taiKhoan.setMaTK(FormatData.FormatOutputData(rs
						.getString("MaTK")));
				taiKhoan.setMatKhau(pass);
				taiKhoan.setLoaiTaiKhoan(rs.getInt("LoaiTaiKhoan"));
				taiKhoan.setHoTen(rs.getString("HoTen"));
				taiKhoan.setEmail(rs.getString("Email"));
				taiKhoan.setDiaChi(rs.getString("DiaChi"));
				taiKhoan.setGioiTinh(rs.getString("GioiTinh"));
				taiKhoan.setSoDienThoai(rs.getString("SoDienThoai"));
				taiKhoan.setSoThich(rs.getString("SoThich"));
				taiKhoan.setTinhTrang(rs.getInt("TinhTrang"));
				return taiKhoan;
			}
		} catch (SQLException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
		return null;
	}
	
	public TaiKhoan kiemTraThanhVien(String user, String pass) {
		user = FormatData.FormatInputData(user);
		pass = FormatData.FormatInputData(pass);

		String sql = "select * from TAIKHOAN where  MaTK='"
				+ user + "' and MatKhau='" + pass + "'";

		ResultSet rs = db.getResultSet(sql);
		try {
			if (rs.next()) {
				TaiKhoan taiKhoan = new TaiKhoan();
				taiKhoan.setMaTK(FormatData.FormatOutputData(rs
						.getString("MaTK")));
				taiKhoan.setMatKhau(pass);
				taiKhoan.setLoaiTaiKhoan(rs.getInt("LoaiTaiKhoan"));
				taiKhoan.setHoTen(rs.getString("HoTen"));
				taiKhoan.setEmail(rs.getString("Email"));
				taiKhoan.setDiaChi(rs.getString("DiaChi"));
				taiKhoan.setGioiTinh(rs.getString("GioiTinh"));
				taiKhoan.setSoDienThoai(rs.getString("SoDienThoai"));
				taiKhoan.setSoThich(rs.getString("SoThich"));
				taiKhoan.setTinhTrang(rs.getInt("TinhTrang"));
				return taiKhoan;
			}
		} catch (SQLException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	/**
	 * cÃ¡ÂºÂ­p nhÃ¡ÂºÂ­t thÃƒÂ´ng tin
	 * @param taiKhoan
	 * @param hoTen
	 * @param diaChi
	 * @param dienThoai
	 * @return true/false
	 */
	
	public boolean upDateThongTin(String taiKhoan, String hoTen, String diaChi,
			String dienThoai) {
		hoTen = FormatData.FormatInputData(hoTen);
		diaChi = FormatData.FormatInputData(diaChi);
		dienThoai = FormatData.FormatInputData(dienThoai);
		return db.updateData("update TAIKHOAN set HoTen=N'" + hoTen
				+ "', DiaChi=N'" + diaChi + "', SoDienThoai='" + dienThoai
				+ "' where MaTK='" + taiKhoan + "'");
	}

	/**
	 * Ã„â€˜Ã¡Â»â€¢i mÃ¡ÂºÂ­t khÃ¡ÂºÂ©u tÃƒÂ i khoÃ¡ÂºÂ£n thÃƒÂ nh viÃƒÂªn
	 * @param taiKhoan
	 * @param matKhau
	 * @return true/false
	 */
	
	public boolean doiMatKhau(String taiKhoan, String matKhau) {
		matKhau = FormatData.FormatInputData(matKhau);
		return db.updateData("update TAIKHOAN set MatKhau='" + matKhau
				+ "' where MaTK='" + taiKhoan + "'");
	}
	
	public boolean dangKy(String maTK,String matKhau,String hoTen,String email,String diaChi,String ngaySinh,int gioiTinh,String soDienThoai,String soThich,int tinhTrang,String anh,String ngayThamGia){
		DataBaseDatDN db = new DataBaseDatDN();
		SimpleDateFormat sp = new SimpleDateFormat("yyyy/mm/dd");
		try{
			Statement stmt = db.getConnect().createStatement();
			{
				String sql ="Insert into TAIKHOAN(MaTK,MatKhau,LoaiTaiKhoan,HoTen,Email,DiaChi,NgaySinh,GioiTinh,SoDienThoai,SoThich,TinhTrang,Anh,NgayThamGia) "
						+ "values('"+maTK+"','"+matKhau+"','0',N'"+hoTen+"',N'"+email+"',N'"+diaChi+"',N'"+ngaySinh+"',N'"+gioiTinh+"',N'"+soDienThoai+"',N'"+soThich+"',N'"+tinhTrang+"',N'"+anh+"',GETDATE())";
				System.out.println("" + sql);
				System.out.println("Tao Tai Khoan Thanh Cong!!!");
				stmt.executeUpdate(sql);
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Loi cau lenh SQL!!!");
		}
	 return false;
	}
}
