package model.dao;

import java.sql.Statement;
import java.text.SimpleDateFormat;
/**
 * ThemMoiBaiVietDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemMoiBaiVietDAO {

	public boolean themMoiBaiViet(String textTieuDeBaiViet,
			int maDanhMuc, String textDiaChi, String textMoTa, String textEditor, String anh1,String anh2,String anh3) {
		DataBaseDatDN db = new DataBaseDatDN();
		SimpleDateFormat sp = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("mejjjjjjj");
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql ="Insert into BAIVIET (TieuDe,MaTK,MaDanhMuc,DiaChiBaiViet,MoTa,NoiDung,HinhAnh1,HinhAnh2,HinhAnh3,NgayDang,Duyet,LuotXem,LuotThich,LuotKhongThich,DanhGiaTrungBinh)  values (N'"+textTieuDeBaiViet+"',N'datdn','"+maDanhMuc+"',N'"+textDiaChi+"',N'"+textMoTa+"',N'"+textEditor+"','"+anh1+"','"+anh2+"','"+anh3+"',GETDATE(),1,0,0,0,0)";
				
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
}
