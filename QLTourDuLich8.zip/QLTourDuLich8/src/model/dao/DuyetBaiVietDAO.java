package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.bean.BaiViet;
/**
 * DuyetBaiVietDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class DuyetBaiVietDAO {

	public BaiViet getduyetBaiViet(int maBaiViet) {
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		BaiViet baiViet = new BaiViet();
		String sql = "SELECT * FROM BAIVIET WHERE MaBV = '"+ maBaiViet+"'";
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				baiViet.setNoiDung(rs.getString("NoiDung"));
				baiViet.setNgayDang(rs.getDate("NgayDang"));
				baiViet.setDuyet(rs.getString("Duyet"));
				baiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
			}
			return baiViet;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
	}


