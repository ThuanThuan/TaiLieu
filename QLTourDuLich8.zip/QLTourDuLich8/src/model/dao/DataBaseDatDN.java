package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * DataBaseDatDN.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DataBaseDatDN {
	private Connection connect;

	public Connection getConnect() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			Connection connect = DriverManager.getConnection(
					"jdbc:sqlserver://localhost:1433;databaseName=MockProject3",
					"sa", "12345678");
			System.out.println("ket noi thanh cong");
			return connect;

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Ket noi that bai");
			return null;
		}
	}
	public ResultSet executeQuery(String sql){
        try {
              Statement st=connect.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
              return st.executeQuery(sql);
              
        } catch (SQLException ex) {
              ex.printStackTrace();
              return null;
        }
  }

	public void closedConnect() {
		try {
			if (connect != null) {
				connect.close();
			}
		} catch (Exception e) {

		}
		
	}
	
	public static void main(String[] args){
		
		System.out.println("xin chao");
	}
	
}
