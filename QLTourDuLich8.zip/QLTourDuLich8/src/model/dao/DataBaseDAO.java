package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * DataBaseDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DataBaseDAO {
	private Connection con;
	private Statement stm;

	/**
	 * Khá»Ÿi táº¡o Connection
	 * @param 
	 * @return 
	 */
	
	public DataBaseDAO() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager
					.getConnection(
							"jdbc:sqlserver://localhost:1433;databaseName=MockProject3",
							"sa", "12345678");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		if (con != null) {
			System.out.println("Connection is established !");
		} else
			System.out.println("Connection isn't established !");
		try {
			stm = con.createStatement();
			System.out.println("Statement is established !");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Ä�Ã³ng Connection
	 * @param 
	 * @return 
	 */
	
	public void closeConnection() {
		try {
			stm.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Truy váº¥n csdl
	 * @param sql
	 * @return ResultSet
	 */
	
	public ResultSet getResultSet(String sql) {
		try {
			return stm.executeQuery(sql);
		} catch (Exception e) {
			System.out.println("Lá»—i truy váº¥n");
			return null;
		}
	}

	/**
	 * Cáº­p nháº­t csdl
	 * @param sql
	 * @return boolean
	 */
	
	public boolean updateData(String sql) {
		try {
			return stm.executeUpdate(sql) != 0;
		} catch (Exception e) {
			System.out.println("Execute update error!");
			return false;
		}
	}
}
