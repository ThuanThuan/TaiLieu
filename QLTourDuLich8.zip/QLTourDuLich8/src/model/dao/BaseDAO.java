package model.dao;

import java.sql.*;
/**
 * BaseDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class BaseDAO {
	Connection con = null;

	public Connection getconnection() {
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager
					.getConnection(
							"jdbc:sqlserver://localhost:1433;databaseName=MockProject3",
							"sa", "12345678");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}

	public void closeconnection() {
		try {
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public ResultSet executeQuery(String sql) {
		try {
			Statement st = con.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			return st.executeQuery(sql);
		} catch (SQLException ex) {
			ex.printStackTrace();
			return null;
		}
		
	}
	public int executeUpdate(String sql){	
		try {
			Statement  st= con.createStatement();
			return st.executeUpdate(sql);
		} catch (SQLException ex) {
			ex.printStackTrace();
			return -1;
		}
		
		
	}

	public static void main(String[] args) {
		BaseDAO base = new BaseDAO();
		base.getconnection();
	}

}
