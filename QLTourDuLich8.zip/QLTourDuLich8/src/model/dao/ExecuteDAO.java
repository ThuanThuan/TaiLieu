package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * ExecuteDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ExecuteDAO extends BaseDAO {
	public boolean kiemTraDangNhap(String tenDangNhap, String matKhau) {
		// TODO Auto-generated method stub\
		Connection con=getconnection();
		String sql="select * from TAIKHOAN";
		try {
			Statement statemet=con.createStatement();
			ResultSet result=statemet.executeQuery(sql);
			
			while(result.next()){
				
				if(tenDangNhap.equals(result.getString(1))&&matKhau.equals(result.getString(2)))
					return true;
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
	public boolean capNhatMatKhau(String matKhauMoi, String tenDangNhap) {
		// TODO Auto-generated method stub
		Connection con=getconnection();
		String sql=String.format("update TAIKHOAN set MatKhau=N'%s' where MaTK=N'%s'",matKhauMoi,tenDangNhap);
		try {
			Statement statemet=con.createStatement();
			statemet.executeUpdate(sql);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	public boolean capNhatThongTin(String hoTen, String tenDangNhap,
			String email, String diaChi, String ngaySinh, int gioiTinh,
			String soDienThoai, String soThich, String anh) {
		// TODO Auto-generated method stub
		Connection con=getconnection();
		String sql=String.format("update TAIKHOAN set HoTen=N'%s',Email=N'%s',DiaChi=N'%s',NgaySinh='%s',GioiTinh=N'%s',SoDienThoai='%s',soThich=N'%s',Anh=N'%s' where MaTK=N'%s'",hoTen,email,diaChi,ngaySinh,gioiTinh,soDienThoai,soThich,anh,tenDangNhap);
		try {
			Statement statemet=con.createStatement();
			statemet.executeUpdate(sql);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return false;
	}

	public boolean dangKytaiKhoan(String hoTen, String matKhau,
			String tenDangNhap, String email, String diaChi, String ngaySinh,
			String gioiTinh, String soDienThoai, String soThich, String anh, String ngayThamGia) {
		// TODO Auto-generated method stub
		Connection con=getconnection();
		ResultSet result=null;
		String sql=String.format("select * from TAIKHOAN where MaTK=N'%s'",tenDangNhap);
		System.out.println(sql);
		try {
			Statement statemet=con.createStatement();
			result=statemet.executeQuery(sql);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e+"ssssssssss");
		}
		try {
			if(!result.next()){
			sql=String.format("insert into TAIKHOAN values (N'%s',N'%s',N'%s',N'%s',N'%s',N'%s',%s,N'%s',N'%s',N'%s',N'%s',N'%s','%s')",tenDangNhap,matKhau,0,hoTen,email,diaChi,ngaySinh,gioiTinh,soDienThoai,soThich,0,anh,ngayThamGia);
			System.out.println(sql);
			try {
				Statement statemet=con.createStatement();
				statemet.executeUpdate(sql);
				return true;
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public void xoaBV(int maBV) {
		// TODO Auto-generated method stub
		Connection con=getconnection();
		String sql=String.format("delete from BAIVIET where MaBV='%s'",maBV);
		System.out.println(sql);
		try {
			Statement sta=con.createStatement();
			sta.executeUpdate(sql);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
}
