package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.DanhMuc;
import model.bean.DanhMucTour;
import model.bean.TourDuLich;
/**
 * DanhMucDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DanhMucDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=MockProject3";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
		
	}
	public ArrayList<DanhMucTour> getListDM() {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from DANHMUC");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<DanhMucTour> list = new ArrayList<DanhMucTour>();
		DanhMucTour DanhMucTour;
		try {
			while(rs.next()){
				DanhMucTour = new DanhMucTour();

				DanhMucTour.setMaDanhMuc(rs.getString("MaDanhMuc"));
				DanhMucTour.setTenDanhMuc(rs.getString("TenLoaiTour"));
				list.add(DanhMucTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DanhMucTour> getDanhMuc(String maDanhMuc) {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from TOURDULICH where MaDanhMuc='"+maDanhMuc+"' ");
		System.out.println(sql);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DanhMucTour> list = new ArrayList<DanhMucTour>();
		DanhMucTour danhSachTour;
		try {
			while(rs.next()){
				danhSachTour = new DanhMucTour();
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setMaKhuyenMai(rs.getString("MaKhuyenMai"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getString("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
				list.add(danhSachTour);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	DataBaseDAO db = new DataBaseDAO();
	public ArrayList<DanhMuc> getListDanhMuc() {
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		ArrayList<DanhMuc> list = new ArrayList<DanhMuc>();
		DanhMuc listDanhMuc;
		String sql = "SELECT MaDanhMuc,TenLoaiTour,MoTaDanhMuc FROM DANHMUC";

		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()){
				listDanhMuc = new DanhMuc();
				listDanhMuc.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				listDanhMuc.setTenDanhMuc(rs.getString("TenLoaiTour"));
				listDanhMuc.setMoTa(rs.getString("MoTaDanhMuc"));
				list.add(listDanhMuc);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}
		return null;
	}
	public ArrayList<DanhMuc> getDanhSachDanhMuc(String txtFind) {
		txtFind = FormatData.FormatInputData(txtFind);
		String sql = "select * from DANHMUC where  MaDanhMuc like N'%"+txtFind
			+"' or TenLoaiTour like N'%"+txtFind+"%'";
		ResultSet rs = db.getResultSet(sql);
		ArrayList<DanhMuc> list = null;
		try {
			list = new ArrayList<DanhMuc>();
			while(rs.next()){
				DanhMuc danhMuc = new DanhMuc();
				danhMuc.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				danhMuc.setTenDanhMuc(rs.getString("TenLoaiTour"));
				danhMuc.setMoTa(rs.getString("MoTaDanhMuc"));
				list.add(danhMuc);
			}
		} catch (SQLException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
		return list;
	}
	public boolean themDanhMucMonAnMoi(String tenMonMoi,String moTaDanhMuc,String moTa) {

		String sql="insert into DANHMUC(TenLoaiTour,MoTaDanhMuc) values(N'"+tenMonMoi+"',N'"+moTa+"')";
		try {
			System.out.println(""+sql);
			return db.updateData(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
		}		
		return false;
	}
	public int getMaxID(String columName, String tableName){
		String sql="select "+columName+" "+ 
				" from "+tableName+" " +
				" where "+columName+" >= all (select "+columName+" from "+ tableName+")";
		ResultSet rs=db.getResultSet(sql);
		try {
			int max=0;
			while(rs.next()){
				max=Integer.valueOf(rs.getString(1));				
			}
			return max;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * xÃ³a danh má»¥c mÃ³n Äƒn Ä‘Æ°á»£c chá»�n tá»« quáº£n trá»‹ viÃªn
	 * @param maDanhMuc
	 * @return true/false
	 */
	
	public boolean deleteDanhMucMonAn(int maDanhMuc) {
		return db.updateData("delete from DANHMUC where MaDanhMuc='"+maDanhMuc+"'");

	}

	/**
	 * láº¥y tÃªn danh má»¥c mÃ³n Äƒn
	 * @param maMonAnChinhSua
	 * @return tenMonAn
	 */
	
	public String getTenMonAn(int maMonAnChinhSua) {
		String sql="select MaDanhMuc,TenLoaiTour,MoTaDanhMuc from DANHMUC where MaDanhMuc="+maMonAnChinhSua+"";
		ResultSet rs= db.getResultSet(sql);
		ArrayList<DanhMuc> list = null;
		try {
			list = new ArrayList<DanhMuc>();
			while(rs.next()){
				DanhMuc danhMuc = new DanhMuc();
				danhMuc.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				danhMuc.setTenDanhMuc(rs.getString("TenLoaiTour"));
				danhMuc.setMoTa(rs.getString("MoTaDanhMuc"));
				list.add(danhMuc);
			}
		}catch(Exception e){
				return null;
			}
		return sql;
		
		
	}
     
	public DanhMuc getThongTinDanhMuc(int maDanhMuc){
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		DanhMuc listDanhMuc = new DanhMuc();
		String sql = "SELECT * FROM DANHMUC WHERE MaDanhMuc = '"+ maDanhMuc+"'";
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listDanhMuc.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				
				listDanhMuc.setTenDanhMuc(rs.getString("TenLoaiTour"));
				listDanhMuc.setMoTa(rs.getString("MoTaDanhMuc"));
				
			}
			return listDanhMuc;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
	/**
	 * Cáº­p nháº­t tÃªn danh má»¥c mÃ³n Äƒn
	 * @param maMonAnChinhSua,tenMonAnMoi
	 * @return true/false
	 */
	
	public boolean capNhatTenMonAn(int maMonAnChinhSua,
			String tenMonAnMoi,String moTaDanhMuc) {
		String sql="update DANHMUC set TenLoaiTour=N'"+tenMonAnMoi+"',MoTaDanhMuc=N'"+moTaDanhMuc+"' " +
				" where MaDanhMuc='"+maMonAnChinhSua+"'";
		return db.updateData(sql);
	}
	

}
