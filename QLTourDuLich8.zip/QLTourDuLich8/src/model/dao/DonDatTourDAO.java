package model.dao;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import model.bean.*;
/**
 * DonDatTourDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DonDatTourDAO {
	public ArrayList<DonDatTour> getDonDatTour(String txtFind) {
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT d.*,t.TenTour,k.HoTen"
		+ " FROM DATTOURDULICH d"
		+ " INNER JOIN TOURDULICH as t"
		+ " ON d.MaTour = t.MaTour join TAIKHOAN as k ON d.MaTK=k.MaTK" ;
		System.out.println(sql);
		ArrayList<DonDatTour> list = new ArrayList<DonDatTour>();
		DonDatTour listDatTour;
		try {
		Statement st = (Statement) dataBase.getConnect().createStatement();
		rs = ((java.sql.Statement) st).executeQuery(sql);
		while (rs.next()) {
		listDatTour = new DonDatTour();
		listDatTour.setMaDatTour(rs.getInt("MaDatTour"));
		listDatTour.setMaTour(rs.getInt("MaTour"));
		listDatTour.setSoNguoiLon(rs.getInt("SoNguoiLon"));
		listDatTour.setSoTreEm(rs.getInt("SoTreEm"));
		listDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
		listDatTour.setTongSoTien(rs.getInt("TongSoTien"));
		listDatTour.setHoTenNguoiDat(rs.getString("HoTenNguoiDat"));
		listDatTour.setSoDienThoai(rs.getString("SoDienThoai"));
		listDatTour.setEmail(rs.getString("Email"));
		listDatTour.setYeuCau(rs.getString("YeuCau"));
		listDatTour.setMaTK(rs.getString("MaTK"));
		listDatTour.setTenTour(rs.getString("TenTour"));
		listDatTour.setTenTK(rs.getString("HoTen"));
		listDatTour.setQueQuan(rs.getString("QueQuan"));
		listDatTour.setTinhTrang(rs.getString("TinhTrang"));
		list.add(listDatTour);
		}
		return list;
		} catch (Exception e) {
		e.printStackTrace();
		} finally {
		dataBase.closedConnect();
		}
		return null;
		}
	public ArrayList<DonDatTour> getDonDatTourMoi(String txtFind){
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT d.*,t.TenTour,k.HoTen"
		+ " FROM DATTOURDULICH d"
		+ " INNER JOIN TOURDULICH as t"
		+ " ON d.MaTour = t.MaTour join TAIKHOAN as k ON d.MaTK=k.MaTK where t.TenTour=N'%"+txtFind+"%'" ;
		System.out.println(sql);
		ArrayList<DonDatTour> list = new ArrayList<DonDatTour>();
		DonDatTour listDatTour;
		try {
		Statement st = (Statement) dataBase.getConnect().createStatement();
		rs = ((java.sql.Statement) st).executeQuery(sql);
		while (rs.next()) {
		listDatTour = new DonDatTour();
		listDatTour.setMaDatTour(rs.getInt("MaDatTour"));
		listDatTour.setMaTour(rs.getInt("MaTour"));
		listDatTour.setSoNguoiLon(rs.getInt("SoNguoiLon"));
		listDatTour.setSoTreEm(rs.getInt("SoTreEm"));
		listDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
		listDatTour.setTongSoTien(rs.getInt("TongSoTien"));
		listDatTour.setHoTenNguoiDat(rs.getString("HoTenNguoiDat"));
		listDatTour.setSoDienThoai(rs.getString("SoDienThoai"));
		listDatTour.setEmail(rs.getString("Email"));
		listDatTour.setYeuCau(rs.getString("YeuCau"));
		listDatTour.setMaTK(rs.getString("MaTK"));
		listDatTour.setTenTour(rs.getString("TenTour"));
		listDatTour.setTenTK(rs.getString("HoTen"));
		listDatTour.setQueQuan(rs.getString("QueQuan"));
		listDatTour.setTinhTrang(rs.getString("TinhTrang"));
		listDatTour.setGiaTour(rs.getInt("GiaTour"));
		list.add(listDatTour);
		}
		return list;
		} catch (Exception e) {
		e.printStackTrace();
		} finally {
		dataBase.closedConnect();
		}
		return null;
	}
	public boolean deleteDatTour(int maDatTour) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "Delete From DATTOURDULICH WHERE MaDatTour ='" + maDatTour+ "'";
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	public DonDatTour getThongTinTour(int maDatTour){
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		DonDatTour listDatTour = new DonDatTour();
		String sql ="SELECT d.*,t.*,k.*"
				+ " FROM DATTOURDULICH d"
				+ " INNER JOIN TOURDULICH as t"
				+ " ON d.MaTour = t.MaTour join TAIKHOAN as k ON d.MaTK=k.MaTK where maDatTour='"+maDatTour+"'" ;
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listDatTour = new DonDatTour();
				listDatTour.setMaDatTour(rs.getInt("MaDatTour"));
				listDatTour.setMaTour(rs.getInt("MaTour"));
				listDatTour.setSoNguoiLon(rs.getInt("SoNguoiLon"));
				listDatTour.setSoTreEm(rs.getInt("SoTreEm"));
				listDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
				listDatTour.setTongSoTien(rs.getInt("TongSoTien"));
				listDatTour.setHoTenNguoiDat(rs.getString("HoTenNguoiDat"));
				listDatTour.setSoDienThoai(rs.getString("SoDienThoai"));
				listDatTour.setEmail(rs.getString("Email"));
				listDatTour.setYeuCau(rs.getString("YeuCau"));
				listDatTour.setMaTK(rs.getString("MaTK"));
				listDatTour.setTenTour(rs.getString("TenTour"));
				listDatTour.setTenTK(rs.getString("HoTen"));
				listDatTour.setQueQuan(rs.getString("QueQuan"));
				listDatTour.setTinhTrang(rs.getString("TinhTrang"));
				listDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
				listDatTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				listDatTour.setDiemDen(rs.getString("DiemDen"));
				listDatTour.setPhuongTien(rs.getString("PhuongTien"));
				listDatTour.setThoiGian(rs.getString("ThoiGian"));
				listDatTour.setGiaTour(rs.getInt("GiaTour"));
				listDatTour.setGiaTourSau(rs.getInt("GiaTourSau"));
			}
			return listDatTour;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
	public boolean updateDonDatTour(int maDatTour,int maTour,int soNguoiLon,int soTreEm,String thoiGianKhoiHanh,int tongSoTien,String hoTenNguoiDat,String sDT,String email,String yeuCau) {
			DataBaseDatDN db = new DataBaseDatDN();
			SimpleDateFormat sp =  new SimpleDateFormat("dd/MM/yyyy");
			try {
				Statement st = db.getConnect().createStatement();
				{
					String sql= "update DATTOURDULICH set MaTour='"+maTour+"',SoNguoiLon =N'"+soNguoiLon+"',SoTreEm ='"+soTreEm+"',ThoiGianKhoiHanh=N'"+thoiGianKhoiHanh+"'," +
							"TongSoTien= N'"+tongSoTien+"', HoTenNguoiDat = N'"+hoTenNguoiDat+"',SoDienThoai = N'"+sDT+"',Email = N'"+email+"',YeuCau = N'"+yeuCau+"'  WHERE MaDatTour = '"+maDatTour+"'" ;
					
					System.out.print("SQL: "+sql);
					st.executeUpdate(sql);
				}
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}

			return false;
		}
	public boolean themDonDatTour(int maTour,int soNguoiLon,int soTreEm,String thoiGianKhoiHanh,int tongSoTien,String hoTenNguoiDat,String soDienThoai,String email,String yeuCau,String maTK,String queQuan,String tinhTrang){
        DataBaseDatDN db = new DataBaseDatDN();
         tinhTrang ="Chưa Thanh Toán";
        try{
               Statement st = db.getConnect().createStatement();
               {
                     String sql ="Insert into DATTOURDULICH(MaTour,SoNguoiLon,SoTreEm,ThoiGianKhoiHanh,TongSoTien,HoTenNguoiDat,SoDienThoai,Email,YeuCau,MaTK,QueQuan,TinhTrang) values('"+maTour+"','"+soNguoiLon+"',N'"+soTreEm+"',N'"+thoiGianKhoiHanh+"',N'"+tongSoTien+"',N'"+hoTenNguoiDat+"',N'"+soDienThoai+"',N'"+email+"',N'"+yeuCau+"',N'"+maTK+"',N'"+queQuan+"',N'"+tinhTrang+"')";
                     System.out.println("SQL:" + sql);
                     st.executeUpdate(sql);
               }
               
        }catch(Exception e){
               e.printStackTrace();
        }
          return false;
 }
	public ArrayList<DanhSachTour> getTourDuLich(int maTour) {
		// TODO Auto-generated method stub
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		
	
		String sql=	String.format("select * from TOURDULICH where MaTour='"+maTour+"' ");
	
		try {
			Statement stmt = db.getConnect().createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<DanhSachTour> list = new ArrayList<DanhSachTour>();
		DanhSachTour danhSachTour;
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setMoTa(rs.getString("MoTa"));
				danhSachTour.setLichTrinh(rs.getString("LichTrinh"));
				danhSachTour.setPhuongTien(rs.getString("PhuongTien"));
				danhSachTour.setThoiGian(rs.getString("ThoiGian"));
				danhSachTour.setHinhThuc(rs.getString("HinhThuc"));
			    danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
			    
				list.add(danhSachTour);
			}
		System.out.print(list.size());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<DonDatTour> getDonTourDuLich( int maDatTour) {
        DataBaseDatDN db = new DataBaseDatDN();
        ResultSet rs = null;
        
 
        String sql=   String.format("select d.*,t.*,tk.* from DATTOURDULICH d inner join TOURDULICH as t on d.MaTour=t.MaTour join TAIKHOAN tk on d.MaTK=tk.MaTK where MaDatTour='"+maDatTour+"' ");
     System.out.println(sql);
        try {
               Statement stmt = db.getConnect().createStatement();
               rs = stmt.executeQuery(sql);
        } catch (SQLException e) {
               e.printStackTrace();
        }
        
        ArrayList<DonDatTour> list = new ArrayList<DonDatTour>();
        DonDatTour donDatTour;
        try {
               while(rs.next()){
                     donDatTour = new DonDatTour();
                     donDatTour.setMaDatTour(rs.getInt("MaDatTour"));
                     donDatTour.setMaTour(rs.getInt("MaTour"));
                     donDatTour.setSoNguoiLon(rs.getInt("SoNguoiLon"));
                     donDatTour.setSoTreEm(rs.getInt("SoTreEm"));
                     donDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
                     donDatTour.setTongSoTien(rs.getInt("TongSoTien"));
                     donDatTour.setHoTenNguoiDat(rs.getString("HoTenNguoiDat"));
                     donDatTour.setSoDienThoai(rs.getString("SoDienThoai"));
                     donDatTour.setEmail(rs.getString("Email"));
                     donDatTour.setYeuCau(rs.getString("YeuCau"));
                     donDatTour.setMaTK(rs.getString("MaTK"));
                     donDatTour.setHinhThuc(rs.getString("HinhThuc"));
                     donDatTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
                     donDatTour.setPhuongTien(rs.getString("PhuongTien"));
                     donDatTour.setThoiGian(rs.getString("ThoiGian"));
                     donDatTour.setTenTour(rs.getString("TenTour"));
                     donDatTour.setQueQuan(rs.getString("QueQuan"));
                     donDatTour.setTinhTrang(rs.getString("TinhTrang"));
               
                     list.add(donDatTour);
               }
        System.out.print(list.size());
        } catch (SQLException e) {
               e.printStackTrace();
        }
        return list;
 }
	public ArrayList<DonDatTour> getDonTourDuLich() {
		// TODO Auto-generated method stub
		   DataBaseDatDN db = new DataBaseDatDN();
	        ResultSet rs = null;
	        
	 
	        String sql=   String.format("select TOP 1 d.*,t.*,tk.* from DATTOURDULICH d inner join TOURDULICH as t on d.MaTour=t.MaTour join TAIKHOAN tk on d.MaTK=tk.MaTK order by MaDatTour DESC  ");
	     System.out.println(sql);
	        try {
	               Statement stmt = db.getConnect().createStatement();
	               rs = stmt.executeQuery(sql);
	        } catch (SQLException e) {
	               e.printStackTrace();
	        }
	        
	        ArrayList<DonDatTour> list = new ArrayList<DonDatTour>();
	        DonDatTour donDatTour;
	        try {
	               while(rs.next()){
	                     donDatTour = new DonDatTour();
	                     donDatTour.setMaDatTour(rs.getInt("MaDatTour"));
	                     donDatTour.setMaTour(rs.getInt("MaTour"));
	                     donDatTour.setSoNguoiLon(rs.getInt("SoNguoiLon"));
	                     donDatTour.setSoTreEm(rs.getInt("SoTreEm"));
	                     donDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
	                     donDatTour.setTongSoTien(rs.getInt("TongSoTien"));
	                     donDatTour.setHoTenNguoiDat(rs.getString("HoTenNguoiDat"));
	                     donDatTour.setSoDienThoai(rs.getString("SoDienThoai"));
	                     donDatTour.setEmail(rs.getString("Email"));
	                     donDatTour.setYeuCau(rs.getString("YeuCau"));
	                     donDatTour.setMaTK(rs.getString("MaTK"));
	                     donDatTour.setHinhThuc(rs.getString("HinhThuc"));
	                     donDatTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
	                     donDatTour.setPhuongTien(rs.getString("PhuongTien"));
	                     donDatTour.setThoiGian(rs.getString("ThoiGian"));
	                     donDatTour.setTenTour(rs.getString("TenTour"));
	                     donDatTour.setQueQuan(rs.getString("QueQuan"));
	                     donDatTour.setDiemDen(rs.getString("DiemDen"));
	                     donDatTour.setTinhTrang(rs.getString("TinhTrang"));
	                     donDatTour.setGiaTourSau(rs.getInt("GiaTourSau"));
	                     int giaTreEm=((rs.getInt("GiaTourSau")/2)*(rs.getInt("SoTreEm")));
	                     donDatTour.setGiaTienTreEm(giaTreEm);
	                     int giaNguoiLon=(rs.getInt("GiaTourSau")*(rs.getInt("SoNguoiLon")));
	                     donDatTour.setGiaTienNguoiLon(giaNguoiLon);
	                     list.add(donDatTour);
	               }
	        System.out.print(list.size());
	        } catch (SQLException e) {
	               e.printStackTrace();
	        }
	        return list;
	}
	public ArrayList<DonDatTour> getDonTourDuLichTaiKhoan(String maTK) {
		// TODO Auto-generated method stub
		   DataBaseDatDN db = new DataBaseDatDN();
	        ResultSet rs = null;
	        
	 
	        String sql=   String.format("select dt.*,t.* from DATTOURDULICH dt inner join TOURDULICH as t on dt.MaTour=t.MaTour where dt.MaTK='"+maTK+"' ");
	         System.out.println(sql);
	        try {
	               Statement stmt = db.getConnect().createStatement();
	               rs = stmt.executeQuery(sql);
	        } catch (SQLException e) {
	               e.printStackTrace();
	        }
	        
	        ArrayList<DonDatTour> list = new ArrayList<DonDatTour>();
	        DonDatTour donDatTour;
	        try {
	               while(rs.next()){
	                     donDatTour = new DonDatTour();
	                     donDatTour.setMaDatTour(rs.getInt("MaDatTour"));
	                     donDatTour.setMaTour(rs.getInt("MaTour"));
	                     donDatTour.setSoNguoiLon(rs.getInt("SoNguoiLon"));
	                     donDatTour.setSoTreEm(rs.getInt("SoTreEm"));
	                     donDatTour.setThoiGianKhoiHanh(rs.getString("ThoiGianKhoiHanh"));
	                     donDatTour.setTongSoTien(rs.getInt("TongSoTien"));
	                     donDatTour.setHoTenNguoiDat(rs.getString("HoTenNguoiDat"));
	                     donDatTour.setSoDienThoai(rs.getString("SoDienThoai"));
	                     donDatTour.setEmail(rs.getString("Email"));
	                     donDatTour.setYeuCau(rs.getString("YeuCau"));
	                     donDatTour.setMaTK(rs.getString("MaTK"));
	                     donDatTour.setHinhThuc(rs.getString("HinhThuc"));
	                     donDatTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
	                     donDatTour.setPhuongTien(rs.getString("PhuongTien"));
	                     donDatTour.setThoiGian(rs.getString("ThoiGian"));
	                     donDatTour.setTenTour(rs.getString("TenTour"));
	                     donDatTour.setQueQuan(rs.getString("QueQuan"));
	                     donDatTour.setDiemDen(rs.getString("DiemDen"));
	                     donDatTour.setTinhTrang(rs.getString("TinhTrang"));
	                     list.add(donDatTour);
	               }
	        System.out.print(list.size());
	        } catch (SQLException e) {
	               e.printStackTrace();
	        }
	        return list;
	}
	public boolean updateDonDatTour1(String tinhTrang,int maDatTour) {
		DataBaseDatDN db = new DataBaseDatDN();
		SimpleDateFormat sp =  new SimpleDateFormat("dd/MM/yyyy");
		tinhTrang ="Ðã Thanh Toán";
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql= "Update DATTOURDULICH set TinhTrang=N'"+tinhTrang+"' where maDatTour ='"+maDatTour+"'" ;
				
				System.out.print("SQL: "+sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	public DanhSachTour getTourDuLich1(int maTour) {
		// TODO Auto-generated method stub
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		
	
		String sql=	String.format("select * from TOURDULICH where MaTour='"+maTour+"' ");
	
		try {
			Statement stmt = db.getConnect().createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DanhSachTour danhSachTour;
		try {
			while(rs.next()){
				danhSachTour = new DanhSachTour();
				
				danhSachTour.setMatour(rs.getString("MaTour"));
				danhSachTour.setTenTour(rs.getString("TenTour"));
				danhSachTour.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				danhSachTour.setGiaTour(rs.getInt("GiaTour"));
				danhSachTour.setHinhAnh1(rs.getString("HinhAnh1"));
				danhSachTour.setMoTa(rs.getString("MoTa"));
				danhSachTour.setLichTrinh(rs.getString("LichTrinh"));
				danhSachTour.setPhuongTien(rs.getString("PhuongTien"));
				danhSachTour.setThoiGian(rs.getString("ThoiGian"));
				danhSachTour.setHinhThuc(rs.getString("HinhThuc"));
			    danhSachTour.setGiaTourSau(rs.getInt("GiaTourSau"));
			    
				
				return danhSachTour;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	
}
