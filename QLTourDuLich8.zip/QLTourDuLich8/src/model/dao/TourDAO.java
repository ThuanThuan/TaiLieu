package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import model.bean.BaiViet;
import model.bean.TourDuLich;
/**
 * TourDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class TourDAO {
	public ArrayList<TourDuLich> getTenTour(String txtFind) {
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql ="Select * from TOURDULICH";
		System.out.println(sql);
		ArrayList<TourDuLich> list = new ArrayList<TourDuLich>();
		TourDuLich listTourDuLich;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listTourDuLich = new TourDuLich();
				listTourDuLich.setMaTour(rs.getInt("MaTour"));
				listTourDuLich.setTenTour(rs.getString("TenTour"));
				list.add(listTourDuLich);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;

	}
	public ArrayList<TourDuLich> getListTourDuLich(String txtFind) {
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT t.*,d.TenLoaiTour,k.TenKhuyenMai"
				+ " FROM TOURDULICH as t"
				+ " INNER JOIN DANHMUC as d"
				+ " ON t.MaDanhMuc = d.MaDanhMuc"
				+ " JOIN KHUYENMAI as k ON t.MaKhuyenMai=k.MaKhuyenMai";
		System.out.println(sql);
		ArrayList<TourDuLich> list = new ArrayList<TourDuLich>();
		TourDuLich listTourDuLich;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listTourDuLich = new TourDuLich();
				listTourDuLich.setMaTour(rs.getInt("MaTour"));
				listTourDuLich.setTenDanhMuc(rs.getString("TenLoaiTour"));
				listTourDuLich.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				listTourDuLich.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				listTourDuLich.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
				listTourDuLich.setTenTour(rs.getString("TenTour"));
				listTourDuLich.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				listTourDuLich.setThoiGian(rs.getString("ThoiGian"));
				listTourDuLich.setPhuongTien(rs.getString("PhuongTien"));
				listTourDuLich.setLichTrinh(rs.getString("LichTrinh"));
				listTourDuLich.setHinhThuc(rs.getString("HinhThuc"));
				listTourDuLich.setGiaTour(rs.getInt("GiaTour"));
				listTourDuLich.setAnh1(rs.getString("HinhAnh1"));
				listTourDuLich.setAnh2(rs.getString("HinhAnh2"));
				listTourDuLich.setAnh3(rs.getString("HinhAnh3"));
				listTourDuLich.setEmail(rs.getString("Email"));
				listTourDuLich.setMoTa(rs.getString("MoTa"));
				listTourDuLich.setDiemDen(rs.getString("DiemDen"));
				listTourDuLich.setGiaTourSau(rs.getInt("GiaTourSau"));
				list.add(listTourDuLich);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;

	}
	public ArrayList<TourDuLich> getListTourDuLichMoi(String txtFind) {
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT t.*,d.TenLoaiTour,k.TenKhuyenMai"
				+ " FROM TOURDULICH as t"
				+ " INNER JOIN DANHMUC as d"
				+ " ON t.MaDanhMuc = d.MaDanhMuc"
				+ " JOIN KHUYENMAI as k ON t.MaKhuyenMai=k.MaKhuyenMai where t.TenTour like N'%"+txtFind+"%'";
		System.out.println(sql);
		ArrayList<TourDuLich> list = new ArrayList<TourDuLich>();
		TourDuLich listTourDuLich;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listTourDuLich = new TourDuLich();
				listTourDuLich.setMaTour(rs.getInt("MaTour"));
				listTourDuLich.setTenDanhMuc(rs.getString("TenLoaiTour"));
				listTourDuLich.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				listTourDuLich.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				listTourDuLich.setTenKhuyenMai(rs.getString("TenKhuyenMai"));
				listTourDuLich.setTenTour(rs.getString("TenTour"));
				listTourDuLich.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				listTourDuLich.setThoiGian(rs.getString("ThoiGian"));
				listTourDuLich.setPhuongTien(rs.getString("PhuongTien"));
				listTourDuLich.setLichTrinh(rs.getString("LichTrinh"));
				listTourDuLich.setHinhThuc(rs.getString("HinhThuc"));
				listTourDuLich.setGiaTour(rs.getInt("GiaTour"));
				listTourDuLich.setAnh1(rs.getString("HinhAnh1"));
				listTourDuLich.setAnh2(rs.getString("HinhAnh2"));
				listTourDuLich.setAnh3(rs.getString("HinhAnh3"));
				listTourDuLich.setEmail(rs.getString("Email"));
				listTourDuLich.setMoTa(rs.getString("MoTa"));
				listTourDuLich.setDiemDen(rs.getString("DiemDen"));
				listTourDuLich.setGiaTourSau(rs.getInt("GiaTourSau"));
				list.add(listTourDuLich);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;

	}
	public boolean themTourDuLich(int maDanhMuc,int maKhuyenMai,String tenTour,String diemKhoiHanh,String thoiGian,String phuongTien,String lichTrinh,String hinhThuc,int giaTour,String hinhAnh1,String hinhAnh2,String hinhAnh3,String email,String moTa,String diemDen,int giaTourSau){
		DataBaseDatDN db = new DataBaseDatDN();
		try{
			Statement st = db.getConnect().createStatement();
			{
				String sql ="Insert into TOURDULICH(MaDanhMuc,MaKhuyenMai,TenTour,DiemKhoiHanh,ThoiGian,PhuongTien,LichTrinh,HinhThuc,GiaTour,HinhAnh1,HinhAnh2,HinhAnh3,Email,MoTa,LuotThich,LuotKhongThich,DanhGiaTrungBinh,DiemDen,GiaTourSau) values('"+maDanhMuc+"','"+maKhuyenMai+"',N'"+tenTour+"',N'"+diemKhoiHanh+"',N'"+thoiGian+"',N'"+phuongTien+"',N'"+lichTrinh+"',N'"+hinhThuc+"',N'"+giaTour+"',N'"+hinhAnh1+"',N'"+hinhAnh2+"',N'"+hinhAnh3+"',N'"+email+"',N'"+moTa+"',0,0,0,N'"+diemDen+"','"+giaTourSau+"')";
				System.out.println("SQL:" + sql);
				st.executeUpdate(sql);
				System.out.print(sql);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	 return false;
	}
	public boolean deleteTourDuLich(int maTour) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "Delete From TOURDULICH WHERE MaTour ='" + maTour+ "'";
				System.out.print("SQL: " + sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	public TourDuLich getThongTinTour(int maTour){
		DataBaseDatDN db = new DataBaseDatDN();
		ResultSet rs = null;
		TourDuLich listTourDuLich = new TourDuLich();
		String sql = "SELECT * FROM TOURDULICH WHERE MaTour = '"+ maTour+"'";
		System.out.println(sql);
		try {
			Statement st = db.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listTourDuLich.setMaTour(rs.getInt("MaTour"));
				listTourDuLich.setMaDanhMuc(rs.getInt("MaDanhMuc"));
				listTourDuLich.setMaKhuyenMai(rs.getInt("MaKhuyenMai"));
				listTourDuLich.setTenTour(rs.getString("TenTour"));
				listTourDuLich.setDiemKhoiHanh(rs.getString("DiemKhoiHanh"));
				listTourDuLich.setThoiGian(rs.getString("ThoiGian"));
				listTourDuLich.setPhuongTien(rs.getString("PhuongTien"));
				listTourDuLich.setLichTrinh(rs.getString("LichTrinh"));
				listTourDuLich.setHinhThuc(rs.getString("HinhThuc"));
				listTourDuLich.setGiaTour(rs.getInt("GiaTour"));
				listTourDuLich.setAnh1(rs.getString("HinhAnh1"));
				listTourDuLich.setAnh2(rs.getString("HinhAnh2"));
				listTourDuLich.setAnh3(rs.getString("HinhAnh3"));
				listTourDuLich.setEmail(rs.getString("Email"));
				listTourDuLich.setTextEditor(rs.getString("MoTa"));
				listTourDuLich.setDiemDen(rs.getString("DiemDen"));
				listTourDuLich.setGiaTourSau(rs.getInt("GiaTourSau"));
			}
			return listTourDuLich;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closedConnect();
		}

		return null;
	}
	public boolean updateTourDuLich(int maTour,int maDanhMuc,int maKhuyenMai,String tenTour,String diemKhoiHanh,String thoiGian,String phuongTien,String lichTrinh,String hinhThuc,int giaTour,String hinhAnh1,String hinhAnh2,String hinhAnh3,String email,String moTa,String diemDen,int giaTourSau) {
			DataBaseDatDN db = new DataBaseDatDN();
			SimpleDateFormat sp =  new SimpleDateFormat("dd/MM/yyyy");
			try {
				Statement st = db.getConnect().createStatement();
				{
					String sql= "update TOURDULICH set MaDanhMuc =N'"+maDanhMuc+"',MaKhuyenMai ='"+maKhuyenMai+"',TenTour=N'"+tenTour+"'," +
							"DiemKhoiHanh= N'"+diemKhoiHanh+"', ThoiGian = N'"+thoiGian+"',PhuongTien = N'"+phuongTien+"',LichTrinh = N'"+lichTrinh+"',HinhThuc = N'"+hinhThuc+"',GiaTour='"+giaTour+"',HinhAnh1='"+hinhAnh1+"',HinhAnh2='"+hinhAnh2+"',HinhAnh3='"+hinhAnh3+"',Email='"+email+"',MoTa=N'"+moTa+"',DiemDen=N'"+diemDen+"',GiaTourSau='"+giaTourSau+"'"
									+ " WHERE MaTour = '"+maTour+"'" ;
					
					System.out.print("SQL: "+sql);
					st.executeUpdate(sql);
				}
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}

			return false;
		}
}
