package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.ThongKe;
/**
 * ThongKeDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThongKeDAO {
	//Thong Ke Theo Ngay Tu Chon
	
		public ArrayList<ThongKe> getListTourHotTheoNgay(String ngayBatDau, String ngayKetThuc) {
			DataBaseDatDN db = new DataBaseDatDN();
			ResultSet rs = null;
			ArrayList<ThongKe> list = new ArrayList<ThongKe>();
			ThongKe listThongKe;
			String sql = String.format("select TOP 5 t.TenTour, (sum(SoNguoiLon+SoTreEm)) as SoLuongDat "
					+ "from DATTOURDULICH dt,TOURDULICH t "
					+ "where dt.MaTour=t.MaTour and ThoiGianKhoiHanh between '%s' and '%s' "
					+ "group by TenTour "
					+ "order by SoLuongDat desc",ngayBatDau,ngayKetThuc);

			try {
				Statement st = db.getConnect().createStatement();
				rs = st.executeQuery(sql);
				System.out.println(sql);
				while(rs.next()){
					listThongKe = new ThongKe();
					listThongKe.setLabel(rs.getString("tenTour"));
					listThongKe.setValue(rs.getInt("soLuongDat"));;
					list.add(listThongKe);
				}
				return list;
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Loi cau lenh SQL Tour Hot!!!");
			} finally {
				db.closedConnect();
			}
			return null;
		}
		
		public ArrayList<ThongKe> getListDiemKhoiHanhTheoNgay(String ngayBatDau, String ngayKetThuc) {
			DataBaseDatDN db = new DataBaseDatDN();
			ResultSet rs = null;
			ArrayList<ThongKe> list = new ArrayList<ThongKe>();
			ThongKe listDiemKhoiHanh;
			String sql = String.format("select QueQuan ,(sum(SoNguoiLon+SoTreEm)) as SoLuongKhach "
					+ "from DATTOURDULICH "
					+ "where ThoiGianKhoiHanh between '%s' and '%s' "
					+ "group by QueQuan "
					+ "order by SoLuongKhach desc",ngayBatDau,ngayKetThuc);

			try {
				Statement st = db.getConnect().createStatement();
				rs = st.executeQuery(sql);
				System.out.println(sql);
				while(rs.next()){
					listDiemKhoiHanh = new ThongKe();
					listDiemKhoiHanh.setLabel(rs.getString("queQuan"));
					listDiemKhoiHanh.setValue(rs.getInt("soLuongKhach"));;
					list.add(listDiemKhoiHanh);
				}
				return list;
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Loi cau lenh SQL Diem Khoi Hanh!!!");
			} finally {
				db.closedConnect();
			}
			return null;
		}
		
		public ArrayList<ThongKe> getListDoanhThuTheoNgay(String ngayBatDau, String ngayKetThuc) {
			DataBaseDatDN db = new DataBaseDatDN();
			ResultSet rs = null;
			ArrayList<ThongKe> list = new ArrayList<ThongKe>();
			ThongKe listTKDoanhThu;
			String sql = String.format("select sum(TongSoTien) as DoanhThu, month(ThoiGianKhoiHanh) as Thang,year(ThoiGianKhoiHanh) as Nam "
					+ "from DATTOURDULICH "
					+ "where ThoiGianKhoiHanh between '%s' and '%s' "
					+ "group by month(ThoiGianKhoiHanh),year(ThoiGianKhoiHanh) "
					+ "order by Nam",ngayBatDau,ngayKetThuc);

			try {
				Statement st = db.getConnect().createStatement();
				rs = st.executeQuery(sql);
				System.out.println(sql);
				while(rs.next()){
					listTKDoanhThu = new ThongKe();
					listTKDoanhThu.setLabel(rs.getString("thang")+"/"+rs.getString("nam"));
					listTKDoanhThu.setValue(rs.getInt("doanhThu"));;
					list.add(listTKDoanhThu);
				}
				return list;
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Loi cau lenh SQL Doanh Thu!!!");
			} finally {
				db.closedConnect();
			}
			return null;
		}
		
		public ArrayList<ThongKe> getListSoLuongDatTheoNgay(String ngayBatDau, String ngayKetThuc) {
			DataBaseDatDN db = new DataBaseDatDN();
			ResultSet rs = null;
			ArrayList<ThongKe> list = new ArrayList<ThongKe>();
			ThongKe listTKDoanhThu;
			String sql = String.format("select (sum(SoNguoiLon+SoTreEm)) as SoLuongDat, month(ThoiGianKhoiHanh) as Thang,year(ThoiGianKhoiHanh) as Nam "
					+ "from DATTOURDULICH "
					+ "where ThoiGianKhoiHanh between '%s' and '%s' "
					+ "group by month(ThoiGianKhoiHanh), year(ThoiGianKhoiHanh) "
					+ "order by Nam",ngayBatDau,ngayKetThuc);
			System.out.println(sql);
			try {
				Statement st = db.getConnect().createStatement();
				rs = st.executeQuery(sql);
				System.out.println(sql);
				while(rs.next()){
					listTKDoanhThu = new ThongKe();
					listTKDoanhThu.setLabel(rs.getString("thang")+"/"+rs.getString("nam"));
					listTKDoanhThu.setValue(rs.getInt("soLuongDat"));;
					list.add(listTKDoanhThu);
				}
				return list;
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Loi cau lenh SQL So Luong Dat!!!");
			} finally {
				db.closedConnect();
			}
			return null;
		}
}
