package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.DanhSachTour;
/**
 * LoginDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class LoginDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=quanlydulich";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}
	public boolean checkLogin(String userName, String passWord) {
		// TODO Auto-generated method stub
		connect();
		String sql=	String.format("select * from TAIKHOAN where MaTk='"+userName+"' and MatKhau='"+passWord+"'");
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		

		try {
			
			if(rs.next())
			{
				return true;
			}
				
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return false;
	}

}
