package model.dao;

import java.sql.ResultSet;

import common.StringProcess;
import model.bean.TaiKhoan;
/**
 * DataDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DataDAO {
	public TaiKhoan getTaiKhoanHienTai(String tenDangNhap) {
		// TODO Auto-generated method stub
		BaseDAO baseDao = new BaseDAO();
		baseDao.getconnection();
		TaiKhoan taiKhoanHienTai = new TaiKhoan();
		String sql = "select MaTK,MatKhau,HoTen,Email,DiaChi,NgaySinh,GioiTinh,SoDienThoai,SoThich,Anh from TAIKHOAN where MaTK='" + tenDangNhap + "'";
		System.out.println("sql" + sql);
		try {

			ResultSet result = baseDao.executeQuery(sql);
			result.next();
			taiKhoanHienTai.setMaTK(result.getString(1));
			taiKhoanHienTai.setMatKhau(StringProcess.md5(result.getString(2)));
			taiKhoanHienTai.setHoTen(result.getString(3));
			taiKhoanHienTai.setEmail(result.getString(4));
			taiKhoanHienTai.setDiaChi(result.getString(5));
			taiKhoanHienTai.setNgaySinh(result.getString(6));
			taiKhoanHienTai.setGioiTinh(result.getString(7));
			taiKhoanHienTai.setSoDienThoai(result.getString(8));
			taiKhoanHienTai.setSoThich(result.getString(9));
			taiKhoanHienTai.setAnh(result.getString(10));
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return taiKhoanHienTai;
	}
}
