package model.dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import model.bean.BaiViet;
import model.bean.BinhLuan;
/**
 * BaiVietDAO.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class BaiVietDAO {
	public ArrayList<BaiViet> getListBaiViet(String txtFind) {
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT BAIVIET.MaBV,BAIVIET.TieuDe,BAIVIET.NgayDang,BAIVIET.MoTa,TAIKHOAN.HoTen"
				+ " FROM BAIVIET"
				+ " INNER JOIN TAIKHOAN"
				+ " ON BAIVIET.MaTK = TAIKHOAN.MaTK"
				+ " Where BAIVIET.MaDanhMuc =1";
		System.out.println(sql);
		ArrayList<BaiViet> list = new ArrayList<BaiViet>();
		BaiViet listBaiViet;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listBaiViet = new BaiViet();
				listBaiViet.setMaBaiViet(rs.getInt("MaBV"));
				listBaiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
				listBaiViet.setNgayDang(rs.getDate("NgayDang"));	
				listBaiViet.setThanhVien(rs.getString("HoTen"));
				listBaiViet.setMoTa(rs.getString("Mota"));
				list.add(listBaiViet);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;

	}

	public ArrayList<BaiViet> getListBaiVietMoi(String txtFind) {
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT BAIVIET.MaBV,BAIVIET.TieuDe,BAIVIET.NgayDang,BAIVIET.MoTa,TAIKHOAN.HoTen"
				+ " FROM BAIVIET"
				+ " INNER JOIN TAIKHOAN"
				+ " ON BAIVIET.MaTK = TAIKHOAN.MaTK"
				+ " WHERE Duyet = '0' and (BAIVIET.MaBV like '"+txtFind
				+"' or BAIVIET.TieuDe like N'%"+txtFind
				+"%' or BAIVIET.NoiDung like N'%"+txtFind
				+"%' or TAIKHOAN.HoTen like N'%"+txtFind
				+"%' or BAIVIET.MoTa like N'%"+txtFind+"%')";
				
		System.out.println(sql);
		ArrayList<BaiViet> list = new ArrayList<BaiViet>();
		BaiViet listBaiViet;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listBaiViet = new BaiViet();
				listBaiViet.setMaBaiViet(rs.getInt("MaBV"));
				System.out.println("ma bai viettttt" +listBaiViet.getMaBaiViet());
				listBaiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
				listBaiViet.setNgayDang(rs.getDate("NgayDang"));
				listBaiViet.setThanhVien(rs.getString("HoTen"));
				list.add(listBaiViet);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;
	}

	public boolean getDuyetBaiViet(String duyet, int maBaiViet) {
		DataBaseDatDN db = new DataBaseDatDN();
		try {
			Statement st = db.getConnect().createStatement();
			{
				String sql = "UPDATE BAIVIET set Duyet ='1' WHERE '0'=duyet and MaBV = '"+maBaiViet+"'";
				System.out.print("SQL: "+sql);
				st.executeUpdate(sql);
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public ArrayList<BinhLuan> getListBinhLuan(int maBaiViet) {
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat spf =  new SimpleDateFormat("dd/MM/yyyy");
		String sql = "select MaBL, MaBV, TenNguoiBL, BINHLUAN.Email, NoiDungBL, NgayBL" +
				" from BINHLUAN " +
				"where MaBV like '"+maBaiViet+"'  order by NgayBL desc";
		System.out.println(sql);
		ArrayList<BinhLuan> list = new ArrayList<BinhLuan>();
		BinhLuan listBinhLuan;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listBinhLuan = new BinhLuan();
				listBinhLuan.setIdBaiViet(rs.getInt("MaBV"));
				listBinhLuan.setMaBinhLuan(rs.getInt("MaBinhLuan"));
				listBinhLuan.setNoiDungBinhLuan(rs.getString("NoiDungBL"));
				listBinhLuan.setNgayBinhLuan(spf.format(rs.getDate("NgayBL")));
				listBinhLuan.setTenNguoiBinhLuan(rs.getString("TenNguoiBL"));
				listBinhLuan.setEmail(rs.getString("Email"));
				list.add(listBinhLuan);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;


	}

	public ArrayList<BaiViet> getListBaiVietTour(String txtFind) {
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT BAIVIET.MaBV,BAIVIET.TieuDe,BAIVIET.NgayDang,BAIVIET.MoTa,TAIKHOAN.HoTen"
				+ " FROM BAIVIET"
				+ " INNER JOIN TAIKHOAN"
				+ " ON BAIVIET.MaTK = TAIKHOAN.MaTK"
				+ " Where BAIVIET.MaDanhMuc =2";
		System.out.println(sql);
		ArrayList<BaiViet> list = new ArrayList<BaiViet>();
		BaiViet listBaiViet;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listBaiViet = new BaiViet();
				listBaiViet.setMaBaiViet(rs.getInt("MaBV"));
				listBaiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
				listBaiViet.setNgayDang(rs.getDate("NgayDang"));
				listBaiViet.setThanhVien(rs.getString("HoTen"));
				listBaiViet.setMoTa(rs.getString("Mota"));
				list.add(listBaiViet);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}

		return null;
	}

	public ArrayList<BaiViet> getListBaiVietKhachSan(String txtFind) {
		// TODO Auto-generated method stub
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT BAIVIET.MaBV,BAIVIET.TieuDe,BAIVIET.NgayDang,BAIVIET.MoTa,TAIKHOAN.HoTen"
				+ " FROM BAIVIET"
				+ " INNER JOIN TAIKHOAN"
				+ " ON BAIVIET.MaTK = TAIKHOAN.MaTK"
				+ " Where BAIVIET.MaDanhMuc =3";
		System.out.println(sql);
		ArrayList<BaiViet> list = new ArrayList<BaiViet>();
		BaiViet listBaiViet;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listBaiViet = new BaiViet();
				listBaiViet.setMaBaiViet(rs.getInt("MaBV"));
				listBaiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
				listBaiViet.setNgayDang(rs.getDate("NgayDang"));
				listBaiViet.setThanhVien(rs.getString("HoTen"));
				listBaiViet.setMoTa(rs.getString("Mota"));
				list.add(listBaiViet);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}
		return null;
	}
	public ArrayList<BaiViet> getListBaiVietTourKM(String txtFind) {
		// TODO Auto-generated method stub
		if(txtFind==null) txtFind = "";
		else txtFind = txtFind.trim();
		DataBaseDatDN dataBase = new DataBaseDatDN();
		ResultSet rs = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String sql = "SELECT BAIVIET.MaBV,BAIVIET.TieuDe,BAIVIET.NgayDang,BAIVIET.MoTa,TAIKHOAN.HoTen"
				+ " FROM BAIVIET"
				+ " INNER JOIN TAIKHOAN"
				+ " ON BAIVIET.MaTK = TAIKHOAN.MaTK"
				+ " Where BAIVIET.MaDanhMuc = 4";
		System.out.println(sql);
		ArrayList<BaiViet> list = new ArrayList<BaiViet>();
		BaiViet listBaiViet;
		try {
			Statement st = dataBase.getConnect().createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				listBaiViet = new BaiViet();
				listBaiViet.setMaBaiViet(rs.getInt("MaBV"));
				listBaiViet.setTieuDeBaiViet(rs.getString("TieuDe"));
				listBaiViet.setNgayDang(rs.getDate("NgayDang"));
				listBaiViet.setThanhVien(rs.getString("HoTen"));
				listBaiViet.setMoTa(rs.getString("Mota"));
				list.add(listBaiViet);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.closedConnect();
		}
		return null;
	}
}
