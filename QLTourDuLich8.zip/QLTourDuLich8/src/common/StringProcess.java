package common; 

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * StringProcess.java
 *
 * Version 1.0
 *
 * Date:20-03-2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017       DatDN         Create
 */

public class StringProcess {
	
	public static String toUTF8(String isoString){
		String utf8String = null;
		try {
			if (isoString != null){
				byte[] stringByteISO = isoString.getBytes("ISO-8859-1");
				utf8String = new String(stringByteISO, "UTF-8");
			}
		} catch (UnsupportedEncodingException e) {
			System.err.println("Khong ma hoa duoc :(");
			utf8String = isoString;
		}
		return utf8String;
	}
	
	private static String reverseIt(String source) {
	    int i, len = source.length();
	    StringBuilder dest = new StringBuilder(len);

	    for (i = (len - 1); i >= 0; i--){
	        dest.append(source.charAt(i));
	    }

	    return dest.toString();
	}
	public static String money(String money) {
		money = reverseIt(money);
		String s="";
		int i =0 ;
		while(i<money.length()){
			if(i+3>money.length()){
				s = s+","+money.substring(i,money.length());
			} else{
			s = s+","+money.substring(i,i+3);
			}
			i=i+3;
		}
		money = reverseIt(s);
		
		return money.substring(0,money.length()-1);
	}

public static String md5(String matKhau) {
	String md5 = null;
	
	if(null == matKhau) return null;
	
	try {
		
	//Create MessageDigest object for MD5
	MessageDigest digest = MessageDigest.getInstance("MD5");
	
	//Update input string in message digest
	digest.update(matKhau.getBytes(), 0, matKhau.length());

	//Converts message digest value in base 16 (hex) 
	md5 = new BigInteger(1, digest.digest()).toString(16);

	} catch (NoSuchAlgorithmException e) {

		e.printStackTrace();
	}
	return md5;
}
}


