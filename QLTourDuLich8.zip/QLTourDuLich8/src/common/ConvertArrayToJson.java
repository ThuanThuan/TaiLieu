package common;

import java.util.ArrayList;

import com.google.gson.Gson;

import model.bean.ThongKe;
/**
 * ConvertArrayToJson.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ConvertArrayToJson {
	
	public String convertToJson(ArrayList<ThongKe> listSoLuongDat) {
		Gson gson = new Gson();
		String jsonInString = "";
		for (int i = 0; i < listSoLuongDat.size(); i++) {
			String str = gson.toJson(listSoLuongDat.get(i));
			jsonInString = jsonInString + str + ",";
		}
		return jsonInString;
	}
	
	
}
