package common;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
/**
 * ImageResize.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ImageResize {
    public static void resizeImage(String path,int width,int height){
    BufferedImage originalImage,resizedImage;
    int type=0;
	try {
		originalImage = ImageIO.read(new File(path));
		type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
		resizedImage = new BufferedImage(width, height, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, width, height, null);
		g.dispose();
		System.out.println("doi thanh cong");
		ImageIO.write(resizedImage, "jpg", new File(path));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("doi that bai");
	}
	
    }

}
