package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.bean.KhuyenMai;
import model.bean.TaiKhoan;
import model.bo.KhuyenMaiBO;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import form.AdminKhuyenMaiForm;
import form.SuaKhuyenMaiForm;
/**
 * SuaKhuyenMaiAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaKhuyenMaiAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	SuaKhuyenMaiForm khuyenMaiForm = (SuaKhuyenMaiForm) form;
	TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
	if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
		return mapping.findForward("dangnhap");
	}
	int maKhuyenMai = khuyenMaiForm.getMaKhuyenMai();
	KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();
	KhuyenMai khuyenMai = khuyenMaiBO.getThongTinKhuyenMai(maKhuyenMai);
	khuyenMaiForm.setMaKhuyenMai(khuyenMai.getMaKhuyenMai());
    khuyenMaiForm.setTenKhuyenMai(khuyenMai.getTenKhuyenMai());
    khuyenMaiForm.setHinhThucKhuyenMai(khuyenMai.getHinhThucKhuyenMai());
	return mapping.findForward("done");
	}
}
