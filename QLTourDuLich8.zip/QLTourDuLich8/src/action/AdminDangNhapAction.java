package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.AdminThongTinForm;
import model.bean.TaiKhoan;
import model.bo.TaiKhoanBO;
/**
 * AdminDangNhapAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class AdminDangNhapAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		AdminThongTinForm fDangNhap = (AdminThongTinForm) form;

		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin != null && admin.getLoaiTaiKhoan() == -1) {
			return mapping.findForward("done");
		}
		
		String thaoTac = fDangNhap.getThaoTac();
		if (thaoTac != null && thaoTac.equals("dangnhap")) {
			TaiKhoanBO taiKhoanBO = new TaiKhoanBO();
			String user = fDangNhap.getTaiKhoan();
			String pass = StringProcess.md5(fDangNhap.getMatKhau());
			//String pass = fDangNhap.getMatKhau();
			TaiKhoan taiKhoan = taiKhoanBO.kiemTraTaiKhoan(user, pass, -1);
			if (taiKhoan != null) {
				request.getSession().setAttribute("admin", taiKhoan);
//				fDangNhap.setTaiKhoan(user);
//				fDangNhap.setHoTen(taiKhoan.getHoTen());
//				fDangNhap.setDiaChi(taiKhoan.getDiaChi());
//				fDangNhap.setEmail(taiKhoan.getEmail());
//				fDangNhap.setDienThoai(taiKhoan.getSoDienThoai());
//				fDangNhap.setMatKhau(pass);
				return mapping.findForward("done");
			} else {
				fDangNhap.setResultFail("Tài khoản mật khẩu không chính xác!");
				fDangNhap.setTaiKhoan(null);
				fDangNhap.setMatKhau(null);
				return mapping.findForward("thatbai");
			}
		} else {
			fDangNhap.setTaiKhoan(null);
			fDangNhap.setMatKhau(null);
			fDangNhap.setResultFail(null);
			return mapping.findForward("dangnhap");
		}
	}

}
