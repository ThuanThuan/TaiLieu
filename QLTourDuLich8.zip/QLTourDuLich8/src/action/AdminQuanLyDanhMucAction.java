package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import form.AdminDanhMucForm;
import model.bean.DanhMuc;
import model.bo.DanhMucBO;
import model.dao.FormatData;
/**
 * AdminQuanLyDanhMucAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class AdminQuanLyDanhMucAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		AdminDanhMucForm fDanhMucMonAn = (AdminDanhMucForm) form;
		String btnXuly = fDanhMucMonAn.getBtnXuly();
		DanhMucBO danhMucMonAnBO = new DanhMucBO();

		String page = fDanhMucMonAn.getPage();
		String btnSubmit = fDanhMucMonAn.getSubmit();
		try {
			if (Integer.parseInt(page) < 1)
				fDanhMucMonAn.setPage("1");
		} catch (Exception e) {
			fDanhMucMonAn.setPage("1");
		}

		if (btnXuly == null) {
			ArrayList<DanhMuc> list = danhMucMonAnBO.getDanhSachDanhMuc("");
			fDanhMucMonAn.setListDanhMucMonAn(list);
		} else {
			if (btnXuly.equals("delete")) {
				int maDanhMuc = fDanhMucMonAn.getMaDanhMuc();
				String tenDanhMuc = fDanhMucMonAn.getTenMonAn();
				if (danhMucMonAnBO.deleteDanhMucMonAn(maDanhMuc)) {
						fDanhMucMonAn
								.setResultOk("Xóa Danh Mục Thành Công");
					} else {
						fDanhMucMonAn
								.setResultError("Xóa Danh Mục Không Thành Công");
					}
			}
			fDanhMucMonAn.setTxtFind(FormatData.toUTF8(fDanhMucMonAn
					.getTxtFind()));
			ArrayList<DanhMuc> list = danhMucMonAnBO
					.getDanhSachDanhMuc(fDanhMucMonAn.getTxtFind() == null ? ""
							: fDanhMucMonAn.getTxtFind().trim());
			fDanhMucMonAn.setListDanhMucMonAn(list);
		}
		if (btnSubmit != null) {
			if ("Thêm Mới Danh Mục".equals(FormatData.toUTF8(btnSubmit)))
				return mapping.findForward("themDanhMucMonAn");
			if ("Thêm mới".equals(FormatData.toUTF8(btnSubmit))) {
				String tenMonMoi =FormatData.toUTF8(fDanhMucMonAn.getTenMonAnMoi());
				String moTaDanhMuc =FormatData.toUTF8( fDanhMucMonAn.getMoTa());
				danhMucMonAnBO.themDanhMucMonAnMoi(tenMonMoi, moTaDanhMuc);
				fDanhMucMonAn.setListDanhMucMonAn(danhMucMonAnBO
						.getDanhSachDanhMuc(""));
				return mapping.findForward("list");
			}
			if ("Cập nhật".equals(FormatData.toUTF8(btnSubmit))) {
				String tenMonAnMoi = FormatData.toUTF8(fDanhMucMonAn
						.getTenMonAn());
				String moTa =FormatData.toUTF8(fDanhMucMonAn.getMoTa());
				int maMonAnChinhSua = fDanhMucMonAn.getMaMonAnChinhSua();
				danhMucMonAnBO.capNhatTenMonAn(maMonAnChinhSua,tenMonAnMoi,moTa);
				fDanhMucMonAn.setListDanhMucMonAn(danhMucMonAnBO
						.getDanhSachDanhMuc(""));
				return mapping.findForward("list");
			}  
		}
		int maMonAnChinhSua = fDanhMucMonAn.getMaMonAnChinhSua();
		if (maMonAnChinhSua != 0) {
			fDanhMucMonAn.setTenMonAn(danhMucMonAnBO
					.getTenMonAn(maMonAnChinhSua));
			return mapping.findForward("suaDanhMucMonAn");

		}
		return mapping.findForward("list");
	}
}
