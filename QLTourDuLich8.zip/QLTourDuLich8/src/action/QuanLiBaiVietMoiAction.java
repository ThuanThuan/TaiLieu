package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanLiBaiVietForm;
import model.bean.BaiViet;
import model.bean.TaiKhoan;
import model.bo.BaiVietBO;
/**
 * QuanLiBaiVietMoiAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiBaiVietMoiAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		QuanLiBaiVietForm baiVietForm = (QuanLiBaiVietForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
	
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		String page = baiVietForm.getPage();
		String btnSubmit = baiVietForm.getSubmit();
		try {
			if (Integer.parseInt(page) < 1)
				baiVietForm.setPage("1");
		} catch (Exception e) {
			baiVietForm.setPage("1");
		}
		int maBaiViet = baiVietForm.getMaBaiViet();
		String txtFind = baiVietForm.getTxtFind();
		BaiVietBO baiVietBO = new BaiVietBO();
		ArrayList<BaiViet> listBaiViet = baiVietBO.getListBaiVietMoi(txtFind);
		baiVietForm.setListBaiViet(listBaiViet);

		int a = baiVietForm.getListBaiViet().size();
		return mapping.findForward("done");
	}
}
