package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.SuaBaiVietForm;
import model.bo.DeleteBaiVietBO;
/**
 * DeleteBaiVietAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DeleteBaiVietAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		SuaBaiVietForm baiVietForm = (SuaBaiVietForm) form;
		int maBaiViet = baiVietForm.getMaBaiViet();
		DeleteBaiVietBO deleteBaiVietBO = new DeleteBaiVietBO();
		if (deleteBaiVietBO.deleteBaiViet(maBaiViet)) {
			return mapping.findForward("done");
		}
		return mapping.findForward("done");
	}
}
