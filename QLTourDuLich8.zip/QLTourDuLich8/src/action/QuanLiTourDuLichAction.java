package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DanhMuc;
import model.bean.KhuyenMai;
import model.bean.TaiKhoan;
import model.bean.TourDuLich;
import model.bo.DanhMucBO;
import model.bo.KhuyenMaiBO;
import model.bo.TourBO;
import model.dao.FormatData;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.sun.rmi.rmid.ExecOptionPermission;

import form.AdminTourDuLichForm;
import form.DanhSachTourDuLichForm;
/**
 * QuanLiTourDuLichAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiTourDuLichAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		System.out.print("Loi dang nhap");
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		
		DanhSachTourDuLichForm tourDuLichForm = (DanhSachTourDuLichForm) form;
		String btnXuly = tourDuLichForm.getBtnXuly();
		String page = tourDuLichForm.getPage();
		String btnSubmit = tourDuLichForm.getSubmit();
		try {
			if (Integer.parseInt(page) < 1)
				tourDuLichForm.setPage("1");
		} catch (Exception e) {
			tourDuLichForm.setPage("1");
		}
		//layDanhSachDanhMuc
	   String maTour = tourDuLichForm.getMaTour();
	   String txtFind = tourDuLichForm.getTxtFind();
	   TourBO tourBO = new TourBO();
	   if (btnXuly == null) {
	   ArrayList<TourDuLich> listTourDuLich =  tourBO.getListTourDuLich(txtFind);
	   tourDuLichForm.setListTourDuLich(listTourDuLich);
	   }else{
		   tourDuLichForm.setTxtFind(FormatData.toUTF8(tourDuLichForm
					.getTxtFind()));
			ArrayList<TourDuLich> list = tourBO
					.getListTourDuLichMoi(tourDuLichForm.getTxtFind() == null ? ""
							: tourDuLichForm.getTxtFind().trim());
			tourDuLichForm.setListTourDuLich(list);
	   }
	   int a =tourDuLichForm.getListTourDuLich().size();
	   return  mapping.findForward("done");
	   
	}
}
