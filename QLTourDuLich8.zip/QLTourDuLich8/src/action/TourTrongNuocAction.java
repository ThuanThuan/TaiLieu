package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachTourDuLichForm;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bo.DanhMucBO;
import model.bo.DanhSachTourBO;
/**
 * TourTrongNuocAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class TourTrongNuocAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachTourDuLichForm dsForm=(DanhSachTourDuLichForm)form;
		DanhSachTourBO dsBO=new DanhSachTourBO();
		String maDM=dsForm.getMaDanhMuc();
		ArrayList<DanhSachTour> listtourTN;
		ArrayList<DanhSachTour> listtoptour;
		listtourTN=dsBO.getListTourTN(maDM);
		listtoptour=dsBO.getListTopTour();
		dsForm.setListTourTN(listtourTN);
		dsForm.setListtoptour(listtoptour);
		DanhMucBO DBO=new DanhMucBO();
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		dsForm.setListDM(listDM);
		System.out.print("maDanh mUC:"+maDM);
		System.out.print(listtourTN.size());
		return mapping.findForward("dstour");
	}
}
