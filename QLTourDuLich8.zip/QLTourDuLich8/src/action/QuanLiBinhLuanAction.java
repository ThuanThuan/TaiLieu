package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanLiBinhLuanForm;
import model.bean.BinhLuan;

import model.bean.TaiKhoan;
import model.bo.DanhSachTourBO;
import model.dao.FormatData;
/**
 * QuanLiBinhLuanAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiBinhLuanAction extends Action {
	
     @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
    		HttpServletResponse response) throws Exception {
    		request.setCharacterEncoding("utf-8");
    		System.out.print("Loi dang nhap");
    		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
    		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
    			return mapping.findForward("dangnhap");
    		}
    	QuanLiBinhLuanForm quanLiBinhLuan = (QuanLiBinhLuanForm) form;
    	DanhSachTourBO danhSachTourBO = new DanhSachTourBO();
    	String page = quanLiBinhLuan.getPage();
		
		String btnXuLy = quanLiBinhLuan.getBtnXuly();
		try {
			if (Integer.parseInt(page) < 1)
				quanLiBinhLuan.setPage("1");
		} catch (Exception e) {
			quanLiBinhLuan.setPage("1");
		}

		if (btnXuLy == null) {
			ArrayList<BinhLuan> list = danhSachTourBO.getDanhSachBinhLuan("");
			quanLiBinhLuan.setListBinhLuan(list);
			
		} else {
			quanLiBinhLuan.setTxtFind(FormatData.toUTF8(quanLiBinhLuan
					.getTxtFind()));
			ArrayList<BinhLuan> list = danhSachTourBO
					.getDanhSachBinhLuan(quanLiBinhLuan.getTxtFind() == null ? ""
							: quanLiBinhLuan.getTxtFind().trim());
			quanLiBinhLuan.setListBinhLuan(list);
		}
		return mapping.findForward("list");
    }
}
