package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


import form.DanhSachTourDuLichForm;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bo.DanhMucBO;
import model.bo.DanhSachTourBO;
/**
 * DanhSachTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DanhSachTourAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachTourDuLichForm dsForm=(DanhSachTourDuLichForm)form;
		HttpSession session=request.getSession(); 
		session=request.getSession();
		String tenDangNhap = dsForm.getTenDangNhap();
		DanhSachTourBO dsBO=new DanhSachTourBO();
		ArrayList<DanhSachTour> listtour;
		ArrayList<DanhSachTour> listtoptour;
		listtour=dsBO.getListTour();
		listtoptour=dsBO.getListTopTour();
		dsForm.setListtour(listtour);
		dsForm.setTenDangNhap(tenDangNhap);
		
		
		dsForm.setListtoptour(listtoptour);
		DanhMucBO DBO=new DanhMucBO();
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		dsForm.setListDM(listDM);
		System.out.print("list danh muc");
		System.out.print("get list thanh cong");
		String page=dsForm.getPage();
		try{
		if(Integer.parseInt(page)<1)
			dsForm.setPage("1");
		}catch (Exception e) {
			// TODO: handle exception
			dsForm.setPage("1");
		}
		session.setAttribute("danhSachTourDuLichForm", dsForm);
		return mapping.findForward("dstour");
	}
}
