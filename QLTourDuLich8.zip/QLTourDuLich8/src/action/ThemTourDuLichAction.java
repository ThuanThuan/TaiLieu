package action;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DanhMuc;
import model.bean.KhuyenMai;

import model.bean.TaiKhoan;
import model.bean.TourDuLich;
import model.bo.DanhMucBO;
import model.bo.KhuyenMaiBO;


import model.bo.TourBO;
import model.dao.FormatData;

import org.apache.commons.io.FileUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import common.StringProcess;
import form.ThemTourDuLichForm;
/**
 * ThemTourDuLichAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemTourDuLichAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		ThemTourDuLichForm tourDuLichForm = (ThemTourDuLichForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		DanhMucBO danhMucBO = new DanhMucBO();
		ArrayList<DanhMuc> listDanhMuc= danhMucBO.getListDanhMuc();
		tourDuLichForm.setListDanhMuc(listDanhMuc);
		KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();
		ArrayList<KhuyenMai> listKhuyenMai= khuyenMaiBO.getListKhuyenMai();
		tourDuLichForm.setListKhuyenMai(listKhuyenMai);
		String anh1 ="";
		String anh2 ="";  
		String anh3 ="";
		System.out.print("đã hien thi");
		if (StringProcess.toUTF8(tourDuLichForm.getSubmit()).equals("Thêm mới")) {
			int maDanhMuc = tourDuLichForm.getMaDanhMuc();
			int maKhuyenMai = tourDuLichForm.getMaKhuyenMai();
			String tenTour = FormatData.toUTF8(tourDuLichForm.getTenTour());
			String diemKhoiHanh = FormatData.toUTF8(tourDuLichForm.getDiemKhoiHanh());
			String thoiGian = FormatData.toUTF8(tourDuLichForm.getThoiGian());
			String phuongTien = FormatData.toUTF8(tourDuLichForm.getPhuongTien());
			String lichTrinh = FormatData.toUTF8(tourDuLichForm.getLichTrinh());
			String hinhThuc = FormatData.toUTF8(tourDuLichForm.getHinhThuc());
			int giaTour   = tourDuLichForm.getGiaTour();
			String email =  FormatData.toUTF8(tourDuLichForm.getEmail());
			FormFile file = tourDuLichForm.getFile();
			FormFile file1 = tourDuLichForm.getFile1();
			FormFile file2 = tourDuLichForm.getFile2();
			anh1 = taiAnhLen(file, request);
			anh2 = taiAnhLen(file1, request);
			anh3 = taiAnhLen(file2, request);
			String textEditor = FormatData.toUTF8(tourDuLichForm.getTextEditor());
			String diemDen=FormatData.toUTF8(tourDuLichForm.getDiemDen());
			int khuyenMai = 0;
			int giaTourSau=0;
			if(maKhuyenMai==1){
				 khuyenMai =0;
			}else if(maKhuyenMai==2){
			 khuyenMai =5;
			}else if(maKhuyenMai==3) {
				 khuyenMai =10;
			}else if(maKhuyenMai==4){
				khuyenMai=15;
			}
		
			
			
			if(khuyenMai==0){
			  giaTourSau = giaTour;
			}else{
			giaTourSau =giaTour-(giaTour*khuyenMai)/100;
		    }
			TourBO tourBO = new TourBO();
			if (tourBO.themTourDuLich( maDanhMuc, maKhuyenMai, tenTour, diemKhoiHanh, thoiGian, phuongTien, lichTrinh, hinhThuc, giaTour, anh1, anh2, anh3, email,textEditor,diemDen,giaTourSau)) {
				return mapping.findForward("thanhcong");
			}
			return mapping.findForward("thanhcong");
		

		} else {
			String txtFind="";
			// lay danh sach cac dia diem
			TourBO tourBO = new TourBO();
			ArrayList<TourDuLich> listTourDuLich = tourBO.getListTourDuLich(txtFind);
             tourDuLichForm.setListTourDuLich(listTourDuLich);
			tourDuLichForm.setMaTour(0);
			tourDuLichForm.setMaDanhMuc(0);
			tourDuLichForm.setMaKhuyenMai(0);
			tourDuLichForm.setDiemKhoiHanh("");
			tourDuLichForm.setThoiGian("");
			tourDuLichForm.setPhuongTien("");
			tourDuLichForm.setLichTrinh("");
			tourDuLichForm.setHinhThuc("");
			tourDuLichForm.setGiaTour(0);
			tourDuLichForm.setAnh1("");
			tourDuLichForm.setAnh2("");
			tourDuLichForm.setAnh3("");
			tourDuLichForm.setEmail("");
			tourDuLichForm.setTextEditor("");
			tourDuLichForm.setDiemDen("");
			tourDuLichForm.setGiaTourSau(0);
			return mapping.findForward("done");
			
		}
	
	}
	private String taiAnhLen(FormFile file, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String fileName = "";
		try {
			fileName = file.getFileName();
			// Get the servers upload directory real path name
			String filePath = getServlet().getServletContext().getRealPath("/")
					+ "upload";
			// create the upload folder if not exists
			File folder = new File(filePath);
			if (!folder.exists()) {
				folder.mkdir();
			}
			if (!("").equals(fileName)) {

				System.out.println("Server path:" + filePath);
				File newFile = new File(filePath, fileName);

				if (!newFile.exists()) {
					FileOutputStream fos = new FileOutputStream(newFile);
					fos.write(file.getFileData());
					fos.flush();
					fos.close();
				}

				request.setAttribute("uploadedFilePath", newFile
						.getAbsoluteFile());
				request.setAttribute("uploadedFileName", newFile.getName());
				String mypath = "C:\\workspace\\QLDuLich\\WebContent\\anhbaiviet\\"
						+ newFile.getName();
				FileUtils.copyFile(
						new File(filePath + "\\" + newFile.getName()),
						new File(mypath));
				// ImageResize.resizeImage(mypath);
			}
		} catch (Exception e) {
			return null;
		}

		return fileName;
	}

}
