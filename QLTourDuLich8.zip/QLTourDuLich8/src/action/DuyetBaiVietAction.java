package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.SuaBaiVietForm;
import model.bean.BaiViet;
import model.bean.BinhLuan;

import model.bo.BaiVietBO;
import model.bo.DuyetBaiVietBO;
/**
 * DuyetBaiVietAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DuyetBaiVietAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		SuaBaiVietForm baiVietForm = (SuaBaiVietForm) form;
		int maBaiViet = baiVietForm.getMaBaiViet();
		BaiViet baiViet = new BaiViet();
		String duyet = baiVietForm.getDuyet();
		if (StringProcess.toUTF8(baiVietForm.getSubmit()).equals("Duyệt bài viết")) {
			BaiVietBO baiVietBO = new BaiVietBO();
			if (baiVietBO.getDuyetBaiViet(duyet,maBaiViet)) {
				return mapping.findForward("thanhcong");
			}
			return mapping.findForward("done");
		} else
			maBaiViet = baiVietForm.getMaBaiViet();
			DuyetBaiVietBO duyetBaiVietBO = new DuyetBaiVietBO();
			BaiViet duyetbaiViet = duyetBaiVietBO.getduyetBaiViet(maBaiViet);
			baiVietForm.setTextEditor(duyetbaiViet.getNoiDung());
			baiVietForm.setNgayDang(duyetbaiViet.getNgayDang());
			baiVietForm.setDuyet(duyetbaiViet.getDuyet());
			baiVietForm.setTextTieuDeBaiViet(duyetbaiViet.getTieuDeBaiViet());
			
			BaiVietBO baiVietBO = new BaiVietBO();
			ArrayList<BinhLuan> listBinhLuan =baiVietBO.getListBinhLuan(maBaiViet);
			baiVietForm.setListBinhLuan(listBinhLuan);
			
			return mapping.findForward("done");
	}

}
