package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DanhMuc;
import model.bean.KhuyenMai;
import model.bo.KhuyenMaiBO;
import model.dao.FormatData;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminKhuyenMaiForm;
/**
 * QuanLyKhuyenMaiAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLyKhuyenMaiAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		AdminKhuyenMaiForm khuyenMaiForm = (AdminKhuyenMaiForm) form;
		String btnXuly = khuyenMaiForm.getBtnXuly();
		KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();

		String page = khuyenMaiForm.getPage();
		String btnSubmit = khuyenMaiForm.getSubmit();
		try {
			if (Integer.parseInt(page) < 1)
				khuyenMaiForm.setPage("1");
		} catch (Exception e) {
			khuyenMaiForm.setPage("1");
		}

		if (btnXuly == null) {
			ArrayList<KhuyenMai> list = khuyenMaiBO.getListKhuyenMai();
            khuyenMaiForm.setListKhuyenMai(list);
		}else {
			if (btnXuly.equals("delete")) {
				int maKhuyenMai = khuyenMaiForm.getMaKhuyenMai();
				String tenKhuyenMai = khuyenMaiForm.getTenKhuyenMai();
				String hinhThucKhuyenMai =khuyenMaiForm.getHinhThucKhuyenMai();
				if (khuyenMaiBO.deleteKhuyenMai(maKhuyenMai)) {
					khuyenMaiForm
								.setResultOk("Xóa khuyến mãi thành công");
					} else {
						khuyenMaiForm
								.setResultError("Xóa khuyến mãi không thành công");
					}
			}
			khuyenMaiForm.setTxtFind(FormatData.toUTF8(khuyenMaiForm
					.getTxtFind()));
			ArrayList<KhuyenMai> list = khuyenMaiBO
					.getDanhSachKhuyenMai(khuyenMaiForm.getTxtFind() == null ? ""
							: khuyenMaiForm.getTxtFind().trim());
			khuyenMaiForm.setListKhuyenMai(list);
			
		}	
		return mapping.findForward("list");
	}
}



