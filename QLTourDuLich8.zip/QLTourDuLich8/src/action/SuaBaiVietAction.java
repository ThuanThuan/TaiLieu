package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.SuaBaiVietForm;
import model.bean.BaiViet;
import model.bean.DanhMuc;

import model.bean.TaiKhoan;
import model.bo.DanhMucBO;
import model.bo.SuaBaiVietBO;

/**
 * SuaBaiVietAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaBaiVietAction  extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		SuaBaiVietForm suaBaiVietForm = (SuaBaiVietForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		int maBaiViet = suaBaiVietForm.getMaBaiViet();
		// lay thuoc tinh cac doi tuong
		SuaBaiVietBO suaBaiVietBO = new SuaBaiVietBO();
		BaiViet suabaiViet = suaBaiVietBO.getsuaBaiViet(maBaiViet);
		//lay danh sach cac dia diem
		DanhMucBO danhMucBO = new DanhMucBO();
		ArrayList<DanhMuc> listDanhMuc = danhMucBO.getListDanhMuc();
		
		suaBaiVietForm.setListDanhMuc(listDanhMuc);
		suaBaiVietForm.setTextTieuDeBaiViet(suabaiViet.getTieuDeBaiViet());
		suaBaiVietForm.setTextDiaChi(suabaiViet.getDiaChiBaiViet());
		suaBaiVietForm.setTextMoTa(suabaiViet.getMoTa());
		suaBaiVietForm.setTextEditor(suabaiViet.getNoiDung());
		suaBaiVietForm.setMaDanhMuc(suabaiViet.getMaDanhMuc());
		suaBaiVietForm.setAnh1(suabaiViet.getAnh1());
		suaBaiVietForm.setAnh2(suabaiViet.getAnh2());
		suaBaiVietForm.setAnh3(suabaiViet.getAnh3());
		return mapping.findForward("done");
	}
}
