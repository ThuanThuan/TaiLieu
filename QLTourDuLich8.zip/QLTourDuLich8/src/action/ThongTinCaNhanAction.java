package action;

import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import common.StringProcess;
import form.DangKyForm;
import form.DangNhapForm;
import form.DanhSachTourDuLichForm;
import form.ThongTinCaNhanForm;
import model.bean.TaiKhoan;
import model.bo.DataBO;
import model.bo.ExecuteBO;
import model.dao.FormatData;
/**
 * ThongTinCaNhanAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThongTinCaNhanAction extends Action {
   @Override
public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
		HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ThongTinCaNhanForm dangKyForm = (ThongTinCaNhanForm) form;
		HttpSession session = request.getSession();
		DanhSachTourDuLichForm danhSachTourDuLichForm= (DanhSachTourDuLichForm)request.getSession().getAttribute("danhSachTourDuLichForm");
		DataBO data = new DataBO();
		ExecuteBO excute = new ExecuteBO();
		dangKyForm.setTacvu("");
		String anh="";
		if (dangKyForm.getTuKhoa().equals("")) {
			System.out.println("lay thong tin");
		TaiKhoan taiKhoan=	dangKyForm.setTaiKhoanHienTai(data
					.getTaiKhoanHienTai(danhSachTourDuLichForm.getTenDangNhap()));
		dangKyForm.setMaTK(taiKhoan.getMaTK());
		dangKyForm.setMatKhau(taiKhoan.getMatKhau());
		System.out.println(""+taiKhoan.getMatKhau());
		dangKyForm.setHoTen(taiKhoan.getHoTen());
		dangKyForm.setEmail(taiKhoan.getEmail());
		dangKyForm.setDiaChi(taiKhoan.getDiaChi());
		dangKyForm.setGioiTinh(taiKhoan.getGioiTinh());
		dangKyForm.setSoDienThoai(taiKhoan.getSoDienThoai());
		dangKyForm.setSoThich(taiKhoan.getSoThich());
		dangKyForm.setAnh(taiKhoan.getAnh());	
		dangKyForm.setNgaySinh(taiKhoan.getNgaySinh());
		} else if (dangKyForm.getTuKhoa().equals("capNhatMatKhau")) {
			if (excute.capNhatMatKhau(StringProcess.md5(dangKyForm.getMatKhauMoi()),danhSachTourDuLichForm.getTenDangNhap())){
				dangKyForm.setTacvu("thanh cong");
				dangKyForm.setMatKhau(dangKyForm.getMatKhauMoi());
				dangKyForm.setMatKhauMoi("");
			}
			else{
				dangKyForm.setTacvu("that bai");
				dangKyForm.setMatKhauMoi("");
			}
			dangKyForm.setTuKhoa("");
		}
		else if(dangKyForm.getTuKhoa().equals("capNhatThongTin"))
		{
			FormFile file = dangKyForm.getFile1();
			anh = taiAnhLen(file, request);
			if (anh.equals(""))
				anh = dangKyForm.getAnh();
			String hoTen=StringProcess.toUTF8(dangKyForm.getHoTen());
			String tenDangNhap=dangKyForm.getMaTK();
			String email=StringProcess.toUTF8(dangKyForm.getEmail());
			String diaChi=StringProcess.toUTF8(dangKyForm.getDiaChi());
			String ngaySinh=dangKyForm.getNgaySinh();
			String gioiTinh=dangKyForm.getGioiTinh();
			int gt;
			if(gioiTinh=="Nam"){
				gt=0;
			}else{
				gt=1;
			}
			String soDienThoai=dangKyForm.getSoDienThoai();
			String soThich=StringProcess.toUTF8(dangKyForm.getSoThich());
			if(excute.capNhatThongTin(hoTen,tenDangNhap,email,diaChi,ngaySinh,gt,soDienThoai,soThich,anh)){
				dangKyForm.setTacvu("thanh cong");
				dangKyForm.setTaiKhoanHienTai(data
					.getTaiKhoanHienTai(danhSachTourDuLichForm.getTenDangNhap()));
			}else{
				dangKyForm.setTacvu("that bai");
				dangKyForm.setTaiKhoanHienTai(data
						.getTaiKhoanHienTai(danhSachTourDuLichForm.getTenDangNhap()));
			}
			dangKyForm.setTuKhoa("");
		}
		return mapping.findForward("thongTinCaNhan");
	}
	private String taiAnhLen(FormFile file, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String fileName = "";
		try {
			fileName = file.getFileName();

			// Get the servers upload directory real path name
			String filePath = getServlet().getServletContext().getRealPath("/")
					+ "upload";
			// create the upload folder if not exists
			File folder = new File(filePath);
			if (!folder.exists()) {
				folder.mkdir();
			}

			if (!("").equals(fileName)) {

				System.out.println("Server path:" + filePath);
				File newFile = new File(filePath, fileName);

				if (!newFile.exists()) {
					FileOutputStream fos = new FileOutputStream(newFile);
					fos.write(file.getFileData());
					fos.flush();
					fos.close();
				}

				request.setAttribute("uploadedFilePath",
						newFile.getAbsoluteFile());
				request.setAttribute("uploadedFileName", newFile.getName());
				// String mypath =
				// "E:\\TanNC_TTHe\\SourceCode\\Mock Project\\SongNguVietNhat\\WebContent\\pictures\\"
				// + newFile.getName();
				String mypath = "D:\\workspace\\Mockproject1\\WebContent\\avarta\\"
						+ newFile.getName();
				FileUtils.copyFile(
						new File(filePath + "\\" + newFile.getName()),
						new File(mypath));
				//ImageResize.resizeImage(mypath);

			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return fileName;
	}
}

