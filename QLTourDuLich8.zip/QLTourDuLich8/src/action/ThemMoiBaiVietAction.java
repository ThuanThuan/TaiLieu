package action;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import common.StringProcess;
import form.ThemMoiBaiVietForm;
import model.bean.DanhMuc;

import model.bean.TaiKhoan;
import model.bo.DanhMucBO;

import model.bo.ThemMoiBaiVietBO;
import model.dao.FormatData;
/**
 * ThemMoiBaiVietAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemMoiBaiVietAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		ThemMoiBaiVietForm baiVietForm = (ThemMoiBaiVietForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		String anh1 ="";
		String anh2 ="";
		String anh3 ="";
		if (StringProcess.toUTF8(baiVietForm.getSubmit()).equals("Thêm mới")) {
			String textTieuDeBaiViet = FormatData.toUTF8(baiVietForm
					.getTextTieuDeBaiViet());
			
			int maDanhMuc = baiVietForm.getMaDanhMuc();
			FormFile file = baiVietForm.getFile();
			FormFile file1 = baiVietForm.getFile1();
			FormFile file2 = baiVietForm.getFile2();
			anh1 = taiAnhLen(file, request);
			anh2 = taiAnhLen(file1, request);
			anh3 = taiAnhLen(file2, request);
			
			String textDiaChi = FormatData.toUTF8(baiVietForm.getTextDiaChi());
			String textMoTa = FormatData.toUTF8(baiVietForm.getTextMoTa());
			String textEditor = FormatData.toUTF8(baiVietForm.getTextEditor());
			ThemMoiBaiVietBO themMoiBaiVietBO = new ThemMoiBaiVietBO();

			if (themMoiBaiVietBO.themMoiBaiViet(textTieuDeBaiViet, 
					maDanhMuc, textDiaChi, textMoTa, textEditor,anh1,anh2,anh3)) {
				return mapping.findForward("thanhcong");
			}
			return mapping.findForward("done");

		} else {
			// lay danh sach cac dia diem
			DanhMucBO danhMucBO = new DanhMucBO();
			ArrayList<DanhMuc> listDanhMuc = danhMucBO.getListDanhMuc();
			baiVietForm.setListDanhMuc(listDanhMuc);
			baiVietForm.setTextTieuDeBaiViet("");
			baiVietForm.setTextDiaChi("");
			baiVietForm.setTextMoTa("");
			baiVietForm.setTextEditor("");
			return mapping.findForward("done");
			
		}

	}
	private String taiAnhLen(FormFile file, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String fileName = "";
		try {
			fileName = file.getFileName();
			// Get the servers upload directory real path name
			String filePath = getServlet().getServletContext().getRealPath("/")
					+ "upload";
			// create the upload folder if not exists
			File folder = new File(filePath);
			if (!folder.exists()) {
				folder.mkdir();
			}
			if (!("").equals(fileName)) {

				System.out.println("Server path:" + filePath);
				File newFile = new File(filePath, fileName);

				if (!newFile.exists()) {
					FileOutputStream fos = new FileOutputStream(newFile);
					fos.write(file.getFileData());
					fos.flush();
					fos.close();
				}

				request.setAttribute("uploadedFilePath", newFile
						.getAbsoluteFile());
				request.setAttribute("uploadedFileName", newFile.getName());
				String mypath = "C:\\workspace\\QLDuLich\\WebContent\\anhbaiviet\\"
						+ newFile.getName();
				FileUtils.copyFile(
						new File(filePath + "\\" + newFile.getName()),
						new File(mypath));
				// ImageResize.resizeImage(mypath);
			}
		} catch (Exception e) {
			return null;
		}

		return fileName;
	}
}
