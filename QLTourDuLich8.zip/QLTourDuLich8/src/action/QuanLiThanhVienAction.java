package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminNguoiDungForm;
import model.bean.TaiKhoan;
import model.bo.TaiKhoanBO;
import model.dao.FormatData;
/**
 * QuanLiThanhVienAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiThanhVienAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");

		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}

		AdminNguoiDungForm fNguoiDung = (AdminNguoiDungForm) form;
		String btnXuly = fNguoiDung.getBtnXuly();
		TaiKhoanBO taiKhoanBO = new TaiKhoanBO();

		String page = fNguoiDung.getPage();
		try {
			if (Integer.parseInt(page) < 1)
				fNguoiDung.setPage("1");
		} catch (Exception e) {
			fNguoiDung.setPage("1");
		}

		if (btnXuly == null) {
			ArrayList<TaiKhoan> list = taiKhoanBO.getDanhSachTaiKhoan("");
			fNguoiDung.setListThanhVien(list);
		} else {
			if (btnXuly.equals("delete")) {
				String taiKhoan = fNguoiDung.getTenTaiKhoan();
				if (taiKhoan != null) {
					if (taiKhoanBO.deleteTaiKhoan(taiKhoan)) {
						fNguoiDung.setResultOk("Xóa tài khoản thành công");
					} else {
						fNguoiDung
								.setResultError("Xóa tài khoản không thành công");
					}
				} else {
					fNguoiDung.setResultError("Bạn không thể xóa tài khoản này");
				}
			} else if (btnXuly.equals("reset")) {
				String taiKhoan = fNguoiDung.getTenTaiKhoan();
				if (taiKhoan != null) {
					if (taiKhoanBO.resetTaiKhoan(taiKhoan)) {
						fNguoiDung.setResultOk("Reset tài khoản thành công");
					} else {
						fNguoiDung
								.setResultError("Reset tài khoản không thành công");
					}
				} else {
					fNguoiDung
							.setResultError("Bạn không thể  reset");
				}
			}
			fNguoiDung.setTxtFind(FormatData.toUTF8(fNguoiDung.getTxtFind()));
			ArrayList<TaiKhoan> list = taiKhoanBO
					.getDanhSachTaiKhoan(fNguoiDung.getTxtFind() == null ? ""
							: fNguoiDung.getTxtFind().trim());
			fNguoiDung.setListThanhVien(list);
		}
		return mapping.findForward("list");
	}

}
