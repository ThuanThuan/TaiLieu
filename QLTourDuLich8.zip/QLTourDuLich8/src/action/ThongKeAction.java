package action;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.ConvertArrayToJson;
import common.StringProcess;
import form.ThongKeForm;
import model.bean.TaiKhoan;
import model.bean.ThongKe;
import model.bo.ThongKeBO;
import model.dao.FormatData;
/**
 * ThongKeAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThongKeAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ThongKeForm thongKeForm = (ThongKeForm) form;
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			System.out.println("admin loi~!");
			return mapping.findForward("dangnhap");
		}
		
		//Validate du lieu
		if("Xem".equals(thongKeForm.getXem())){
			ActionErrors actionErrors = new ActionErrors();	
			if(FormatData.notVaild(thongKeForm.getNgayBatDau())){
				actionErrors.add("ngayBatDauError", new ActionMessage(StringProcess.toUTF8("error.ngayBatDau")));
			}
			if (FormatData.notVaild(thongKeForm.getNgayKetThuc())) {
				actionErrors.add("ngayKetThucError", new ActionMessage(StringProcess.toUTF8("error.ngayKetThuc")));
			}
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("thongKe");
			}
		}
		
		//validate du lieu
		if("Xem".equals(thongKeForm.getXem())){
			ActionErrors actionErrors = new ActionErrors();	
			DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
			Date ngayBatDau = df.parse(thongKeForm.getNgayBatDau());
			Date ngayKetThuc = df.parse(thongKeForm.getNgayKetThuc());
			if(ngayKetThuc.before(ngayBatDau)){
				actionErrors.add("ngayKetThucError1", new ActionMessage(StringProcess.toUTF8("error.ngayKetThuc1")));
			}
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("thongKe");
			}
		}
		
		request.setCharacterEncoding("UTF-8");
		ArrayList<ThongKe> listSoLuongDat = new ArrayList<>();
		ArrayList<ThongKe> listDoanhThu = new ArrayList<>();
		ArrayList<ThongKe> listDiemKhoiHanh = new ArrayList<>();
		ArrayList<ThongKe> listSoLuongDatTheoThang = new ArrayList<>();
		ConvertArrayToJson convert = new ConvertArrayToJson();
		
		if("Xem".equals(thongKeForm.getXem())){						//Nhan nut submit
			String ngayBatDau = thongKeForm.getNgayBatDau();
			String ngayKetThuc = thongKeForm.getNgayKetThuc();
			ThongKeBO thongKeBO = new ThongKeBO();
			System.out.println("action ne");
			listSoLuongDat = thongKeBO.getListTourHotTheoNgay(ngayBatDau, ngayKetThuc);
			listDoanhThu = thongKeBO.getListDoanhThuTheoNgay(ngayBatDau, ngayKetThuc);
			listDiemKhoiHanh = thongKeBO.getListDiemKhoiHanhTheoNgay(ngayBatDau, ngayKetThuc);
			listSoLuongDatTheoThang = thongKeBO.getListSoLuongDatTheoNgay(ngayBatDau, ngayKetThuc);
			if(listSoLuongDat.size() != 0 && listDoanhThu.size() !=0 && listDiemKhoiHanh.size() != 0
					&& listSoLuongDatTheoThang.size() !=0){
				String jsonTourHot = convert.convertToJson(listSoLuongDat);
				String jsonDoanhThu = convert.convertToJson(listDoanhThu);
				String jsonDiemKhoiHanh = convert.convertToJson(listDiemKhoiHanh);
				String jsonSoLuongDat = convert.convertToJson(listSoLuongDatTheoThang);
				request.setAttribute("jsonTourHot",jsonTourHot);
				request.setAttribute("jsonDoanhThu", jsonDoanhThu);
				request.setAttribute("jsonDiemKhoiHanh", jsonDiemKhoiHanh);
				request.setAttribute("jsonSoLuongDat", jsonSoLuongDat);
				System.out.println("size rong~");
				return mapping.findForward("thongKe");
			}
		}
		return mapping.findForward("thongKe");
	}
	
}