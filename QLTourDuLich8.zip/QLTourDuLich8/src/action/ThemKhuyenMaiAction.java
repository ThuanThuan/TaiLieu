package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.AdminKhuyenMaiForm;
import form.ThemKhuyenMaiForm;
import model.bean.KhuyenMai;
import model.bo.KhuyenMaiBO;
import model.dao.FormatData;
/**
 * ThemKhuyenMaiAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemKhuyenMaiAction extends Action {
       @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
    		HttpServletResponse response) throws Exception {
    	   request.setCharacterEncoding("utf-8");
   		ThemKhuyenMaiForm khuyenMaiForm = (ThemKhuyenMaiForm) form;
   		String btnXuly = khuyenMaiForm.getBtnXuly();
   		KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();
   		if (StringProcess.toUTF8(khuyenMaiForm.getSubmit()).equals("Thêm mới")){
   		String tenKhuyenMai =FormatData.toUTF8(khuyenMaiForm.getTenKhuyenMai());
		String hinhThucKhuyenMai =FormatData.toUTF8( khuyenMaiForm.getHinhThucKhuyenMai());
			if(khuyenMaiBO.themKhuyenMai(tenKhuyenMai, hinhThucKhuyenMai)){
			khuyenMaiForm.setListKhuyenMai((khuyenMaiBO
					.getListKhuyenMai()));
			return mapping.findForward("thanhcong");
			}
		return mapping.findForward("done");
   		}else{
   			String txtFind="";
   			ArrayList<KhuyenMai> listKhuyenMai = khuyenMaiBO.getListKhuyenMai();
   			khuyenMaiForm.setListKhuyenMai(listKhuyenMai);
   			khuyenMaiForm.setMaKhuyenMai(0);
   			khuyenMaiForm.setTenKhuyenMai("");
   			khuyenMaiForm.setHinhThucKhuyenMai("");
   			return mapping.findForward("done");
   		}
    }
}
