package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.DanhSachTourDuLichForm;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bo.DanhMucBO;
import model.bo.DanhSachTourBO;
/**
 * TiemKiemTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class TiemKiemTourAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachTourDuLichForm dsForm=(DanhSachTourDuLichForm)form;
		DanhSachTourBO dsBO=new DanhSachTourBO();
		ArrayList<DanhSachTour> listTour;
		ArrayList<DanhSachTour> listtoptour;
		listtoptour=dsBO.getListTopTour();
		String ddanh=StringProcess.toUTF8(dsForm.getTenTour());
		int gia1=dsForm.getGia1();
		int gia2=(dsForm.getGia2());
		String thoiGian=StringProcess.toUTF8(dsForm.getThoiGian());
		listTour=dsBO.getListTour(ddanh,gia1,gia2,thoiGian);
		dsForm.setTenTour(ddanh);
		dsForm.setGia1(gia1);
		dsForm.setGia2(gia2);
		dsForm.setThoiGian(thoiGian);
		dsForm.setListtour(listTour);
		dsForm.setListtoptour(listtoptour);
		DanhMucBO DBO=new DanhMucBO();
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		dsForm.setListDM(listDM);
		System.out.print("so tour:"+listTour.size());
		System.out.print("so tour:"+ddanh);
		System.out.print("thanh cong");
		return mapping.findForward("tiemkiem");
	}
}
