package action;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.DanhMuc;

import model.bean.TaiKhoan;

import model.bo.DanhMucBO;



import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminDanhMucForm;

/**
 * SuaDanhMucAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaDanhMucAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	AdminDanhMucForm danhMucForm = (AdminDanhMucForm) form;
	TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
	if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
		return mapping.findForward("dangnhap");
	}
	int maDanhMuc = danhMucForm.getMaDanhMuc();
	DanhMucBO danhMucBO = new DanhMucBO();
	DanhMuc danhMuc = danhMucBO.getThongTinDanhMuc(maDanhMuc);
	danhMucForm.setMaDanhMuc(danhMuc.getMaDanhMuc());
    danhMucForm.setTenMonAn(danhMuc.getTenDanhMuc());
    danhMucForm.setMoTa(danhMuc.getMoTa());
	return mapping.findForward("done");
}
}