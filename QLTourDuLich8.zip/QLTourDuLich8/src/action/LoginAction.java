package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.DanhSachTourDuLichForm;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bean.TaiKhoan;
import model.bo.DanhMucBO;
import model.bo.DanhSachTourBO;
import model.bo.ExecuteBO;
import model.dao.FormatData;
/**
 * LoginAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */


public class LoginAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachTourDuLichForm danhSachTourDuLichForm = (DanhSachTourDuLichForm) form;
		DanhSachTourBO dsBO=new DanhSachTourBO();
		TaiKhoan taiKhoan=new TaiKhoan();
		ArrayList<DanhSachTour> listtour;
		ArrayList<DanhSachTour> listtoptour;
		listtour=dsBO.getListTour();
		listtoptour=dsBO.getListTopTour();
		danhSachTourDuLichForm.setListtour(listtour);
		danhSachTourDuLichForm.setListtoptour(listtoptour);
		DanhMucBO DBO=new DanhMucBO();
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		ArrayList<TaiKhoan> listTK;
		
		danhSachTourDuLichForm.setListDM(listDM);
		HttpSession session=request.getSession(); 
		session=request.getSession();
		String tenDangNhap = danhSachTourDuLichForm.getTenDangNhap();
		String matKhau =StringProcess.md5( danhSachTourDuLichForm.getMatKhau());
		//String matKhau = danhSachTourDuLichForm.getMatKhau();
		ExecuteBO excute = new ExecuteBO();
		listTK=dsBO.getListTaiKhoan(tenDangNhap);
		
		request.getSession().setAttribute("admin", taiKhoan);
		if (danhSachTourDuLichForm.getTuKhoa().equals("dangNhap")){
			if (excute.kiemTraDangNhap(tenDangNhap, matKhau))
			{
				return mapping.findForward("trangChu");
			}
			else{
				danhSachTourDuLichForm.setTenDangNhap("");
				danhSachTourDuLichForm.setMatKhau("");
				return mapping.findForward("trangChu");
			}
		}
		else 
		if(danhSachTourDuLichForm.getTuKhoa().equals("dangXuat")){
			danhSachTourDuLichForm.setTenDangNhap("");
			danhSachTourDuLichForm.setMatKhau("");
			session.invalidate();
			danhSachTourDuLichForm.setTenDangNhap("");
			session=request.getSession();
			session.setAttribute("danhSachTourDuLichForm", danhSachTourDuLichForm);
			return mapping.findForward("dangxuat");
		}
		
			danhSachTourDuLichForm.setTenDangNhap("");
			danhSachTourDuLichForm.setMatKhau("");
			danhSachTourDuLichForm.setResultFail("Tài khoản mật khẩu không chính xác!");
			session=request.getSession();
			session.setAttribute("danhSachTourDuLichForm", danhSachTourDuLichForm);
			return mapping.findForward("trangChu");

	}
}