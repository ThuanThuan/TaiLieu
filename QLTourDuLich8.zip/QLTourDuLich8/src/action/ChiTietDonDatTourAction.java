package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.ChiTietDonDatTourForm;
import model.bean.DonDatTour;
import model.bo.DonDatTourBO;
/**
 * ChiTietDonDatTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ChiTietDonDatTourAction extends Action {
	   @Override
	   public ActionForward execute(ActionMapping mapping, ActionForm form,
	                                   HttpServletRequest request, HttpServletResponse response)
	                                   throws Exception {
	                   ChiTietDonDatTourForm donDatTourForm  = (ChiTietDonDatTourForm) form;
	                   DonDatTourBO donDatTourBO = new DonDatTourBO();
	                   int maDatTour = donDatTourForm.getMaDatTour();
	                   ArrayList<DonDatTour> listDonDatTour;
	                   listDonDatTour=donDatTourBO.getDonDatTour(maDatTour);
	                   donDatTourForm.setListDonDatTour(listDonDatTour);
	                   return mapping.findForward("done");
	   }

}
