package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.BaiViet;
import model.bean.DanhMuc;
import model.bean.KhuyenMai;
import model.bean.TaiKhoan;
import model.bean.TourDuLich;
import model.bo.DanhMucBO;
import model.bo.KhuyenMaiBO;
import model.bo.SuaBaiVietBO;
import model.bo.TourBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.SuaBaiVietForm;
import form.SuaTourDuLichForm;
/**
 * SuaTourDuLichAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaTourDuLichAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	SuaTourDuLichForm tourDuLichForm = (SuaTourDuLichForm) form;
	TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
	if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
		return mapping.findForward("dangnhap");
	}
	int maTour = tourDuLichForm.getMaTour();
	// lay thuoc tinh cac doi tuong
	TourBO tourBO = new TourBO();
	TourDuLich suaTour = tourBO.getThongTinTour(maTour);
	//lay danh sach cac dia diem
	DanhMucBO danhMucBO = new DanhMucBO();
	ArrayList<DanhMuc> listDanhMuc = danhMucBO.getListDanhMuc();
	tourDuLichForm.setListDanhMuc(listDanhMuc);
	KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();
	ArrayList<KhuyenMai> listKhuyenMai= khuyenMaiBO.getListKhuyenMai();
	tourDuLichForm.setListKhuyenMai(listKhuyenMai);
	tourDuLichForm.setMaDanhMuc(suaTour.getMaDanhMuc());
	tourDuLichForm.setMaKhuyenMai(suaTour.getMaKhuyenMai());
	tourDuLichForm.setTenTour(suaTour.getTenTour());
	tourDuLichForm.setDiemKhoiHanh(suaTour.getDiemKhoiHanh());
	tourDuLichForm.setThoiGian(suaTour.getThoiGian());
	tourDuLichForm.setPhuongTien(suaTour.getPhuongTien());
	tourDuLichForm.setLichTrinh(suaTour.getLichTrinh());
	tourDuLichForm.setHinhThuc(suaTour.getHinhThuc());
	tourDuLichForm.setGiaTour(suaTour.getGiaTour());
	tourDuLichForm.setHinhThuc(suaTour.getHinhThuc());
	tourDuLichForm.setAnh1(suaTour.getAnh1());
	tourDuLichForm.setAnh2(suaTour.getAnh2());
	tourDuLichForm.setAnh3(suaTour.getAnh3());
	tourDuLichForm.setTextEditor(suaTour.getTextEditor());
	tourDuLichForm.setEmail(suaTour.getEmail());
	tourDuLichForm.setDiemDen(suaTour.getDiemDen());
	tourDuLichForm.setGiaTourSau(suaTour.getGiaTourSau());
	return mapping.findForward("done");
}
}
