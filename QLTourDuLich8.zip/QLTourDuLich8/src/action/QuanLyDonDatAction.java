package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DangNhapForm;
import form.DanhSachTourDuLichForm;
import form.QuanLyDonDatForm;

import model.bo.DonDatTourBO;
/**
 * QuanLyDonDatAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLyDonDatAction extends Action {
   @Override
public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
		HttpServletResponse response) throws Exception {
	   System.out.println("toi day roi");
		QuanLyDonDatForm quanLyDonDatForm = (QuanLyDonDatForm) form;
		HttpSession session=request.getSession();
		DonDatTourBO dataTour = new DonDatTourBO();
		DanhSachTourDuLichForm danhSachTourDuLichForm= (DanhSachTourDuLichForm)request.getSession().getAttribute("danhSachTourDuLichForm");
		String maTK = danhSachTourDuLichForm.getTenDangNhap();
		String page = quanLyDonDatForm.getPage();
		try {
			if (Integer.parseInt(page) < 1)
				quanLyDonDatForm.setPage("1");
		} catch (Exception e) {
			quanLyDonDatForm.setPage("1");
		}
		System.out.println("ten dang nhap" +maTK);
		quanLyDonDatForm.setListDonDatTour(dataTour.getDonTourDuLichTaiKhoan(maTK));	
		System.out.println("toi day roi nha");
		return mapping.findForward("quanLyDonDat");
}
}
