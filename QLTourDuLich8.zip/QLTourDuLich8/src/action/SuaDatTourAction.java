package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminDonDatTourForm;
import model.bean.DonDatTour;
import model.bean.TaiKhoan;
import model.bean.TourDuLich;
import model.bo.DonDatTourBO;
import model.bo.TourBO;
/**
 * SuaDatTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class SuaDatTourAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	AdminDonDatTourForm dattourDuLichForm = (AdminDonDatTourForm) form;
	TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
	if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
		return mapping.findForward("dangnhap");
	}
	int maDatTour = dattourDuLichForm.getMaDatTour();
	// lay thuoc tinh cac doi tuong
	DonDatTourBO tourBO = new DonDatTourBO();
	DonDatTour suaTour = tourBO.getThongTinTour(maDatTour);
	//lay danh sach cac dia diem
	TourBO tour = new TourBO();
	ArrayList<TourDuLich> listTourDuLich = tour.getTenTour("");
	dattourDuLichForm.setListTourDuLich(listTourDuLich);
	dattourDuLichForm.setMaTour(suaTour.getMaTour());
	dattourDuLichForm.setSoNguoiLon(suaTour.getSoNguoiLon());
	dattourDuLichForm.setSoTreEm(suaTour.getSoTreEm());
	dattourDuLichForm.setThoiGianKhoiHanh(suaTour.getThoiGianKhoiHanh());
	dattourDuLichForm.setTongSoTien(suaTour.getTongSoTien());
	dattourDuLichForm.setHoTenNguoiDat(suaTour.getHoTenNguoiDat());
	dattourDuLichForm.setSoDienThoai(suaTour.getSoDienThoai());
	dattourDuLichForm.setEmail(suaTour.getEmail());
	dattourDuLichForm.setYeuCau(suaTour.getYeuCau());
	return mapping.findForward("done");
	}
}
