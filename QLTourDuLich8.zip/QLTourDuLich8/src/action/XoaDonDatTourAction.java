package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminDonDatTourForm;
import form.DonDatTourForm;
import form.SuaTourDuLichForm;
import model.bo.DonDatTourBO;
import model.bo.TourBO;
/**
 * XoaDonDatTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class XoaDonDatTourAction extends Action {
	@Override
	 public ActionForward execute(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception {
			// TODO Auto-generated method stub
		  AdminDonDatTourForm tourDuLichForm = (AdminDonDatTourForm) form;
			int maDatTour = tourDuLichForm.getMaDatTour();
			System.out.println("1234");
			DonDatTourBO donDattourBO = new DonDatTourBO();
			if (donDattourBO.deleteDatTour(maDatTour)) {
				return mapping.findForward("done");
			}
			return mapping.findForward("done");
		}
}
