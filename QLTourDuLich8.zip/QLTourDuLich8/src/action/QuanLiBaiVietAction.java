package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanLiBaiVietForm;
import model.bean.BaiViet;
import model.bean.TaiKhoan;
import model.bo.BaiVietBO;
/**
 * QuanLiBaiVietAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiBaiVietAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		QuanLiBaiVietForm baiVietForm = (QuanLiBaiVietForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
	
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			System.out.print("tai khoan khong du quyen ");
			return mapping.findForward("dangnhap");
		}
		String btnSubmit = baiVietForm.getSubmit();
		String txtFind = baiVietForm.getTxtFind();
		System.out.println(txtFind);
		BaiVietBO baiVietBO = new BaiVietBO();
		ArrayList<BaiViet> listBaiViet =baiVietBO.getListBaiViet(txtFind);
		ArrayList<BaiViet> listBaiVietTour =baiVietBO.getListBaiVietTour(txtFind);
		ArrayList<BaiViet> listBaiVietKhachSan =baiVietBO.getListBaiVietKhachSan(txtFind);
		ArrayList<BaiViet> listBaiVietTourKM = baiVietBO.getListBaiVietTourKM(txtFind);
		baiVietForm.setListBaiViet(listBaiViet);
		baiVietForm.setListBaiVietTour(listBaiVietTour);
		baiVietForm.setListBaiVietKhachSan(listBaiVietKhachSan);
		baiVietForm.setListBaiVietTourKM(listBaiVietTourKM);
		return mapping.findForward("done");
	}
}
