package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.QuanLiBinhLuanForm;
import model.bo.DanhSachTourBO;
/**
 * XoaBinhLuanAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class XoaBinhLuanAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		QuanLiBinhLuanForm quanLiBinhLuanForm = (QuanLiBinhLuanForm) form;
		
		DanhSachTourBO danhSachTourBO = new DanhSachTourBO();
		int maBinhLuan = quanLiBinhLuanForm.getMaBinhLuan();
		if(danhSachTourBO.deleteBinhLuan(maBinhLuan)){
			return mapping.findForward("done");
		}
		return mapping.findForward("list");
	}
	
	

}
