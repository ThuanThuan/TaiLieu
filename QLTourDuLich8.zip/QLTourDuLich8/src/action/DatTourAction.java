package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.DanhSachTourDuLichForm;
import form.DatTourDuLichForm;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bean.DonDatTour;
import model.bo.DanhMucBO;
import model.bo.DonDatTourBO;
import model.dao.FormatData;
/**
 * DatTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DatTourAction extends Action {
	@Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                 HttpServletRequest request, HttpServletResponse response)
                 throws Exception {
          DatTourDuLichForm datTourDuLichForm = (DatTourDuLichForm) form;
          DanhSachTourDuLichForm danhSachTourDuLichForm= (DanhSachTourDuLichForm)request.getSession().getAttribute("danhSachTourDuLichForm");    
          String maTKNguoiDung=danhSachTourDuLichForm.getTenDangNhap();
          DonDatTourBO donDatTourBO= new DonDatTourBO();
          DanhMucBO DBO=new DanhMucBO();
          ArrayList<DanhSachTour> listTour;
          int maTour=datTourDuLichForm.getMaTour();
          System.out.print(maTour);
          listTour=donDatTourBO.getTourDuLich(maTour);
          DanhSachTour giaTour=donDatTourBO.getTourDuLich1(maTour);
          datTourDuLichForm.setGiaTourSau(giaTour.getGiaTourSau());
          int giaTourSau = datTourDuLichForm.getGiaTourSau();
          int giaTienTreEm =(giaTourSau/2);
          datTourDuLichForm.setGiaTienTreEm(giaTienTreEm);
          int giaTienNguoiLon = giaTourSau;
          datTourDuLichForm.setGiaTienNguoiLon(giaTienNguoiLon);
          datTourDuLichForm.setListtour(listTour);
         System.out.print("danh sach tour:" +listTour.size());
         System.out.println("1");
          String submit =  StringProcess.toUTF8(datTourDuLichForm.getSubmit());
         String tinhTrang ="Chưa Thanh Toán";
          if ("ĐẶT TOUR".equals(submit)) {
        	  if(maTKNguoiDung==null){
        	  System.out.println("2");
        	  ArrayList<DanhMucTour> listDM;
        	  String maDanhMuc=datTourDuLichForm.getMaDanhMuc();
        	  listDM=DBO.getListDM();
      			datTourDuLichForm.setListDM(listDM);
                  maTour = datTourDuLichForm.getMaTour();
                 String maTK = datTourDuLichForm.getTaiKhoan();
                 System.out.println("ma tour:"+maTour + maTK);
                 int soNguoiLon = datTourDuLichForm.getSoNguoiLon() ;
                 int soTreEm =  datTourDuLichForm.getSoTreEm() ;
                 String thoiGianKhoiHanh = datTourDuLichForm.getThoiGianKhoiHanh();
                 int tongSoTien =  datTourDuLichForm.getTongSoTien();
                 String hoTenNguoiDat =  StringProcess.toUTF8(datTourDuLichForm.getHoTenNguoiDat())  ;
                 String soDienThoai = datTourDuLichForm.getSoDienThoai();
                 String email = datTourDuLichForm.getEmail();
                 String yeuCau =StringProcess.toUTF8( datTourDuLichForm.getYeuCau());
                 String queQuan =FormatData.toUTF8( datTourDuLichForm.getQueQuan());
                 System.out.println(queQuan);
                 donDatTourBO.themDonDatTour(maTour, soNguoiLon, soTreEm, thoiGianKhoiHanh, tongSoTien, hoTenNguoiDat, soDienThoai, email, yeuCau, maTK,queQuan,tinhTrang);
                 
                	   System.out.println("1234123");
	                  int maDatTour=datTourDuLichForm.getMaDatTour();
	                  System.out.print("ma dat tour:"+maDatTour);
	                   System.out.println();
	                   ArrayList<DonDatTour> listDonDatTour;
	                   ArrayList<DonDatTour> listDon;
	                   listDon=donDatTourBO.getDonDatTour();
//	                   listDonDatTour=donDatTourBO.getDonDatTour(maDatTour);
	                   datTourDuLichForm.setListDonDatTour(listDon);
	                   setDatTourDuLichFormNull(datTourDuLichForm);
                       return mapping.findForward("done");
       
                       }else   if(maTKNguoiDung!=null){
        	 
            	  System.out.println("2");
            	  ArrayList<DanhMucTour> listDM;
            	  String maDanhMuc=datTourDuLichForm.getMaDanhMuc();
            	  listDM=DBO.getListDM();
          			datTourDuLichForm.setListDM(listDM);
                      maTour = datTourDuLichForm.getMaTour();
         
                     System.out.println("ma tour:"+maTour + maTKNguoiDung);
                     int soNguoiLon = datTourDuLichForm.getSoNguoiLon() ;
                     int soTreEm =  datTourDuLichForm.getSoTreEm() ;
                     String thoiGianKhoiHanh = datTourDuLichForm.getThoiGianKhoiHanh();
                     int tongSoTien = datTourDuLichForm.getTongSoTien() ;
                     String hoTenNguoiDat =  StringProcess.toUTF8(datTourDuLichForm.getHoTenNguoiDat())  ;
                     String soDienThoai = datTourDuLichForm.getSoDienThoai();
                     String email = datTourDuLichForm.getEmail();
                     String yeuCau = StringProcess.toUTF8(datTourDuLichForm.getYeuCau());
                     String queQuan = FormatData.toUTF8(datTourDuLichForm.getQueQuan());
                     donDatTourBO.themDonDatTour(maTour, soNguoiLon, soTreEm, thoiGianKhoiHanh, tongSoTien, hoTenNguoiDat, soDienThoai, email, yeuCau, maTKNguoiDung,queQuan,tinhTrang);
                     
                    	   System.out.println("1234123");
    	                  int maDatTour=datTourDuLichForm.getMaDatTour();
    	                  System.out.print("ma dat tour:"+maDatTour);
    	                   System.out.println();
    	                   
    	                   ArrayList<DonDatTour> listDon;
    	                   listDon=donDatTourBO.getDonDatTour();
//    	                   listDonDatTour=donDatTourBO.getDonDatTour(maDatTour);
    	                   datTourDuLichForm.setListDonDatTour(listDon);
    	                   setDatTourDuLichFormNull(datTourDuLichForm);
                           return mapping.findForward("done");
        	 
              
        	  
           
          }
          }else{
          	
         	 return mapping.findForward("datTourDuLich");
          }
          return mapping.findForward("datTourDuLich");
	}


                
                 
        
         
          
          
          

   
   private void setDatTourDuLichFormNull(DatTourDuLichForm form){
          form.setSubmit(null);
          form.setEmail(null);
          form.setHoTenNguoiDat(null);
          form.setSoDienThoai(null);
          form.setEmail(null);
          form.setYeuCau(null);
          form.setThoiGianKhoiHanh(null);
          form.setQueQuan(null);
   }

}
