package action;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.bean.TaiKhoan;
import model.bo.DanhMucBO;
import model.dao.FormatData;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


import form.AdminDanhMucForm;
/**
 * UpdateDanhMucAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class UpdateDanhMucAction extends Action {
   @Override
public ActionForward execute(ActionMapping mapping, ActionForm form,
		HttpServletRequest request, HttpServletResponse response)
		throws Exception {
		request.setCharacterEncoding("utf-8");
		AdminDanhMucForm danhMucForm = (AdminDanhMucForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		    int maDanhMuc = danhMucForm.getMaDanhMuc();
			String tenDanhMuc =  FormatData.toUTF8(danhMucForm.getTenMonAn());
			String moTa =FormatData.toUTF8(danhMucForm.getMoTa());
			DanhMucBO danhMucBO = new DanhMucBO();
		
		//System.out.println("anh " +anh);
		if (danhMucBO.capNhatTenMonAn(maDanhMuc, tenDanhMuc, moTa)) {
			return mapping.findForward("done");
		}
		return mapping.findForward("done");
}
}
