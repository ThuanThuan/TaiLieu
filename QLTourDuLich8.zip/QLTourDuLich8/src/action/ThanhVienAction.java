package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.DanhSachTourDuLichForm;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bean.TaiKhoan;
import model.bo.DanhMucBO;
import model.bo.DanhSachTourBO;
import model.bo.TaiKhoanBO;
/**
 * ThanhVienAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThanhVienAction  extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
	   TaiKhoanBO taiKhoanBO = new TaiKhoanBO();
		DanhSachTourDuLichForm adminThongTinForm=(DanhSachTourDuLichForm)form;
		DanhSachTourBO dsBO=new DanhSachTourBO();
		ArrayList<DanhSachTour> listtour;
		ArrayList<DanhSachTour> listtoptour;
		listtour=dsBO.getListTour();
		listtoptour=dsBO.getListTopTour();
		adminThongTinForm.setListtour(listtour);
		adminThongTinForm.setListtoptour(listtoptour);
		DanhMucBO DBO=new DanhMucBO();
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		adminThongTinForm.setListDM(listDM);
		System.out.print("list danh muc");
		System.out.print("get list thanh cong");
		System.out.println(adminThongTinForm.getMaTour() + "Matour");
		String thaoTac = adminThongTinForm.getThaoTac();
		HttpSession session=request.getSession(); 
		session=request.getSession();
		String tenDangNhap = adminThongTinForm.getTenDangNhap();
		if (thaoTac != null ) {
			String user = adminThongTinForm.getTaiKhoan();
			String pass =StringProcess.md5( adminThongTinForm.getMatKhau());
			//String pass = adminThongTinForm.getMatKhau();
			TaiKhoan taiKhoan = taiKhoanBO.kiemTraThanhVien(user, pass);
			if (taiKhoan != null) {
				request.getSession().setAttribute("admin", taiKhoan);
				adminThongTinForm.setTenDangNhap(user);
				adminThongTinForm.setTaiKhoan(user);
				adminThongTinForm.setHoTen(taiKhoan.getHoTen());
				adminThongTinForm.setDiaChi(taiKhoan.getDiaChi());
				adminThongTinForm.setEmail(taiKhoan.getEmail());
				adminThongTinForm.setDienThoai(taiKhoan.getSoDienThoai());
				adminThongTinForm.setMatKhau(pass);
				System.out.println(user);
				return mapping.findForward("thanhcong");
			} 
	   else {
				adminThongTinForm.setResultFail("Tài khoản mật khẩu không chính xác!");
				adminThongTinForm.setTaiKhoan("");
				adminThongTinForm.setMatKhau("");
				return mapping.findForward("thatbai");
			}
	   } else {
			adminThongTinForm.setTaiKhoan("");
			adminThongTinForm.setMatKhau("");
			adminThongTinForm.setResultFail(null);
			return mapping.findForward("done");
		}
	   
	
	  
	   
	  
	}

}
