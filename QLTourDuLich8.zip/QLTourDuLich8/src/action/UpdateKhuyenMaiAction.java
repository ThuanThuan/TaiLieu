package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.TaiKhoan;
import model.bo.DanhMucBO;
import model.bo.KhuyenMaiBO;
import model.dao.FormatData;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminDanhMucForm;
import form.AdminKhuyenMaiForm;
import form.SuaKhuyenMaiForm;
/**
 * UpdateKhuyenMaiAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class UpdateKhuyenMaiAction extends Action {
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
    		HttpServletRequest request, HttpServletResponse response)
    		throws Exception {
    	request.setCharacterEncoding("utf-8");
		SuaKhuyenMaiForm khuyenMaiForm = (SuaKhuyenMaiForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		    int maKhuyenMai = khuyenMaiForm.getMaKhuyenMai();
			String tenKhuyenMai =  FormatData.toUTF8(khuyenMaiForm.getTenKhuyenMai());
			String hinhThucKhuyenMai =FormatData.toUTF8(khuyenMaiForm.getHinhThucKhuyenMai());
			KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();
		
		//System.out.println("anh " +anh);
		if (khuyenMaiBO.capNhatKhuyenMai(maKhuyenMai, tenKhuyenMai, hinhThucKhuyenMai)) {
			return mapping.findForward("done");
		}
		return mapping.findForward("done");
    }
}
