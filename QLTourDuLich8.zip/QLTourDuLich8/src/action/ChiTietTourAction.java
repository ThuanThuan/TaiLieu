package action;

import java.util.ArrayList;
/**
 * ChiTietTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.DanhSachTourDuLichForm;
import form.DanhSachTourForm;
import model.bean.BinhLuan;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bo.DanhMucBO;
import model.bo.DanhSachTourBO;
import model.dao.FormatData;
public class ChiTietTourAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachTourForm dsForm=(DanhSachTourForm)form;
		DanhSachTourDuLichForm danhSachTourDuLichForm= (DanhSachTourDuLichForm)request.getSession().getAttribute("danhSachTourDuLichForm");
		System.out.println("Form get: " + dsForm.toString());
		DanhSachTourBO dsBO=new DanhSachTourBO();
		ArrayList<DanhSachTour> listtourct;
		String maTour=dsForm.getMatour();
		String maTKNguoiDung = danhSachTourDuLichForm.getTenDangNhap();
		listtourct=dsBO.getListCT(maTour);
		dsForm.setListtour(listtourct);
		DanhMucBO DBO=new DanhMucBO();
		dsForm.setGoToBottom("false");
		String page = dsForm.getPage();
		
		try {
			if (Integer.parseInt(page) < 1)
				dsForm.setPage("1");
		} catch (Exception e) {
			dsForm.setPage("1");
		}
//		getlistdanh muc
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		dsForm.setListDM(listDM);
		
		String submit = dsForm.getSubmit();
		System.out.print(listtourct.size());
		System.out.print("size list tour:"+dsForm.getListtour().size());
		String noiDungBinhLuan =FormatData.toUTF8(dsForm.getNoiDungBinhLuan());
		dsForm.setKiemTraHoatDong("false");
		if(maTKNguoiDung!=null){
		if("Thích".equals(StringProcess.toUTF8(submit))){
			dsBO.setThichBaiViet(maTKNguoiDung,maTour);
			dsForm.setGoToBottom("true");
		}
		if("Không Thích".equals(StringProcess.toUTF8(submit))){
			dsBO.setKhongThichBaiViet(maTKNguoiDung,maTour);
			dsForm.setGoToBottom("true");
		}
		if(dsBO.kiemTraHoatDong(maTKNguoiDung,maTour)){
			dsForm.setKiemTraHoatDong("true");
		}
		if(!("".equals(maTKNguoiDung))){
		if("Đánh Giá".equals(StringProcess.toUTF8(submit))){
			
			int soSao=dsForm.getSoSao();
			System.out.println("sosao" + soSao);
			dsBO.setSoSaoDanhGia(maTKNguoiDung,maTour,soSao);
			dsForm.setGoToBottom("true");
			
		}
	
       if("Bình Luận".equals(StringProcess.toUTF8(submit))){
    	   if(!("".equals(noiDungBinhLuan))){
				if(	dsBO.themBinhLuan(maTKNguoiDung,maTour,noiDungBinhLuan)){
					System.out.println("thanh cong");
					dsForm.setNoiDungBinhLuan("");
					dsForm.setGoToBottom("true");
				}
					
				}
    	 
       
			}
       
          
		}
		  
	}
		
		if("Hàng Đầu".equals(StringProcess.toUTF8(submit))){
			ArrayList<BinhLuan> listBinhLuan1;
			  listBinhLuan1 = dsBO.getListBinhLuanMoiNhat(maTour);
			  dsForm.setListBinhLuan(listBinhLuan1);
		}else if("Cũ Nhất".equals(StringProcess.toUTF8(submit))){
			ArrayList<BinhLuan> listBinhLuan1;
			  listBinhLuan1 = dsBO.getListBinhLuanCuNhat(maTour);
			  dsForm.setListBinhLuan(listBinhLuan1);
		}else if("Tất Cả".equals(StringProcess.toUTF8(submit))){
			ArrayList<BinhLuan> listBinhLuan1;
			  listBinhLuan1 = dsBO.getListBinhLuan(maTour);
			  dsForm.setListBinhLuan(listBinhLuan1);
		}
			
		ArrayList<BinhLuan> listBinhLuan1;
		listBinhLuan1 = dsBO.getListBinhLuan(maTour);
	     dsForm.setListBinhLuan(listBinhLuan1);	
		
		return mapping.findForward("chitiettour");
	}
}
