package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachTourDuLichForm;
import form.SuaBaiVietForm;
import form.SuaTourDuLichForm;
import model.bo.DeleteBaiVietBO;
import model.bo.TourBO;
/**
 * XoaTourDuLichAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class XoaTourDuLichAction extends Action {

  @Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
	  SuaTourDuLichForm tourDuLichForm = (SuaTourDuLichForm) form;
		int maTour = tourDuLichForm.getMaTour();
		System.out.println("1234");
		TourBO tourBO = new TourBO();
		if (tourBO.deleteTourDuLich(maTour)) {
			return mapping.findForward("done");
		}
		return mapping.findForward("done");
	}
}
