package action;

import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import common.StringProcess;
import form.SuaBaiVietForm;
import model.bean.TaiKhoan;
import model.bo.UpdateBaiVietBO;
/**
 * UpdateBaiVietAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class UpdateBaiVietAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		SuaBaiVietForm Form = (SuaBaiVietForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		String anh1 = "";
		String anh2 = "";
		String anh3 = "";
		int maBaiViet = Form.getMaBaiViet();
		String textTieuDeBaiViet = StringProcess.toUTF8(Form
				.getTextTieuDeBaiViet());
		int maDanhMuc = Form.getMaDanhMuc();
		String textDiaChi = StringProcess.toUTF8(Form.getTextDiaChi());
		String textMoTa = StringProcess.toUTF8(Form.getTextMoTa());
		String textEditor = StringProcess.toUTF8(Form.getTextEditor());
		UpdateBaiVietBO updateBaiVietBO = new UpdateBaiVietBO();
		
		
		FormFile file = Form.getFile();
		anh1 = taiAnhLen(file, request);
		anh2 = taiAnhLen(file, request);
		anh3 = taiAnhLen(file, request);
		
		//System.out.println("anh " +anh);
		if (updateBaiVietBO.updateBaiViet(maBaiViet, textTieuDeBaiViet,
			 maDanhMuc, textDiaChi, textMoTa, textEditor,anh1,anh2,anh3)) {
			return mapping.findForward("done");

		}
		return mapping.findForward("done");
	}

	private String taiAnhLen(FormFile file, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String fileName = "";
		try {
			fileName = file.getFileName();
			// Get the servers upload directory real path name
			String filePath = getServlet().getServletContext().getRealPath("/")
					+ "upload";
			// create the upload folder if not exists
			File folder = new File(filePath);
			if (!folder.exists()) {
				folder.mkdir();
			}
			if (!("").equals(fileName)) {

				System.out.println("Server path:" + filePath);
				File newFile = new File(filePath, fileName);

				if (!newFile.exists()) {
					FileOutputStream fos = new FileOutputStream(newFile);
					fos.write(file.getFileData());
					fos.flush();
					fos.close();
				}

				request.setAttribute("uploadedFilePath", newFile
						.getAbsoluteFile());
				request.setAttribute("uploadedFileName", newFile.getName());
				String mypath = "C:\\workspace\\QLDuLich\\WebContent\\anhbaiviet\\"
						+ newFile.getName();
				FileUtils.copyFile(
						new File(filePath + "\\" + newFile.getName()),
						new File(mypath));
			}
		} catch (Exception e) {
			return null;
		}

		return fileName;
	}
}
