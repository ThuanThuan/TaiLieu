package action;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import form.AdminDonDatTourForm;
import form.SuaTourDuLichForm;
import model.bean.DanhMuc;
import model.bean.KhuyenMai;
import model.bean.TaiKhoan;
import model.bean.TourDuLich;
import model.bo.DanhMucBO;
import model.bo.DonDatTourBO;
import model.bo.KhuyenMaiBO;
import model.bo.TourBO;
import model.dao.FormatData;
/**
 * UpdateDatTourAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class UpdateDatTourAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("utf-8");
		AdminDonDatTourForm tourDuLichForm = (AdminDonDatTourForm) form;
		TaiKhoan admin = (TaiKhoan) request.getSession().getAttribute("admin");
		if (admin == null || (admin != null && admin.getLoaiTaiKhoan() != -1)) {
			return mapping.findForward("dangnhap");
		}
		TourBO tour = new TourBO();
		ArrayList<TourDuLich> listTourDuLich = tour.getListTourDuLich("");
		tourDuLichForm.setListTourDuLich(listTourDuLich);
		    int maDatTour =tourDuLichForm.getMaDatTour();
		    int maTour = tourDuLichForm.getMaTour();
			int  soNguoiLon = tourDuLichForm.getSoNguoiLon();
			int soTreEm =tourDuLichForm.getSoTreEm();
			String thoiGianKhoiHanh = FormatData.toUTF8(tourDuLichForm.getThoiGianKhoiHanh());
			int tongSoTien = tourDuLichForm.getTongSoTien()	;
			String hoTenNguoiDat = FormatData.toUTF8(tourDuLichForm.getHoTenNguoiDat());
			String soDienThoai = FormatData.toUTF8(tourDuLichForm.getSoDienThoai());
			String email = FormatData.toUTF8(tourDuLichForm.getEmail());
			String yeuCau = FormatData.toUTF8(tourDuLichForm.getYeuCau());
			DonDatTourBO datTourBO = new DonDatTourBO();
		
		//System.out.println("anh " +anh);
		if (datTourBO.updateDonDatTour(maDatTour, maTour,soNguoiLon, soTreEm, thoiGianKhoiHanh, tongSoTien, hoTenNguoiDat, soDienThoai, email, yeuCau)) {
			return mapping.findForward("done");
		}
		return mapping.findForward("done");
		
		
	}
		
	private String taiAnhLen(FormFile file, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String fileName = "";
		try {
			fileName = file.getFileName();
			// Get the servers upload directory real path name
			String filePath = getServlet().getServletContext().getRealPath("/")
					+ "upload";
			// create the upload folder if not exists
			File folder = new File(filePath);
			if (!folder.exists()) {
				folder.mkdir();
			}
			if (!("").equals(fileName)) {

				System.out.println("Server path:" + filePath);
				File newFile = new File(filePath, fileName);

				if (!newFile.exists()) {
					FileOutputStream fos = new FileOutputStream(newFile);
					fos.write(file.getFileData());
					fos.flush();
					fos.close();
				}

				request.setAttribute("uploadedFilePath", newFile
						.getAbsoluteFile());
				request.setAttribute("uploadedFileName", newFile.getName());
				String mypath = "C:\\workspace\\QLDuLich\\WebContent\\anhbaiviet\\"
						+ newFile.getName();
				FileUtils.copyFile(
						new File(filePath + "\\" + newFile.getName()),
						new File(mypath));
			}
		} catch (Exception e) {
			return null;
		}

		return fileName;
	}
}
