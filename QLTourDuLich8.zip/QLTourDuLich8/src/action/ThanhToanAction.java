package action;


import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;




import common.StringProcess;
import form.DatTourDuLichForm;
import model.bean.DonDatTour;
import model.bo.DonDatTourBO;



public class ThanhToanAction extends Action {
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
    		HttpServletResponse response) throws Exception {
    	DatTourDuLichForm datTourDuLichForm =(DatTourDuLichForm) form;
    	DonDatTourBO donDatTourBO = new DonDatTourBO();
    	int maDatTour = datTourDuLichForm.getMaDatTour();
    	System.out.println("mã d?t tour" + maDatTour);
    	DonDatTour datTour= donDatTourBO.getThongTinTour(maDatTour);
    	String submit= datTourDuLichForm.getSubmit();
    	datTourDuLichForm.setTongSoTien(datTour.getTongSoTien());
    	datTourDuLichForm.setMaTour(datTour.getMaTour());
     	datTourDuLichForm.setSoNguoiLon(datTour.getSoNguoiLon());
     	int a= datTourDuLichForm.getSoNguoiLon();
     	int b =datTourDuLichForm.getSoTreEm();
    	datTourDuLichForm.setSoTreEm(datTour.getSoTreEm());
    	datTourDuLichForm.setDiemKhoiHanh(datTour.getDiemKhoiHanh());
    	datTourDuLichForm.setPhuongTien(datTour.getPhuongTien());
    	datTourDuLichForm.setHoTenNguoiDat(datTour.getHoTenNguoiDat());
    	datTourDuLichForm.setQueQuan(datTour.getQueQuan());
    	datTourDuLichForm.setSoDienThoai(datTour.getSoDienThoai());
    	datTourDuLichForm.setEmail(datTour.getEmail());
    	datTourDuLichForm.setTongSoTien(datTour.getTongSoTien());
    	datTourDuLichForm.setTenTour(datTour.getTenTour());
    	datTourDuLichForm.setThoiGian(datTour.getThoiGian());
    	datTourDuLichForm.setDiemDen(datTour.getDiemDen());
    	datTourDuLichForm.setGiaTourSau(datTour.getGiaTourSau());
    	int giaTourSau=datTourDuLichForm.getGiaTourSau();
    	datTourDuLichForm.setTacVu("");
    	int rand;
		int giaTienTreEm=((giaTourSau/2)*b);
		System.out.println("gia tien tre em" + giaTienTreEm);
		datTourDuLichForm.setGiaTienTreEm(giaTienTreEm);
		int giaTienNguoiLon=giaTourSau*a;
		datTourDuLichForm.setGiaTienNguoiLon(giaTienNguoiLon);
    	 rand = rand(1000, 9999);
    	String maXacNhan = String.valueOf(rand);
    	datTourDuLichForm.setMaXacNhan(maXacNhan);
    	String tinhTrang="Ðã Thanh Toán";
    	  if ("TIẾP TỤC".equals(StringProcess.toUTF8(submit))) {
    			
    		    if(donDatTourBO.updateDonDatTour1(tinhTrang, maDatTour)){
    		    	datTourDuLichForm.setTacVu("thanhcong");
    		    	datTourDuLichForm.setTenChuTaiKhoan("");
    		    	datTourDuLichForm.setConfirmMaXacNhan("");	    
    		    	datTourDuLichForm.setNgayThanhToan("");
    		    	
    		    	
    		    }
    			}
    		 			
  			
    		  
    	  
    	return mapping.findForward("thanhToan");
    	
    }
    public static int rand(int min, int max) {
        try {
            Random rn = new Random();
            int range = max - min + 1;
            int randomNum = min + rn.nextInt(range);
            return randomNum;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }
}