package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.KhuyenMai;
import model.bo.KhuyenMaiBO;
import model.bo.TourBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.AdminKhuyenMaiForm;
import form.SuaTourDuLichForm;
/**
 * XoaKhuyenMaiAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class XoaKhuyenMaiAction extends Action {
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
    		HttpServletRequest request, HttpServletResponse response)
    		throws Exception {
    	AdminKhuyenMaiForm adminKhuyenMaiForm = (AdminKhuyenMaiForm) form;
 		int maKhuyenMai = adminKhuyenMaiForm.getMaKhuyenMai();
 		
 		KhuyenMaiBO khuyenMaiBO = new KhuyenMaiBO();
 		if (khuyenMaiBO.deleteKhuyenMai(maKhuyenMai)) {
 			return mapping.findForward("done");
 		}
 		return mapping.findForward("done");
    }
}
