package action;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.upload.FormFile;

import common.StringProcess;
import form.DangKyForm;
import model.bean.DanhMucTour;
import model.bo.DanhMucBO;
import model.bo.TaiKhoanBO;
import model.dao.FormatData;
/**
 * DangKyAction.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

public class DangKyAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	
		System.out.println("phuong");
		Date date = new Date();
		DangKyForm dangKyForm = (DangKyForm) form;
		DanhMucBO DBO=new DanhMucBO();
		//validate du lieu
		ArrayList<DanhMucTour> listDM;
		listDM=DBO.getListDM();
		String anh ="";
		dangKyForm.setListDM(listDM);
		
		if("Đăng Ký".equals(StringProcess.toUTF8(dangKyForm.getSubmit()))){
			ActionErrors actionErrors = new ActionErrors();
			if(FormatData.notVaild(dangKyForm.getMaTK())){
				actionErrors.add("maTKError", new ActionMessage(StringProcess.toUTF8("error.username")));				
			}
			
			if(FormatData.notVaild(dangKyForm.getMatKhau())){
				actionErrors.add("matKhauError", new ActionMessage(StringProcess.toUTF8("error.password")));				
			}
			if(FormatData.notVaild(dangKyForm.getConfirmMatKhau())){
				actionErrors.add("matKhauError1", new ActionMessage(StringProcess.toUTF8("error.cfpassword")));				
			}
			if(!((dangKyForm.getConfirmMatKhau()).equals(dangKyForm.getMatKhau()))){
				actionErrors.add("matKhauError2", new ActionMessage(StringProcess.toUTF8("error.password0")));
			}
			
			if(FormatData.notVaild(dangKyForm.getHoTen())){
				actionErrors.add("hoTenError", new ActionMessage(StringProcess.toUTF8("error.hoten")));				
			}
			
			if(FormatData.notVaild(dangKyForm.getEmail())){
				actionErrors.add("emailError", new ActionMessage(StringProcess.toUTF8("error.dcemail")));
			}
			if(FormatData.notVaildEmail(dangKyForm.getEmail())){
				actionErrors.add("emailError1", new ActionMessage(StringProcess.toUTF8("error.fmemail")));				
			}
			
			if(FormatData.notVaild(dangKyForm.getNgaySinh())){
				actionErrors.add("ngaySinhError", new ActionMessage(StringProcess.toUTF8("error.ngay")));				
			}
			
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("dkThatBai");
			}
		}
		
		
		if("Đăng Ký".equals(StringProcess.toUTF8(dangKyForm.getSubmit()))){		//nhan nut Dang Ky
			String maTK = dangKyForm.getMaTK();
			String matKhau =StringProcess.md5( dangKyForm.getMatKhau());
			//String matKhau = dangKyForm.getMatKhau();
			String hoTen = StringProcess.toUTF8(dangKyForm.getHoTen());
			String email = FormatData.toUTF8(dangKyForm.getEmail());
			String diaChi = FormatData.toUTF8(dangKyForm.getDiaChi());
			String ngaySinh =FormatData.toUTF8( dangKyForm.getNgaySinh());
			Integer gioiTinh = dangKyForm.getGioiTinh();
			String soDienThoai = dangKyForm.getSoDienThoai();
			String soThich =StringProcess.toUTF8( dangKyForm.getSoThich());
			Integer tinhTrang =dangKyForm.getTinhTrang();
			FormFile file1 = dangKyForm.getFile1();
			anh = taiAnhLen(file1, request);
			String ngayThamGia = FormatData.sdf.format(date);
			TaiKhoanBO taikhoanBO = new TaiKhoanBO();
			taikhoanBO.dangKy(maTK, matKhau, hoTen, email, diaChi, ngaySinh, gioiTinh, soDienThoai, soThich, tinhTrang, anh, ngayThamGia);
			System.out.println("Action thanh cong");
			return mapping.findForward("dkThanhCong");
		} else {
			System.out.println("Action That bai");
			return mapping.findForward("dkThatBai");
		}
	}
	
	private String taiAnhLen(FormFile file, HttpServletRequest request) {
		// TODO Auto-generated method stub
		String fileName = "";
		try {
			fileName = file.getFileName();
			// Get the servers upload directory real path name
			String filePath = getServlet().getServletContext().getRealPath("/")
					+ "upload";
			// create the upload folder if not exists
			File folder = new File(filePath);
			if (!folder.exists()) {
				folder.mkdir();
			}
			if (!("").equals(fileName)) {

				System.out.println("Server path:" + filePath);
				File newFile = new File(filePath, fileName);

				if (!newFile.exists()) {
					FileOutputStream fos = new FileOutputStream(newFile);
					fos.write(file.getFileData());
					fos.flush();
					fos.close();
				}

				request.setAttribute("uploadedFilePath", newFile
						.getAbsoluteFile());
				request.setAttribute("uploadedFileName", newFile.getName());
				String mypath = "C:\\workspace\\QLDuLich\\WebContent\\anhbaiviet\\"
						+ newFile.getName();
				FileUtils.copyFile(
						new File(filePath + "\\" + newFile.getName()),
						new File(mypath));
				// ImageResize.resizeImage(mypath);
			}
		} catch (Exception e) {
			return null;
		}

		return fileName;
	}

}
