package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.Login;
/**
 * LoginForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class LoginForm extends ActionForm

{
	private String userName;
	private String passWord;
	
	private ArrayList<Login> listThanhVien;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public ArrayList<Login> getListThanhVien() {
		return listThanhVien;
	}
	public void setListThanhVien(ArrayList<Login> listThanhVien) {
		this.listThanhVien = listThanhVien;
	}
	
}
