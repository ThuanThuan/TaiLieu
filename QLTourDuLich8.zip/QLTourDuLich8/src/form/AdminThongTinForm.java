package form;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
/**
 * AdminThongTinForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class AdminThongTinForm extends ActionForm {

	private static final long serialVersionUID = 1L;

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request){
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			return;
		}
	}
	
	private String taiKhoan;
	private String hoTen;
	private String diaChi;
	private String email;
	private String dienThoai;
	private String matKhau;
	private String matKhauCu;
	private String matKhauMoi;
	private String matKhauLai;
	private String daiDien;
	private String thaoTac;
	private String resultOk;
	private String resultFail;
	
	public String getTaiKhoan() {
		return taiKhoan;
	}
	
	public void setTaiKhoan(String taiKhoan) {
		this.taiKhoan = taiKhoan;
	}
	
	public String getHoTen() {
		return hoTen;
	}
	
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	
	public String getDiaChi() {
		return diaChi;
	}
	
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getDienThoai() {
		return dienThoai;
	}
	
	public void setDienThoai(String dienThoai) {
		this.dienThoai = dienThoai;
	}
	
	public String getMatKhau() {
		return matKhau;
	}
	
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	
	public String getMatKhauCu() {
		return matKhauCu;
	}

	public void setMatKhauCu(String matKhauCu) {
		this.matKhauCu = matKhauCu;
	}

	public String getMatKhauMoi() {
		return matKhauMoi;
	}

	public void setMatKhauMoi(String matKhauMoi) {
		this.matKhauMoi = matKhauMoi;
	}

	public String getMatKhauLai() {
		return matKhauLai;
	}

	public void setMatKhauLai(String matKhauLai) {
		this.matKhauLai = matKhauLai;
	}

	public String getDaiDien() {
		return daiDien;
	}
	
	public void setDaiDien(String daiDien) {
		this.daiDien = daiDien;
	}
	
	public String getThaoTac() {
		return thaoTac;
	}
	
	public void setThaoTac(String thaoTac) {
		this.thaoTac = thaoTac;
	}

	public String getResultOk() {
		return resultOk;
	}

	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}

	public String getResultFail() {
		return resultFail;
	}

	public void setResultFail(String resultFail) {
		this.resultFail = resultFail;
	}
}
