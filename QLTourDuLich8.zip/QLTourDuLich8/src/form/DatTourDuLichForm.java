package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bean.DonDatTour;
/**
 * DatTourDuLichForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DatTourDuLichForm extends ActionForm {
	private int maDatTour;
	private int maTour;
	private int maPhuongThucThanhToan;
	private int soNguoiLon;
	private int soTreEm;
	private String thoiGianKhoiHanh;
	private int tongSoTien;
	private String hoTenNguoiDat;
	private String soDienThoai;
	private String email;
	private String yeuCau;
	private String submit;
	private String giaTourTinh;
	private String kiemTraDatTour;
	private String taiKhoan;
	private int giaTour;
	private String diaChiBaiViet;
	private String tenDanhMuc;
	private String maDanhMuc;
	private String queQuan;
	private ArrayList<DanhMucTour> listDM;
	private int giaTourSau;
	private String nganHang;
	private String tenChuTaiKhoan;
	private String soTaiKhoan;
	private String maXacNhan;
   private String tacVu;
   private String confirmMaXacNhan;
   private String ngayThanhToan;
   private String thoiGian;
   private String diemDen;
   private int giaTienTreEm;
   private int giaTienNguoiLon;
   
   
   
	
	
   


	public int getGiaTienTreEm() {
	return giaTienTreEm;
}


public void setGiaTienTreEm(int giaTienTreEm) {
	this.giaTienTreEm = giaTienTreEm;
}


public int getGiaTienNguoiLon() {
	return giaTienNguoiLon;
}


public void setGiaTienNguoiLon(int giaTienNguoiLon) {
	this.giaTienNguoiLon = giaTienNguoiLon;
}


	public String getDiemDen() {
	return diemDen;
}


public void setDiemDen(String diemDen) {
	this.diemDen = diemDen;
}


	public String getThoiGian() {
	return thoiGian;
}


public void setThoiGian(String thoiGian) {
	this.thoiGian = thoiGian;
}


	public String getNgayThanhToan() {
	return ngayThanhToan;
}


public void setNgayThanhToan(String ngayThanhToan) {
	this.ngayThanhToan = ngayThanhToan;
}


	public String getNganHang() {
	return nganHang;
}


public void setNganHang(String nganHang) {
	this.nganHang = nganHang;
}


public String getTenChuTaiKhoan() {
	return tenChuTaiKhoan;
}


public void setTenChuTaiKhoan(String tenChuTaiKhoan) {
	this.tenChuTaiKhoan = tenChuTaiKhoan;
}


public String getSoTaiKhoan() {
	return soTaiKhoan;
}


public void setSoTaiKhoan(String soTaiKhoan) {
	this.soTaiKhoan = soTaiKhoan;
}


public String getMaXacNhan() {
	return maXacNhan;
}


public void setMaXacNhan(String maXacNhan) {
	this.maXacNhan = maXacNhan;
}


public String getTacVu() {
	return tacVu;
}


public void setTacVu(String tacVu) {
	this.tacVu = tacVu;
}


public String getConfirmMaXacNhan() {
	return confirmMaXacNhan;
}


public void setConfirmMaXacNhan(String confirmMaXacNhan) {
	this.confirmMaXacNhan = confirmMaXacNhan;
}


	public int getGiaTourSau() {
		return giaTourSau;
	}


	public void setGiaTourSau(int giaTourSau) {
		this.giaTourSau = giaTourSau;
	}


	public ArrayList<DanhMucTour> getListDM() {
		return listDM;
	}

    
	public String getQueQuan() {
		return queQuan;
	}


	public void setQueQuan(String queQuan) {
		this.queQuan = queQuan;
	}


	public String getTenDanhMuc() {
		return tenDanhMuc;
	}


	public void setTenDanhMuc(String tenDanhMuc) {
		this.tenDanhMuc = tenDanhMuc;
	}


	public String getMaDanhMuc() {
		return maDanhMuc;
	}


	public void setMaDanhMuc(String maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}


	public void setListDM(ArrayList<DanhMucTour> listDM) {
		this.listDM = listDM;
	}

	public String getTenTour() {
		return tenTour;
	}

	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public String getDiemKhoiHanh() {
		return diemKhoiHanh;
	}

	public void setDiemKhoiHanh(String diemKhoiHanh) {
		this.diemKhoiHanh = diemKhoiHanh;
	}

	public String getPhuongTien() {
		return phuongTien;
	}

	public void setPhuongTien(String phuongTien) {
		this.phuongTien = phuongTien;
	}

	public String getHinhThuc() {
		return hinhThuc;
	}

	public void setHinhThuc(String hinhThuc) {
		this.hinhThuc = hinhThuc;
	}

	public ArrayList<DonDatTour> getListDonDatTour() {
		return listDonDatTour;
	}

	public void setListDonDatTour(ArrayList<DonDatTour> listDonDatTour) {
		this.listDonDatTour = listDonDatTour;
	}

	private String tenTour;
    private String diaChi;
    
    private String diemKhoiHanh;
    private String phuongTien;
    private String hinhThuc;
    private ArrayList<DonDatTour> listDonDatTour;
	private ArrayList<DanhSachTour> listtour;

	public String getDiaChiBaiViet() {
		return diaChiBaiViet;
	}

	public void setDiaChiBaiViet(String diaChiBaiViet) {
		this.diaChiBaiViet = diaChiBaiViet;
	}

	public ArrayList<DanhSachTour> getListtour() {
		return listtour;
	}

	public void setListtour(ArrayList<DanhSachTour> listtour) {
		this.listtour = listtour;
	}

	

	public int getGiaTour() {
		return giaTour;
	}


	public void setGiaTour(int giaTour) {
		this.giaTour = giaTour;
	}


	public int getMaDatTour() {
		return maDatTour;
	}

	public void setMaDatTour(int maDatTour) {
		this.maDatTour = maDatTour;
	}

	public int getMaTour() {
		return maTour;
	}

	public void setMaTour(int maTour) {
		this.maTour = maTour;
	}

	public int getMaPhuongThucThanhToan() {
		return maPhuongThucThanhToan;
	}

	public void setMaPhuongThucThanhToan(int maPhuongThucThanhToan) {
		this.maPhuongThucThanhToan = maPhuongThucThanhToan;
	}

	

	public int getSoNguoiLon() {
		return soNguoiLon;
	}


	public void setSoNguoiLon(int soNguoiLon) {
		this.soNguoiLon = soNguoiLon;
	}


	public int getSoTreEm() {
		return soTreEm;
	}


	public void setSoTreEm(int soTreEm) {
		this.soTreEm = soTreEm;
	}


	public String getThoiGianKhoiHanh() {
		return thoiGianKhoiHanh;
	}

	public void setThoiGianKhoiHanh(String thoiGianKhoiHanh) {
		this.thoiGianKhoiHanh = thoiGianKhoiHanh;
	}

	

	public int getTongSoTien() {
		return tongSoTien;
	}


	public void setTongSoTien(int tongSoTien) {
		this.tongSoTien = tongSoTien;
	}


	public String getHoTenNguoiDat() {
		return hoTenNguoiDat;
	}

	public void setHoTenNguoiDat(String hoTenNguoiDat) {
		this.hoTenNguoiDat = hoTenNguoiDat;
	}

	public String getSoDienThoai() {
		return soDienThoai;
	}

	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getYeuCau() {
		return yeuCau;
	}

	public void setYeuCau(String yeuCau) {
		this.yeuCau = yeuCau;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	public String getGiaTourTinh() {
		return giaTourTinh;
	}

	public void setGiaTourTinh(String giaTourTinh) {
		this.giaTourTinh = giaTourTinh;
	}

	public String getKiemTraDatTour() {
		return kiemTraDatTour;
	}

	public void setKiemTraDatTour(String kiemTraDatTour) {
		this.kiemTraDatTour = kiemTraDatTour;
	}

	public String getTaiKhoan() {
		return taiKhoan;
	}

	public void setTaiKhoan(String taiKhoan) {
		this.taiKhoan = taiKhoan;
	}

}