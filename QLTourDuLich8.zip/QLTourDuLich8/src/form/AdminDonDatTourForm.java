package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DonDatTour;
import model.bean.TaiKhoan;
import model.bean.TourDuLich;
/**
 * AdminDonDatTourForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class AdminDonDatTourForm extends ActionForm {
  private int maTour;
  private int maDatTour;
  private int maTK;
  private int soNguoiLon;
  private int soTreEm;
  private String thoiGianKhoiHanh;
  private int tongSoTien;
  private String hoTenNguoiDat;
  private String soDienThoai;
  private String email;
  private String yeuCau;
  private String submit="";
  private ArrayList<DonDatTour> listDonDatTour;
  private ArrayList<TourDuLich> listTourDuLich;
  private ArrayList<TaiKhoan> listTaiKhoan;
public int getMaTour() {
	return maTour;
}
public void setMaTour(int maTour) {
	this.maTour = maTour;
}
public int getMaDatTour() {
	return maDatTour;
}
public void setMaDatTour(int maDatTour) {
	this.maDatTour = maDatTour;
}
public int getMaTK() {
	return maTK;
}
public void setMaTK(int maTK) {
	this.maTK = maTK;
}
public int getSoNguoiLon() {
	return soNguoiLon;
}
public void setSoNguoiLon(int soNguoiLon) {
	this.soNguoiLon = soNguoiLon;
}
public int getSoTreEm() {
	return soTreEm;
}
public void setSoTreEm(int soTreEm) {
	this.soTreEm = soTreEm;
}
public String getThoiGianKhoiHanh() {
	return thoiGianKhoiHanh;
}
public void setThoiGianKhoiHanh(String thoiGianKhoiHanh) {
	this.thoiGianKhoiHanh = thoiGianKhoiHanh;
}
public int getTongSoTien() {
	return tongSoTien;
}
public void setTongSoTien(int tongSoTien) {
	this.tongSoTien = tongSoTien;
}
public String getHoTenNguoiDat() {
	return hoTenNguoiDat;
}
public void setHoTenNguoiDat(String hoTenNguoiDat) {
	this.hoTenNguoiDat = hoTenNguoiDat;
}
public String getSoDienThoai() {
	return soDienThoai;
}
public void setSoDienThoai(String soDienThoai) {
	this.soDienThoai = soDienThoai;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getYeuCau() {
	return yeuCau;
}
public void setYeuCau(String yeuCau) {
	this.yeuCau = yeuCau;
}
public String getSubmit() {
	return submit;
}
public void setSubmit(String submit) {
	this.submit = submit;
}
public ArrayList<DonDatTour> getListDonDatTour() {
	return listDonDatTour;
}
public void setListDonDatTour(ArrayList<DonDatTour> listDonDatTour) {
	this.listDonDatTour = listDonDatTour;
}
public ArrayList<TourDuLich> getListTourDuLich() {
	return listTourDuLich;
}
public void setListTourDuLich(ArrayList<TourDuLich> listTourDuLich) {
	this.listTourDuLich = listTourDuLich;
}
public ArrayList<TaiKhoan> getListTaiKhoan() {
	return listTaiKhoan;
}
public void setListTaiKhoan(ArrayList<TaiKhoan> listTaiKhoan) {
	this.listTaiKhoan = listTaiKhoan;
}
  
}
