package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DonDatTour;
/**
 * ChiTietDonDatTourForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ChiTietDonDatTourForm extends ActionForm {
    private int maDatTour;
    private int maTour;
    private int soNguoiLon;
    private int soTreEm;
    private int tongSoTien;
    private int hoTenNguoiDat;
    private String tenTour;
    private String diaChi;
    private String soDienThoai;
    private String email;
    private String giaTour;
    private String diemKhoiHanh;
    private String phuongTien;
    private String hinhThuc;
    private String taiKhoan;
    public String getTaiKhoan() {
		return taiKhoan;
	}
	public void setTaiKhoan(String taiKhoan) {
		this.taiKhoan = taiKhoan;
	}
	private ArrayList<DonDatTour> listDonDatTour;
    public ArrayList<DonDatTour> getListDonDatTour() {
              return listDonDatTour;
       }
       public void setListDonDatTour(ArrayList<DonDatTour> listDonDatTour) {
              this.listDonDatTour = listDonDatTour;
       }
       public int getMaDatTour() {
              return maDatTour;
       }
       public void setMaDatTour(int maDatTour) {
              this.maDatTour = maDatTour;
       }
       public int getMaTour() {
              return maTour;
       }
       public void setMaTour(int maTour) {
              this.maTour = maTour;
       }
       public int getSoNguoiLon() {
              return soNguoiLon;
       }
       public void setSoNguoiLon(int soNguoiLon) {
              this.soNguoiLon = soNguoiLon;
       }
       public int getSoTreEm() {
              return soTreEm;
       }
       public void setSoTreEm(int soTreEm) {
              this.soTreEm = soTreEm;
       }
       public int getTongSoTien() {
              return tongSoTien;
       }
       public void setTongSoTien(int tongSoTien) {
              this.tongSoTien = tongSoTien;
       }
       public int getHoTenNguoiDat() {
              return hoTenNguoiDat;
       }
       public void setHoTenNguoiDat(int hoTenNguoiDat) {
              this.hoTenNguoiDat = hoTenNguoiDat;
       }
       public String getTenTour() {
              return tenTour;
       }
       public void setTenTour(String tenTour) {
              this.tenTour = tenTour;
       }
       public String getDiaChi() {
              return diaChi;
       }
       public void setDiaChi(String diaChi) {
              this.diaChi = diaChi;
       }
       public String getSoDienThoai() {
              return soDienThoai;
       }
       public void setSoDienThoai(String soDienThoai) {
              this.soDienThoai = soDienThoai;
       }
       public String getEmail() {
              return email;
       }
       public void setEmail(String email) {
              this.email = email;
       }
       public String getGiaTour() {
              return giaTour;
       }
       public void setGiaTour(String giaTour) {
              this.giaTour = giaTour;
       }
       public String getDiemKhoiHanh() {
              return diemKhoiHanh;
       }
       public void setDiemKhoiHanh(String diemKhoiHanh) {
              this.diemKhoiHanh = diemKhoiHanh;
       }
       public String getPhuongTien() {
              return phuongTien;
       }
       public void setPhuongTien(String phuongTien) {
              this.phuongTien = phuongTien;
       }
       public String getHinhThuc() {
              return hinhThuc;
       }
       public void setHinhThuc(String hinhThuc) {
              this.hinhThuc = hinhThuc;
       }

}
