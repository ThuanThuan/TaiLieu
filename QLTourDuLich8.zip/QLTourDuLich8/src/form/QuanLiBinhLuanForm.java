package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.BinhLuan;
import model.bean.DonDatTour;
/**
 * QuanLiBinhLuanForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiBinhLuanForm extends ActionForm {
	private static final long serialVersionUID = 1L;
	private int maBinhLuan;
	private int maTour;
	private String maTK;
	private String tenTour;
	private ArrayList<BinhLuan> listBinhLuan;
	private String ngayBinhLuan;
	private String noiDungBinhLuan;
	private String btnXuly;
	private String txtFind;
	private String submit="";
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	private String tenNguoiBinhLuan;
	public String getTenNguoiBinhLuan() {
		return tenNguoiBinhLuan;
	}
	public void setTenNguoiBinhLuan(String tenNguoiBinhLuan) {
		this.tenNguoiBinhLuan = tenNguoiBinhLuan;
	}
	public String getResultOk() {
		return resultOk;
	}
	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}
	public String getResultError() {
		return resultError;
	}
	public void setResultError(String resultError) {
		this.resultError = resultError;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getBtnXuly() {
		return btnXuly;
	}
	public void setBtnXuly(String btnXuly) {
		this.btnXuly = btnXuly;
	}
	public String getTxtFind() {
		return txtFind;
	}
	public void setTxtFind(String txtFind) {
		this.txtFind = txtFind;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	
	
	public int getMaTour() {
		return maTour;
	}
	public int getMaBinhLuan() {
		return maBinhLuan;
	}
	public void setMaBinhLuan(int maBinhLuan) {
		this.maBinhLuan = maBinhLuan;
	}
	public void setMaTour(int maTour) {
		this.maTour = maTour;
	}
	public String getMaTK() {
		return maTK;
	}
	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	
	public ArrayList<BinhLuan> getListBinhLuan() {
		return listBinhLuan;
	}
	public void setListBinhLuan(ArrayList<BinhLuan> listBinhLuan) {
      int page = Integer.parseInt(this.page);
		
		int maxSize = listBinhLuan == null ? 0 : listBinhLuan.size();
		int max = maxSize % 10 > 0 ? maxSize / 10 + 1 : maxSize / 10;
		this.maxPage = max + "";
		if (page == 1)
			this.prev = null;
		if (page == max)
			this.next = null;
		if (page > 1)
			this.prev = page - 1 + "";
		if (page < max)
			this.next = page + 1 + "";
		int index = (page - 1) * 10;
		int j = 0;
		if (page <= max && maxSize > 0) {
			this.listBinhLuan = new ArrayList<BinhLuan>();
			for (; index < maxSize && j < 10; j++, index++) {
				this.listBinhLuan.add(listBinhLuan.get(index));
			}
		} else {
			this.listBinhLuan =listBinhLuan;
			
		}
	}
	public String getNgayBinhLuan() {
		return ngayBinhLuan;
	}
	public void setNgayBinhLuan(String ngayBinhLuan) {
		this.ngayBinhLuan = ngayBinhLuan;
	}
	public String getNoiDungBinhLuan() {
		return noiDungBinhLuan;
	}
	public void setNoiDungBinhLuan(String noiDungBinhLuan) {
		this.noiDungBinhLuan = noiDungBinhLuan;
	}
	
	

}
