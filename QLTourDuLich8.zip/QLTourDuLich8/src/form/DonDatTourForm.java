package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.*;
/**
 * DonDatTourForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DonDatTourForm extends ActionForm {
	private static final long serialVersionUID = 1L;
	private ArrayList<DonDatTour> listDonDatTour;
	private ArrayList<TourDuLich> listTourDuLich;
	private ArrayList<TaiKhoan> listTaiKhoan;
	private String textTimKiem;
	private String btnXuly;
	private String txtFind;
	private String submit="";
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	public String getResultOk() {
	return resultOk;
	}
	public void setResultOk(String resultOk) {
	this.resultOk = resultOk;
	}
	public String getResultError() {
	return resultError;
	}
	public void setResultError(String resultError) {
	this.resultError = resultError;
	}
	public ArrayList<DonDatTour> getListDonDatTour() {
	return listDonDatTour;
	}
	public void setListDonDatTour(ArrayList<DonDatTour> listDonDatTour) {
		int page = Integer.parseInt(this.page);
		int maxSize = listDonDatTour == null ? 0 : listDonDatTour.size();
		int max = maxSize % 10 > 0 ? maxSize / 10 + 1 : maxSize / 10;
		this.maxPage = max + "";
		if (page == 1)
			this.prev = null;
		if (page == max)
			this.next = null;
		if (page > 1)
			this.prev = page - 1 + "";
		if (page < max)
			this.next = page + 1 + "";
		int index = (page - 1) * 10;
		int j = 0;
		if (page <= max && maxSize > 0) {
			this.listDonDatTour = new ArrayList<DonDatTour>();
			for (; index < maxSize && j < 10; j++, index++) {
				this.listDonDatTour.add(listDonDatTour.get(index));
			}
		} else {
			this.listDonDatTour = null;
		}
	}
	public ArrayList<TourDuLich> getListTourDuLich() {
	return listTourDuLich;
	}
	public void setListTourDuLich(ArrayList<TourDuLich> listTourDuLich) {
	this.listTourDuLich = listTourDuLich;
	}
	public ArrayList<TaiKhoan> getListTaiKhoan() {
	return listTaiKhoan;
	}
	public void setListTaiKhoan(ArrayList<TaiKhoan> listTaiKhoan) {
	this.listTaiKhoan = listTaiKhoan;
	}
	public String getTextTimKiem() {
	return textTimKiem;
	}
	public void setTextTimKiem(String textTimKiem) {
	this.textTimKiem = textTimKiem;
	}
	public String getBtnXuly() {
	return btnXuly;
	}
	public void setBtnXuly(String btnXuly) {
	this.btnXuly = btnXuly;
	}
	public String getTxtFind() {
	return txtFind;
	}
	public void setTxtFind(String txtFind) {
	this.txtFind = txtFind;
	}
	public String getSubmit() {
	return submit;
	}
	public void setSubmit(String submit) {
	this.submit = submit;
	}
	public String getPage() {
	return page;
	}
	public void setPage(String page) {
	this.page = page;
	}
	public String getMaxPage() {
	return maxPage;
	}
	public void setMaxPage(String maxPage) {
	this.maxPage = maxPage;
	}
	public String getNext() {
	return next;
	}
	public void setNext(String next) {
	this.next = next;
	}
	public String getPrev() {
	return prev;
	}
	public void setPrev(String prev) {
	this.prev = prev;
	}
	public static long getSerialversionuid() {
	return serialVersionUID;
	}
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
	try {
	request.setCharacterEncoding("utf-8");
	} catch (UnsupportedEncodingException e) {
	}
	}
}
