package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.BaiViet;
/**
 * QuanLiBaiVietForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLiBaiVietForm extends ActionForm {
	private static final long serialVersionUID = 1L;
	private ArrayList<BaiViet> listBaiViet;
	private ArrayList<BaiViet> listBaiVietTour;
	private ArrayList<BaiViet> listBaiVietKhachSan;
	private ArrayList<BaiViet> listBaiVietTourKM;
	public ArrayList<BaiViet> getListBaiVietTourKM() {
		return listBaiVietTourKM;
	}

	public void setListBaiVietTourKM(ArrayList<BaiViet> listBaiVietTourKM) {
		this.listBaiVietTourKM = listBaiVietTourKM;
	}
	private String textTimKiem;
	private int maBaiViet;
	private String btnXuly;
	private String txtFind;
	private String submit="";
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	public ArrayList<BaiViet> getListBaiVietKhachSan() {
		return listBaiVietKhachSan;
	}

	public void setListBaiVietKhachSan(ArrayList<BaiViet> listBaiVietKhachSan) {
		this.listBaiVietKhachSan = listBaiVietKhachSan;
	}

	public ArrayList<BaiViet> getListBaiVietTour() {
		return listBaiVietTour;
	}

	public void setListBaiVietTour(ArrayList<BaiViet> listBaiVietTour) {
		this.listBaiVietTour = listBaiVietTour;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}

	public String getNext() {
		return next;
	}

	public void setNext(String next) {
		this.next = next;
	}

	public String getPrev() {
		return prev;
	}

	public void setPrev(String prev) {
		this.prev = prev;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getTxtFind() {
		return txtFind;
	}

	public void setTxtFind(String txtFind) {
		this.txtFind = txtFind;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	public String getBtnXuly() {
		return btnXuly;
	}

	public void setBtnXuly(String btnXuly) {
		this.btnXuly = btnXuly;
	}

	public ArrayList<BaiViet> getListBaiViet() {
		return listBaiViet;
	}

	public void setListBaiViet(ArrayList<BaiViet> listBaiViet) {
		this.listBaiViet = listBaiViet;
		}

	public String getTextTimKiem() {
		return textTimKiem;
	}

	public void setTextTimKiem(String textTimKiem) {
		this.textTimKiem = textTimKiem;
	}

	public int getMaBaiViet() {
		return maBaiViet;
	}

	public void setMaBaiViet(int maBaiViet) {
		this.maBaiViet = maBaiViet;
	}
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
		}
	}


}
