package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import model.bean.BinhLuan;
import model.bean.DanhMuc;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bean.KhuyenMai;
import model.bean.TaiKhoan;
import model.bean.TourDuLich;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
/**
 * DanhSachTourDuLichForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;
public class DanhSachTourDuLichForm extends ActionForm  {
	private static final long serialVersionUID = 1L;
	private ArrayList<TourDuLich> listTourDuLich;
	private ArrayList<DanhMuc> listDanhMuc;
	private ArrayList<KhuyenMai> listKhuyenMai;
	private String tenTour;
	private String textTimKiem;
	private String maTour;
	private String btnXuly;
	private String txtFind;
	private String khongThich;
	private String hoatDong;
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	private ArrayList<DanhSachTour> listtour;
	private ArrayList<DanhMucTour> listtour2;
	private ArrayList<DanhSachTour> listtoptour;
	private ArrayList<DanhSachTour> listtourct;
	private ArrayList<DanhMucTour> listDM;
	private int gia1;
	private int gia2;
	private String taiKhoan;
	private String hoTen;
	private String diaChi;
	private String email;
	private String dienThoai;
	private String matKhauCu;
	private String matKhauMoi;
	private String matKhauLai;
	private String daiDien;
	private String thaoTac;
	private String tenDangNhap;
	private String matKhau;
	private String tuKhoa="";
	private String matour;
	private String danhMuc;
	private String maKhuyenMai;
	private String diemKhoiHanh;
	private String thoiGian;
	private String phuongTien;
	private String lichTrinh;
	private String hinhThuc;
	private int giaTour;
	private String hinhAnh1;
	private String hinhAnh2;
	private String hinhAnh3;
	private String noidungBinhLuan;
	private String Email;
	private String MoTa;
	private int soSao;
	private String submit="";
	private float danhGia;
	private int thich;
	private String noiDungBinhLuan;
	private String maTK;
	private String maDanhMuc;
	private ArrayList<DanhSachTour> listTourTN;
	private String diemDen;
	private int giaTourSau;
	private String hienThiGia;
	private int loaiTaiKhoan;
	private ArrayList<TaiKhoan> listTK;
	
	
	public int getLoaiTaiKhoan() {
		return loaiTaiKhoan;
	}
	public void setLoaiTaiKhoan(int loaiTaiKhoan) {
		this.loaiTaiKhoan = loaiTaiKhoan;
	}
	public String getHienThiGia() {
		return hienThiGia;
	}
	public void setHienThiGia(String hienThiGia) {
		this.hienThiGia = hienThiGia;
	}
	public int getGiaTourSau() {
		return giaTourSau;
	}
	public void setGiaTourSau(int giaTourSau) {
		this.giaTourSau = giaTourSau;
	}
	public String getDiemDen() {
		return diemDen;
	}
	public void setDiemDen(String diemDen) {
		this.diemDen = diemDen;
	}
	public ArrayList<DanhSachTour> getListTourTN() {
		return listTourTN;
	}
	public void setListTourTN(ArrayList<DanhSachTour> listTourTN) {
		this.listTourTN = listTourTN;
	}
	public String getMaDanhMuc() {
		return maDanhMuc;
	}
	public void setMaDanhMuc(String maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}
	private ArrayList<BinhLuan> listBinhLuan;
	private String kiemTraHoatDong="false";
	
	public String getKhongThich() {
		return khongThich;
	}
	public void setKhongThich(String khongThich) {
		this.khongThich = khongThich;
	}
	public String getHoatDong() {
		return hoatDong;
	}
	public void setHoatDong(String hoatDong) {
		this.hoatDong = hoatDong;
	}
	public String getMatour() {
		return matour;
	}
	public void setMatour(String matour) {
		this.matour = matour;
	}
	public String getDanhMuc() {
		return danhMuc;
	}
	public void setDanhMuc(String danhMuc) {
		this.danhMuc = danhMuc;
	}
	public String getMaKhuyenMai() {
		return maKhuyenMai;
	}
	public void setMaKhuyenMai(String maKhuyenMai) {
		this.maKhuyenMai = maKhuyenMai;
	}
	public String getDiemKhoiHanh() {
		return diemKhoiHanh;
	}
	public void setDiemKhoiHanh(String diemKhoiHanh) {
		this.diemKhoiHanh = diemKhoiHanh;
	}
	public String getThoiGian() {
		return thoiGian;
	}
	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}
	public String getPhuongTien() {
		return phuongTien;
	}
	public void setPhuongTien(String phuongTien) {
		this.phuongTien = phuongTien;
	}
	public String getLichTrinh() {
		return lichTrinh;
	}
	public void setLichTrinh(String lichTrinh) {
		this.lichTrinh = lichTrinh;
	}
	public String getHinhThuc() {
		return hinhThuc;
	}
	public void setHinhThuc(String hinhThuc) {
		this.hinhThuc = hinhThuc;
	}
	
	
	public int getGiaTour() {
		return giaTour;
	}
	public void setGiaTour(int giaTour) {
		this.giaTour = giaTour;
	}
	public String getHinhAnh1() {
		return hinhAnh1;
	}
	public void setHinhAnh1(String hinhAnh1) {
		this.hinhAnh1 = hinhAnh1;
	}
	public String getHinhAnh2() {
		return hinhAnh2;
	}
	public void setHinhAnh2(String hinhAnh2) {
		this.hinhAnh2 = hinhAnh2;
	}
	public String getHinhAnh3() {
		return hinhAnh3;
	}
	public void setHinhAnh3(String hinhAnh3) {
		this.hinhAnh3 = hinhAnh3;
	}
	public String getNoidungBinhLuan() {
		return noidungBinhLuan;
	}
	public void setNoidungBinhLuan(String noidungBinhLuan) {
		this.noidungBinhLuan = noidungBinhLuan;
	}
	public String getMoTa() {
		return MoTa;
	}
	public void setMoTa(String moTa) {
		MoTa = moTa;
	}
	public int getSoSao() {
		return soSao;
	}
	public void setSoSao(int soSao) {
		this.soSao = soSao;
	}
	public float getDanhGia() {
		return danhGia;
	}
	public void setDanhGia(float danhGia) {
		this.danhGia = danhGia;
	}
	public int getThich() {
		return thich;
	}
	public void setThich(int thich) {
		this.thich = thich;
	}
	public String getNoiDungBinhLuan() {
		return noiDungBinhLuan;
	}
	public void setNoiDungBinhLuan(String noiDungBinhLuan) {
		this.noiDungBinhLuan = noiDungBinhLuan;
	}
	public String getMaTK() {
		return maTK;
	}
	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}
	public ArrayList<BinhLuan> getListBinhLuan() {
		return listBinhLuan;
	}
	public void setListBinhLuan(ArrayList<BinhLuan> listBinhLuan) {
		this.listBinhLuan = listBinhLuan;
	}
	public String getKiemTraHoatDong() {
		return kiemTraHoatDong;
	}
	public void setKiemTraHoatDong(String kiemTraHoatDong) {
		this.kiemTraHoatDong = kiemTraHoatDong;
	}
	public String getTuKhoa() {
		return tuKhoa;
		
	}
	public void setTuKhoa(String tuKhoa) {
		this.tuKhoa = tuKhoa;
	}
	public String getTenDangNhap() {
		return tenDangNhap;
	}
	public void setTenDangNhap(String tenDangNhap) {
		this.tenDangNhap = tenDangNhap;
	}
	
	public String getTaiKhoan() {
		return taiKhoan;
	}
	public void setTaiKhoan(String taiKhoan) {
		this.taiKhoan = taiKhoan;
	}
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDienThoai() {
		return dienThoai;
	}
	public void setDienThoai(String dienThoai) {
		this.dienThoai = dienThoai;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public String getMatKhauCu() {
		return matKhauCu;
	}
	public void setMatKhauCu(String matKhauCu) {
		this.matKhauCu = matKhauCu;
	}
	public String getMatKhauMoi() {
		return matKhauMoi;
	}
	public void setMatKhauMoi(String matKhauMoi) {
		this.matKhauMoi = matKhauMoi;
	}
	public String getMatKhauLai() {
		return matKhauLai;
	}
	public void setMatKhauLai(String matKhauLai) {
		this.matKhauLai = matKhauLai;
	}
	public String getDaiDien() {
		return daiDien;
	}
	public void setDaiDien(String daiDien) {
		this.daiDien = daiDien;
	}
	public String getThaoTac() {
		return thaoTac;
	}
	public void setThaoTac(String thaoTac) {
		this.thaoTac = thaoTac;
	}
	public String getResultFail() {
		return resultFail;
	}
	public void setResultFail(String resultFail) {
		this.resultFail = resultFail;
	}
	private String resultFail;
	
	public int getGia1() {
		return gia1;
	}
	public void setGia1(int gia1) {
		this.gia1 = gia1;
	}
	public int getGia2() {
		return gia2;
	}
	public void setGia2(int gia2) {
		this.gia2 = gia2;
	}
	public ArrayList<DanhSachTour> getListtour() {
		return listtour;
	}
	public void setListtour(ArrayList<DanhSachTour> listtour) {
		this.listtour = listtour;
	}
	public ArrayList<DanhMucTour> getListtour2() {
		return listtour2;
	}
	public void setListtour2(ArrayList<DanhMucTour> listtour2) {
		this.listtour2 = listtour2;
	}
	public ArrayList<DanhSachTour> getListtoptour() {
		return listtoptour;
	}
	public void setListtoptour(ArrayList<DanhSachTour> listtoptour) {
		this.listtoptour = listtoptour;
	}
	public ArrayList<DanhSachTour> getListtourct() {
		return listtourct;
	}
	public void setListtourct(ArrayList<DanhSachTour> listtourct) {
		this.listtourct = listtourct;
	}
	public ArrayList<DanhMucTour> getListDM() {
		return listDM;
	}
	public void setListDM(ArrayList<DanhMucTour> listDM) {
		this.listDM = listDM;
	}
	public String getResultOk() {
		return resultOk;
	}
	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}
	public String getResultError() {
		return resultError;
	}
	public void setResultError(String resultError) {
		this.resultError = resultError;
	}
	public String getTextTimKiem() {
		return textTimKiem;
	}
	public void setTextTimKiem(String textTimKiem) {
		this.textTimKiem = textTimKiem;
	}
	public String getMaTour() {
		return maTour;
	}
	public void setMaTour(String maTour) {
		this.maTour = maTour;
	}
	public String getBtnXuly() {
		return btnXuly;
	}
	public void setBtnXuly(String btnXuly) {
		this.btnXuly = btnXuly;
	}
	public String getTxtFind() {
		return txtFind;
	}
	public void setTxtFind(String txtFind) {
		this.txtFind = txtFind;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	
	public ArrayList<TourDuLich> getListTourDuLich() {
		return listTourDuLich;
	}
	public void setListTourDuLich(ArrayList<TourDuLich> listTourDuLich) {
		int page = Integer.parseInt(this.page);
		int maxSize = listTourDuLich == null ? 0 : listTourDuLich.size();
		int max = maxSize % 10 > 0 ? maxSize / 10 + 1 : maxSize / 10;
		this.maxPage = max + "";
		if (page == 1)
			this.prev = null;
		if (page == max)
			this.next = null;
		if (page > 1)
			this.prev = page - 1 + "";
		if (page < max)
			this.next = page + 1 + "";
		int index = (page - 1) * 10;
		int j = 0;
		if (page <= max && maxSize > 0) {
			this.listTourDuLich = new ArrayList<TourDuLich>();
			for (; index < maxSize && j < 10; j++, index++) {
				this.listTourDuLich.add(listTourDuLich.get(index));
			}
		} else {
			this.listTourDuLich = listTourDuLich;
		}
	}
	public ArrayList<DanhMuc> getListDanhMuc() {
		return listDanhMuc;
	}
	public void setListDanhMuc(ArrayList<DanhMuc> listDanhMuc) {
		this.listDanhMuc = listDanhMuc;
	}
	public ArrayList<KhuyenMai> getListKhuyenMai() {
		return listKhuyenMai;
	}
	public void setListKhuyenMai(ArrayList<KhuyenMai> listKhuyenMai) {
		this.listKhuyenMai = listKhuyenMai;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
		}
	}
	
	@Override
	public String toString() {
		return "DanhSachTourForm [matour=" + matour + ", danhMuc=" + danhMuc + ", maKhuyenMai=" + maKhuyenMai
				+ ", tenTour=" + tenTour + ", diemKhoiHanh=" + diemKhoiHanh + ", thoiGian=" + thoiGian + ", phuongTien="
				+ phuongTien + ", lichTrinh=" + lichTrinh + ", hinhThuc=" + hinhThuc + ", giaTour=" + giaTour
				+ ", hinhAnh1=" + hinhAnh1 + ", hinhAnh2=" + hinhAnh2 + ", hinhAnh3=" + hinhAnh3 + ", page=" + page
				+ ", maxPage=" + maxPage + ", next=" + next + ", prev=" + prev + ", Email=" + Email + ", MoTa=" + MoTa
				+ ", soSao=" + soSao + ", submit=" + submit + ", danhGia=" + danhGia + ", thich=" + thich
				+ ", noiDungBinhLuan=" + noiDungBinhLuan + ", khongThich=" + khongThich + ", hoatDong=" + hoatDong
				+ ", kiemTraHoatDong=" + kiemTraHoatDong + ", noidungBinhLuan=" + noidungBinhLuan + ", listDM=" + listDM
				+ ", listtour=" + listtour + ", listtoptour=" + listtoptour + ", listtourct=" + listtourct + "]";
	}
	
	

}
