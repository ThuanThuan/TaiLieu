package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.BinhLuan;
import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
import model.bean.HoatDong;

/**
 * DanhSachTourForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DanhSachTourForm extends ActionForm{
	private String matour;
	private String danhMuc;
	private String maKhuyenMai;
	private String tenTour;
	private String diemKhoiHanh;
	private String thoiGian;
	private String phuongTien;
	private String lichTrinh;
	private String hinhThuc;
	private String giaTour;
	private String hinhAnh1;
	private String hinhAnh2;
	private String hinhAnh3;
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	private String Email;
	private String MoTa;
	private int soSao;
	private String submit="";
	private float danhGia;
	private int thich;
	private String noiDungBinhLuan;
	private String maTK;
	private ArrayList<BinhLuan> listBinhLuan;
	private String tenDangNhap;
	private String matKhau;
	private String tuKhoa;
   
    private int totalPage;
    private String diemDen;
    private String giaTourSau;
    private String goToBottom;
    private String hienThiGia;
    private String anh;
    private String lichTrinh1;
    private String lichTrinh2;
    private String lichTrinh3;
    private String lichTrinh4;
    private String lichTrinh5;
    private String lichTrinh6;
    private String lichTrinh7;
    private String lichTrinh8;
    private String lichTrinh9;
    
    
    
	public String getLichTrinh6() {
		return lichTrinh6;
	}

	public void setLichTrinh6(String lichTrinh6) {
		this.lichTrinh6 = lichTrinh6;
	}

	public String getLichTrinh7() {
		return lichTrinh7;
	}

	public void setLichTrinh7(String lichTrinh7) {
		this.lichTrinh7 = lichTrinh7;
	}

	public String getLichTrinh8() {
		return lichTrinh8;
	}

	public void setLichTrinh8(String lichTrinh8) {
		this.lichTrinh8 = lichTrinh8;
	}

	public String getLichTrinh9() {
		return lichTrinh9;
	}

	public void setLichTrinh9(String lichTrinh9) {
		this.lichTrinh9 = lichTrinh9;
	}

	public String getLichTrinh1() {
		return lichTrinh1;
	}

	public void setLichTrinh1(String lichTrinh1) {
		this.lichTrinh1 = lichTrinh1;
	}

	public String getLichTrinh2() {
		return lichTrinh2;
	}

	public void setLichTrinh2(String lichTrinh2) {
		this.lichTrinh2 = lichTrinh2;
	}

	public String getLichTrinh3() {
		return lichTrinh3;
	}

	public void setLichTrinh3(String lichTrinh3) {
		this.lichTrinh3 = lichTrinh3;
	}

	public String getLichTrinh4() {
		return lichTrinh4;
	}

	public void setLichTrinh4(String lichTrinh4) {
		this.lichTrinh4 = lichTrinh4;
	}

	public String getLichTrinh5() {
		return lichTrinh5;
	}

	public void setLichTrinh5(String lichTrinh5) {
		this.lichTrinh5 = lichTrinh5;
	}

	public String getAnh() {
		return anh;
	}

	public void setAnh(String anh) {
		this.anh = anh;
	}

	public String getHienThiGia() {
		return hienThiGia;
	}

	public void setHienThiGia(String hienThiGia) {
		this.hienThiGia = hienThiGia;
	}

	public String getGiaTourSau() {
		return giaTourSau;
	}

	public void setGiaTourSau(String giaTourSau) {
		this.giaTourSau = giaTourSau;
	}

	public String getGoToBottom() {
		return goToBottom;
	}

	public void setGoToBottom(String goToBottom) {
		this.goToBottom = goToBottom;
	}

	public String getDiemDen() {
		return diemDen;
	}

	public void setDiemDen(String diemDen) {
		this.diemDen = diemDen;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}



	public String getResultOk() {
		return resultOk;
	}

	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}

	public String getResultError() {
		return resultError;
	}

	public void setResultError(String resultError) {
		this.resultError = resultError;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getTenDangNhap() {
		return tenDangNhap;
	}

	public void setTenDangNhap(String tenDangNhap) {
		this.tenDangNhap = tenDangNhap;
	}

	public String getMatKhau() {
		return matKhau;
	}

	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}

	public String getTuKhoa() {
		return tuKhoa;
	}

	public void setTuKhoa(String tuKhoa) {
		this.tuKhoa = tuKhoa;
	}

	public String getMaTK() {
		return maTK;
	}

	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}

	public ArrayList<BinhLuan> getListBinhLuan() {
		return listBinhLuan;
	}

	public void setListBinhLuan(ArrayList<BinhLuan> listBinhLuan) {
		int page = Integer.parseInt(this.page);
		int maxSize = listBinhLuan == null ? 0 : listBinhLuan.size();
		int max = maxSize % 10 > 0 ? maxSize / 10 + 1 : maxSize / 10;
		this.maxPage = max + "";
		if (page == 1)
			this.prev = null;
		if (page == max)
			this.next = null;
		if (page > 1)
			this.prev = page - 1 + "";
		if (page < max)
			this.next = page + 1 + "";
		int index = (page - 1) * 10;
		int j = 0;
		if (page <= max && maxSize > 0) {
			this.listBinhLuan = new ArrayList<BinhLuan>();
			for (; index < maxSize && j < 10; j++, index++) {
				this.listBinhLuan.add(listBinhLuan.get(index));
			}
		} else {
			this.listBinhLuan = listBinhLuan;
		}
	}

	public String getPage() {
		return page;
	}

	public String getNoiDungBinhLuan() {
		return noiDungBinhLuan;
	}

	public void setNoiDungBinhLuan(String noiDungBinhLuan) {
		this.noiDungBinhLuan = noiDungBinhLuan;
	}

	public float getDanhGia() {
		return danhGia;
	}

	public void setDanhGia(float danhGia) {
		this.danhGia = danhGia;
	}

	public int getThich() {
		return thich;
	}

	public void setThich(int thich) {
		this.thich = thich;
	}

	public int getKhongThich() {
		return khongThich;
	}

	public void setKhongThich(int khongThich) {
		this.khongThich = khongThich;
	}

	public HoatDong getHoatDong() {
		return hoatDong;
	}

	public void setHoatDong(HoatDong hoatDong) {
		this.hoatDong = hoatDong;
	}

	public String getKiemTraHoatDong() {
		return kiemTraHoatDong;
	}

	public void setKiemTraHoatDong(String kiemTraHoatDong) {
		this.kiemTraHoatDong = kiemTraHoatDong;
	}

	public String getNoidungBinhLuan() {
		return noidungBinhLuan;
	}

	public void setNoidungBinhLuan(String noidungBinhLuan) {
		this.noidungBinhLuan = noidungBinhLuan;
	}

	private int khongThich;
	private HoatDong hoatDong;
	
	private String kiemTraHoatDong="false";
	
	private String noidungBinhLuan;
	public String getSubmit() {
		return submit;
	}
	
	public void setSubmit(String submit) {
		this.submit = submit;
	}

	public int getSoSao() {
		return soSao;
	}

	public void setSoSao(int soSao) {
		this.soSao = soSao;
	}

	public String getMoTa() {
		return MoTa;
	}

	public void setMoTa(String moTa) {
		MoTa = moTa;
	}

	

	

	public String getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}

	public String getNext() {
		return next;
	}

	public void setNext(String next) {
		this.next = next;
	}

	public String getPrev() {
		return prev;
	}

	public void setPrev(String prev) {
		this.prev = prev;
	}

	private ArrayList<DanhMucTour> listDM;
	private ArrayList<DanhSachTour> listtour;
	private ArrayList<DanhSachTour> listtoptour;
	private ArrayList<DanhSachTour> listtourct;

	public ArrayList<DanhSachTour> getListtourct() {
		return listtourct;
	}

	public void setListtourct(ArrayList<DanhSachTour> listtourct) {
		this.listtourct = listtourct;
	}

	public ArrayList<DanhMucTour> getListDM() {
		return listDM;
	}
	
	public ArrayList<DanhSachTour> getListtoptour() {
		return listtoptour;
	}
	public void setListtoptour(ArrayList<DanhSachTour> listtoptour) {
		this.listtoptour = listtoptour;
	}

	
	public String getMatour() 
	{
		return matour;
	}
	public void setMatour(String matour) {
		this.matour = matour;
	}
	public String getDanhMuc() {
		return danhMuc;
	}
	public void setDanhMuc(String danhMuc) {
		this.danhMuc = danhMuc;
	}
	public String getMaKhuyenMai() {
		return maKhuyenMai;
	}
	public void setMaKhuyenMai(String maKhuyenMai) {
		this.maKhuyenMai = maKhuyenMai;
	}
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	public String getDiemKhoiHanh() {
		return diemKhoiHanh;
	}
	public void setDiemKhoiHanh(String diemKhoiHanh) {
		this.diemKhoiHanh = diemKhoiHanh;
	}
	public String getThoiGian() {
		return thoiGian;
	}
	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}
	public String getPhuongTien() {
		return phuongTien;
	}
	public void setPhuongTien(String phuongTien) {
		this.phuongTien = phuongTien;
	}
	
	public String getLichTrinh() {
		return lichTrinh;
	}

	public void setLichTrinh(String lichTrinh) {
		this.lichTrinh = lichTrinh;
	}

	public String getHinhThuc() {
		return hinhThuc;
	}
	public void setHinhThuc(String hinhThuc) {
		this.hinhThuc = hinhThuc;
	}
	public String getGiaTour() {
		return giaTour;
	}
	public void setGiaTour(String giaTour) {
		this.giaTour = giaTour;
	}
	public String getHinhAnh1() {
		return hinhAnh1;
	}
	public void setHinhAnh1(String hinhAnh1) {
		this.hinhAnh1 = hinhAnh1;
	}
	public String getHinhAnh2() {
		return hinhAnh2;
	}
	public void setHinhAnh2(String hinhAnh2) {
		this.hinhAnh2 = hinhAnh2;
	}
	public String getHinhAnh3() {
		return hinhAnh3;
	}
	public void setHinhAnh3(String hinhAnh3) {
		this.hinhAnh3 = hinhAnh3;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public ArrayList<DanhSachTour> getListtour() {
		return listtour;
	}
	public void setListtour(ArrayList<DanhSachTour> listtour) {
		this.listtour = listtour;
	}

	public void setListDM(ArrayList<DanhMucTour> listDM2) {
		this.listDM = listDM2;
	}
	
	@Override
	public String toString() {
		return "DanhSachTourForm [matour=" + matour + ", danhMuc=" + danhMuc + ", maKhuyenMai=" + maKhuyenMai
				+ ", tenTour=" + tenTour + ", diemKhoiHanh=" + diemKhoiHanh + ", thoiGian=" + thoiGian + ", phuongTien="
				+ phuongTien + ", lichTrinh=" + lichTrinh + ", hinhThuc=" + hinhThuc + ", giaTour=" + giaTour
				+ ", hinhAnh1=" + hinhAnh1 + ", hinhAnh2=" + hinhAnh2 + ", hinhAnh3=" + hinhAnh3 + ", page=" + page
				+ ", maxPage=" + maxPage + ", next=" + next + ", prev=" + prev + ", Email=" + Email + ", MoTa=" + MoTa
				+ ", soSao=" + soSao + ", submit=" + submit + ", danhGia=" + danhGia + ", thich=" + thich
				+ ", noiDungBinhLuan=" + noiDungBinhLuan + ", khongThich=" + khongThich + ", hoatDong=" + hoatDong
				+ ", kiemTraHoatDong=" + kiemTraHoatDong + ", noidungBinhLuan=" + noidungBinhLuan + ", listDM=" + listDM
				+ ", listtour=" + listtour + ", listtoptour=" + listtoptour + ", listtourct=" + listtourct + "]";
	}
	
	
	
}
