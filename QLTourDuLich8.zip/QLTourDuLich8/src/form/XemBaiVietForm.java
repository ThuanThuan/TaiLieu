package form;

import java.util.ArrayList;
import java.util.Date;

import model.bean.BaiViet;
import model.bean.BaiVietQuyND;
import model.bean.BinhLuan;
import model.bean.HoatDong;

import org.apache.struts.action.ActionForm;

import common.StringProcess;

/**
 * XemBaiVietForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class XemBaiVietForm extends ActionForm {

	


	/*bai viet*/
	private int maBV;
	private int maDanhMuc;
	private String diaChiBaiViet;
	private String maTK;
	private String tieuDe;
	private String tenKhach;
	private String email;

	private String mota;
	private String noiDung;
	private String ngayDang;
	private int luotXem;
	private int luotThich;
	private int luotKhongThich;
	private float danhGiaTrungBinh;
	private String anh1;
	private String anh2;
	private String anh3;
	private String nguoiDang;
	private BaiViet baiViet;
	private String kinhDo;
	private String viDo;
	
	public String getKinhDo() {
		return kinhDo;
	}

	public void setKinhDo(String kinhDo) {
		this.kinhDo = kinhDo;
	}

	public String getViDo() {
		return viDo;
	}

	public void setViDo(String viDo) {
		this.viDo = viDo;
	}

	/*hoat dong*/
	private float danhGia;
	private int thich;
	private int khongThich;
	private HoatDong hoatDong;
	private String submit="";
	private String kiemTraHoatDong="false";
	private int soSao;
	private String noidungBinhLuan;
	
	public String getTenKhach() {
		return tenKhach;
	}

	public void setTenKhach(String tenKhach) {
		this.tenKhach = tenKhach;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	private ArrayList<BinhLuan> danhSachBinhLuan;
	
	public ArrayList<BinhLuan> getDanhSachBinhLuan() {
		return danhSachBinhLuan;
	}

	public void setDanhSachBinhLuan(ArrayList<BinhLuan> arrayList) {
		this.danhSachBinhLuan = arrayList;
	}

	
	public int getMaBV() {
		return maBV;
	}

	public void setMaBV(int maBV) {
		this.maBV = maBV;
	}

	public int getMaDanhMuc() {
		return maDanhMuc;
	}

	public void setMaDanhMuc(int maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}

	public String getDiaChiBaiViet() {
		return diaChiBaiViet;
	}

	public void setDiaChiBaiViet(String diaChiBaiViet) {
		this.diaChiBaiViet = diaChiBaiViet;
	}

	public String getMaTK() {
		return maTK;
	}

	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}

	public String getTieuDe() {
		return tieuDe;
	}

	public void setTieuDe(String tieuDe) {
		this.tieuDe = tieuDe;
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public String getNoiDung() {
		return noiDung;
	}

	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getNgayDang() {
		return ngayDang;
	}

	public void setNgayDang(String ngayDang) {
		this.ngayDang = ngayDang;
	}

	public void setBaiViet(BaiViet baiViet) {
		this.baiViet = baiViet;
	}

	public int getLuotXem() {
		return luotXem;
	}

	public void setLuotXem(int luotXem) {
		this.luotXem = luotXem;
	}

	public int getLuotThich() {
		return luotThich;
	}

	public void setLuotThich(int luotThich) {
		this.luotThich = luotThich;
	}

	public int getLuotKhongThich() {
		return luotKhongThich;
	}

	public void setLuotKhongThich(int luotKhongThich) {
		this.luotKhongThich = luotKhongThich;
	}

	public float getDanhGiaTrungBinh() {
		return danhGiaTrungBinh;
	}

	public void setDanhGiaTrungBinh(float danhGiaTrungBinh) {
		this.danhGiaTrungBinh = danhGiaTrungBinh;
	}



	public String getAnh1() {
		return anh1;
	}

	public void setAnh1(String anh1) {
		this.anh1 = anh1;
	}

	public String getAnh2() {
		return anh2;
	}

	public void setAnh2(String anh2) {
		this.anh2 = anh2;
	}

	public String getAnh3() {
		return anh3;
	}

	public void setAnh3(String anh3) {
		this.anh3 = anh3;
	}

	public BaiViet getBaiViet() {
		return baiViet;
	}

	public void setBaiViet(BaiVietQuyND baiVietQuyND) {
		this.maBV=baiVietQuyND.getMaBV();
		this.maDanhMuc=baiVietQuyND.getDanhMuc();
		this.diaChiBaiViet=baiVietQuyND.getDiaChiBaiViet();
		this.maTK=baiVietQuyND.getNguoiDang();
		this.tieuDe=baiVietQuyND.getTieuDe();
		this.mota=baiVietQuyND.getMota();
		this.noiDung=baiVietQuyND.getNoiDung();
		this.ngayDang=baiVietQuyND.getNgayDang();
		this.luotXem=baiVietQuyND.getLuotXem();
		this.luotThich=baiVietQuyND.getLuotThich();
		this.luotKhongThich=baiVietQuyND.getLuotKhongThich();
		this.danhGiaTrungBinh=baiVietQuyND.getDanhGiaTrungBinh();
		this.anh1=baiVietQuyND.getAnh1();
		this.anh2=baiVietQuyND.getAnh2();
		this.anh3=baiVietQuyND.getAnh3();
		this.kinhDo = baiVietQuyND.getKinhDo();
		this.viDo = baiVietQuyND.getViDo();
		
	}
	
	public String getNguoiDang() {
		return nguoiDang;
	}

	public void setNguoiDang(String nguoiDang) {
		this.nguoiDang = nguoiDang;
	}
	
	public float getDanhGia() {
		return danhGia;
	}

	public void setDanhGia(float danhGia) {
		this.danhGia = danhGia;
	}

	public int getThich() {
		return thich;
	}

	public void setThich(int thich) {
		this.thich = thich;
	}

	public int getKhongThich() {
		return khongThich;
	}

	public void setKhongThich(int khongThich) {
		this.khongThich = khongThich;
	}
	public HoatDong getHoatDong() {
		return hoatDong;
	}

	public void setHoatDong(HoatDong hoatDong) {
		this.danhGia=hoatDong.getDanhGia();
		this.thich=hoatDong.getThich();
		this.khongThich=hoatDong.getKhongThich();
	}
	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getKiemTraHoatDong() {
		return kiemTraHoatDong;
	}
	public void setKiemTraHoatDong(String kiemTraHoatDong) {
		this.kiemTraHoatDong = kiemTraHoatDong;
	}
	public int getSoSao() {
		return soSao;
	}

	public void setSoSao(int soSao) {
		this.soSao = soSao;
	}
	public String getNoidungBinhLuan() {
		return noidungBinhLuan;
	}

	public void setNoidungBinhLuan(String noidungBinhLuan) {
		this.noidungBinhLuan = noidungBinhLuan;
	}

}
