package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DanhMucTour;
import model.bean.DanhSachTour;
/**
 * DanhMucTourForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DanhMucTourForm extends ActionForm{
	private String maDanhMuc;
	private String tenDanhMuc;
	private String matour;
	private String danhMuc;
	private String maKhuyenMai;
	private String tenTour;
	private String diemKhoiHanh;
	private String thoiGian;
	private String phuongTien;
	private String LichTrinh;
	private String hinhThuc;
	private String giaTour;
	private String hinhAnh1;
	private String hinhAnh2;
	private String hinhAnh3;
	private String Email;
	private String moTa;
	
	
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	private ArrayList<DanhSachTour> listtour;
	private ArrayList<DanhMucTour> listtour2;
	
	private ArrayList<DanhSachTour> listtoptour;
	private ArrayList<DanhSachTour> listtourct;
	private ArrayList<DanhMucTour> listDM;
	public ArrayList<DanhMucTour> getListtour2() {
		return listtour2;
	}
	public void setListtour2(ArrayList<DanhMucTour> listtour2) {
		this.listtour2 = listtour2;
	}
	public String getMatour() {
		return matour;
	}
	public void setMatour(String matour) {
		this.matour = matour;
	}
	public String getDanhMuc() {
		return danhMuc;
	}
	public void setDanhMuc(String danhMuc) {
		this.danhMuc = danhMuc;
	}
	public String getMaKhuyenMai() {
		return maKhuyenMai;
	}
	public void setMaKhuyenMai(String maKhuyenMai) {
		this.maKhuyenMai = maKhuyenMai;
	}
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	public String getDiemKhoiHanh() {
		return diemKhoiHanh;
	}
	public void setDiemKhoiHanh(String diemKhoiHanh) {
		this.diemKhoiHanh = diemKhoiHanh;
	}
	public String getThoiGian() {
		return thoiGian;
	}
	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}
	public String getPhuongTien() {
		return phuongTien;
	}
	public void setPhuongTien(String phuongTien) {
		this.phuongTien = phuongTien;
	}
	public String getLichTrinh() {
		return LichTrinh;
	}
	public void setLichTrinh(String lichTrinh) {
		LichTrinh = lichTrinh;
	}
	public String getHinhThuc() {
		return hinhThuc;
	}
	public void setHinhThuc(String hinhThuc) {
		this.hinhThuc = hinhThuc;
	}
	public String getGiaTour() {
		return giaTour;
	}
	public void setGiaTour(String giaTour) {
		this.giaTour = giaTour;
	}
	public String getHinhAnh1() {
		return hinhAnh1;
	}
	public void setHinhAnh1(String hinhAnh1) {
		this.hinhAnh1 = hinhAnh1;
	}
	public String getHinhAnh2() {
		return hinhAnh2;
	}
	public void setHinhAnh2(String hinhAnh2) {
		this.hinhAnh2 = hinhAnh2;
	}
	public String getHinhAnh3() {
		return hinhAnh3;
	}
	public void setHinhAnh3(String hinhAnh3) {
		this.hinhAnh3 = hinhAnh3;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public ArrayList<DanhSachTour> getListtour() {
		return listtour;
	}
	public void setListtour(ArrayList<DanhSachTour> listtour) {
		this.listtour = listtour;
	}
	public ArrayList<DanhSachTour> getListtoptour() {
		return listtoptour;
	}
	public void setListtoptour(ArrayList<DanhSachTour> listtoptour) {
		this.listtoptour = listtoptour;
	}
	public ArrayList<DanhSachTour> getListtourct() {
		return listtourct;
	}
	public void setListtourct(ArrayList<DanhSachTour> listtourct) {
		this.listtourct = listtourct;
	}
	public String getMaDanhMuc() {
		return maDanhMuc;
	}
	public void setMaDanhMuc(String maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}
	public String getTenDanhMuc() {
		return tenDanhMuc;
	}
	public void setTenDanhMuc(String tenDanhMuc) {
		this.tenDanhMuc = tenDanhMuc;
	}
	public ArrayList<DanhMucTour> getListDM() {
		return listDM;
	}
	public void setListDM(ArrayList<DanhMucTour> listDM) {
		this.listDM = listDM;
	}
	
}
