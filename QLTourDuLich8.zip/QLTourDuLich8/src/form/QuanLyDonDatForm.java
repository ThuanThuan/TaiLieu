package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DanhMuc;
import model.bean.DonDatTour;
/**
 * QuanLyDonDatForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class QuanLyDonDatForm extends ActionForm{
	private String maDatTour;
	private ArrayList<DonDatTour> listDonDatTour;
	
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	public String getResultOk() {
		return resultOk;
	}
	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}
	public String getResultError() {
		return resultError;
	}
	public void setResultError(String resultError) {
		this.resultError = resultError;
	}
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	public String getMaDatTour() {
		return maDatTour;
	}
	public void setMaDatTour(String maDatTour) {
		this.maDatTour = maDatTour;
	}
	public ArrayList<DonDatTour> getListDonDatTour() {
		return listDonDatTour;
	}
	public void setListDonDatTour(ArrayList<DonDatTour> listDonDatTour) {
		int page = Integer.parseInt(this.page);
		
		int maxSize = listDonDatTour == null ? 0 : listDonDatTour.size();
		int max = maxSize % 10 > 0 ? maxSize / 10 + 1 : maxSize / 10;
		this.maxPage = max + "";
		if (page == 1)
			this.prev = null;
		if (page == max)
			this.next = null;
		if (page > 1)
			this.prev = page - 1 + "";
		if (page < max)
			this.next = page + 1 + "";
		int index = (page - 1) * 10;
		int j = 0;
		if (page <= max && maxSize > 0) {
			this.listDonDatTour = new ArrayList<DonDatTour>();
			for (; index < maxSize && j < 10; j++, index++) {
				this.listDonDatTour.add(listDonDatTour.get(index));
			}
		} else {
			this.listDonDatTour =listDonDatTour;
			
		}
	}
	
	
} 
