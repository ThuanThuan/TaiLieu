package form;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import model.bean.BaiViet;
import model.bean.BaiVietQuyND;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;
/**
 * ThongTinBaiVietForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThongTinBaiVietForm extends ActionForm{
	int maBaiViet;
	String nguoiDang,diaChi,tieuDe,moTa,noiDung,luotXem,luotThich,luotKhongThich,danhGiaTrungBinh,Anh1,Anh2,Anh3,loaiBaiViet,tacVu="";
	int danhMuc;
	String ngayDang;
	String kinhDo;
	String viDo;
	FormFile file;
	BaiViet baiViet;
	
	public String getKinhDo() {
		return kinhDo;
	}

	public void setKinhDo(String kinhDo) {
		this.kinhDo = kinhDo;
	}

	public String getViDo() {
		return viDo;
	}
	public void setViDo(String viDo) {
		this.viDo = viDo;
	}
	public void setBaiViet(BaiViet baiViet) {
		this.baiViet = baiViet;
	}

	public BaiViet getBaiViet() {
		return baiViet;
	}

	public void setBaiViet(BaiVietQuyND baiVietQuyND) {
		this.maBaiViet= baiVietQuyND.getMaBV();
		this.danhMuc= baiVietQuyND.getMaDanhMuc();
		this.diaChi=baiVietQuyND.getDiaChiBaiViet();
		this.nguoiDang=baiVietQuyND.getNguoiDang();
		this.tieuDe=baiVietQuyND.getTieuDe();
		this.moTa=baiVietQuyND.getMota();
		this.noiDung=baiVietQuyND.getNoiDung();
		this.ngayDang=baiVietQuyND.getNgayDang();
		this.luotXem=String.valueOf(baiVietQuyND.getLuotXem());
		this.luotThich=String.valueOf( baiVietQuyND.getLuotThich());
		this.luotKhongThich=String.valueOf( baiVietQuyND.getLuotKhongThich());
		this.danhGiaTrungBinh=String.valueOf(baiVietQuyND.getDanhGiaTrungBinh());
		this.Anh1=baiVietQuyND.getAnh1();
		this.Anh2=baiVietQuyND.getAnh2();
		this.Anh3=baiVietQuyND.getAnh3();
	}

	public FormFile getFile() {
		return file;
	}

	public void setFile(FormFile file) {
		this.file = file;
	}

	public String getTacVu() {
		return tacVu;
	}

	public void setTacVu(String tacVu) {
		this.tacVu = tacVu;
	}

	
	public int getMaBaiViet() {
		return maBaiViet;
	}

	public void setMaBaiViet(int maBaiViet) {
		this.maBaiViet = maBaiViet;
	}

	public void setDanhMuc(int danhMuc) {
		this.danhMuc = danhMuc;
	}

	public String getNguoiDang() {
		return nguoiDang;
	}

	public void setNguoiDang(String nguoiDang) {
		this.nguoiDang = nguoiDang;
	}

	
	public int getDanhMuc() {
		return danhMuc;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public String getTieuDe() {
		return tieuDe;
	}

	public void setTieuDe(String tieuDe) {
		this.tieuDe = tieuDe;
	}

	public String getMoTa() {
		return moTa;
	}

	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}

	public String getNoiDung() {
		return noiDung;
	}

	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}

	

	

	public String getNgayDang() {
		return ngayDang;
	}

	public void setNgayDang(String ngayDang) {
		this.ngayDang = ngayDang;
	}

	public String getLuotXem() {
		return luotXem;
	}

	public void setLuotXem(String luotXem) {
		this.luotXem = luotXem;
	}

	public String getLuotThich() {
		return luotThich;
	}

	public void setLuotThich(String luotThich) {
		this.luotThich = luotThich;
	}

	public String getLuotKhongThich() {
		return luotKhongThich;
	}

	public void setLuotKhongThich(String luotKhongThich) {
		this.luotKhongThich = luotKhongThich;
	}

	public String getDanhGiaTrungBinh() {
		return danhGiaTrungBinh;
	}

	public void setDanhGiaTrungBinh(String danhGiaTrungBinh) {
		this.danhGiaTrungBinh = danhGiaTrungBinh;
	}

	

	public String getAnh1() {
		return Anh1;
	}

	public void setAnh1(String anh1) {
		Anh1 = anh1;
	}

	public String getAnh2() {
		return Anh2;
	}

	public void setAnh2(String anh2) {
		Anh2 = anh2;
	}

	public String getAnh3() {
		return Anh3;
	}

	public void setAnh3(String anh3) {
		Anh3 = anh3;
	}

	public String getLoaiBaiViet() {
		return loaiBaiViet;
	}

	public void setLoaiBaiViet(String loaiBaiViet) {
		this.loaiBaiViet = loaiBaiViet;
	}

}
