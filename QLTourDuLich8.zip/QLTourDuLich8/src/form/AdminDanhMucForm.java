package form;
/**
 * AdminDanhMucForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.DanhMuc;
@SuppressWarnings("serial")
public class AdminDanhMucForm extends ActionForm {
	private String tenMonAn;
	private ArrayList<DanhMuc> listDanhMucMonAn;
	private String btnXuly;
	private String txtFind;
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	private String submit;
	private String tenMonAnMoi;
	private int maMonAnChinhSua;
	private String moTa;
	private int maDanhMuc;
	

	
	public int getMaDanhMuc() {
		return maDanhMuc;
	}

	public void setMaDanhMuc(int maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}

	public String getMoTa() {
		return moTa;
	}

	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}

	

	public int getMaMonAnChinhSua() {
		return maMonAnChinhSua;
	}

	public void setMaMonAnChinhSua(int maMonAnChinhSua) {
		this.maMonAnChinhSua = maMonAnChinhSua;
	}

	public String getTenMonAnMoi() {
		return tenMonAnMoi;
	}

	public void setTenMonAnMoi(String tenMonAnMoi) {
		this.tenMonAnMoi = tenMonAnMoi;
	}

	public String getTenMonAn() {
		return tenMonAn;
	}

	public void setTenMonAn(String tenMonAn) {
		this.tenMonAn = tenMonAn;
	}

	public ArrayList<DanhMuc> getListDanhMucMonAn() {
		return listDanhMucMonAn;
	}

	public void setListDanhMucMonAn(ArrayList<DanhMuc> listDanhMucMonAn) {
		int page = Integer.parseInt(this.page);
		int maxSize = listDanhMucMonAn == null ? 0 : listDanhMucMonAn.size();
		int max = maxSize % 10 > 0 ? maxSize / 10 + 1 : maxSize / 10;
		this.maxPage = max + "";
		if (page == 1)
			this.prev = null;
		if (page == max)
			this.next = null;
		if (page > 1)
			this.prev = page - 1 + "";
		if (page < max)
			this.next = page + 1 + "";
		int index = (page - 1) * 10;
		int j = 0;
		if (page <= max && maxSize > 0) {
			this.listDanhMucMonAn = new ArrayList<DanhMuc>();
			for (; index < maxSize && j < 10; j++, index++) {
				this.listDanhMucMonAn.add(listDanhMucMonAn.get(index));
			}
		} else {
			this.listDanhMucMonAn = null;
		}
	}

	public String getBtnXuly() {
		return btnXuly;
	}

	public void setBtnXuly(String btnXuly) {
		this.btnXuly = btnXuly;
	}

	public String getTxtFind() {
		return txtFind;
	}

	public void setTxtFind(String txtFind) {
		this.txtFind = txtFind;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getMaxPage() {
		return maxPage;
	}

	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}

	public String getNext() {
		return next;
	}

	public void setNext(String next) {
		this.next = next;
	}

	public String getPrev() {
		return prev;
	}

	public void setPrev(String prev) {
		this.prev = prev;
	}

	public String getResultOk() {
		return resultOk;
	}

	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}

	public String getResultError() {
		return resultError;
	}

	public void setResultError(String resultError) {
		this.resultError = resultError;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}
}
