package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;

import model.bean.DanhMucTour;
import model.bean.TaiKhoan;
/**
 * DangKyForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class DangKyForm extends ActionForm {
	private String maTK;
	private String matKhau;
	private String confirmMatKhau;
	private String hoTen;
	private String diaChi;
	private String ngaySinh;
	private String email;
	private int gioiTinh;
	private String soDienThoai;
	private String soThich;
	private int tinhTrang;

	private String submit;
	private FormFile file1;
	private String matKhauMoi;
	TaiKhoan taiKhoanHienTai;
	private String tacvu;
	private String tuKhoa="";
	private String anh;
	

	public String getAnh() {
		return anh;
	}

	public void setAnh(String anh) {
		this.anh = anh;
	}

	public String getTuKhoa() {
		return tuKhoa;
	}

	public void setTuKhoa(String tuKhoa) {
		this.tuKhoa = tuKhoa;
	}

	public String getTacvu() {
		return tacvu;
	}

	public void setTacvu(String tacvu) {
		this.tacvu = tacvu;
	}

	public String getMatKhauMoi() {
		return matKhauMoi;
	}

	public void setMatKhauMoi(String matKhauMoi) {
		this.matKhauMoi = matKhauMoi;
	}

	

	public TaiKhoan getTaiKhoanHienTai() {
		return taiKhoanHienTai;
	}

	public void setTaiKhoanHienTai(TaiKhoan taiKhoanHienTai) {
		this.taiKhoanHienTai = taiKhoanHienTai;
	}

	public FormFile getFile1() {
		return file1;
	}

	public void setFile1(FormFile file1) {
		this.file1 = file1;
	}

	private String thongBao;
	private ArrayList<DanhMucTour> listDM;
	private String maDanhMuc;
	private String tenDanhMuc;

	
	public ArrayList<DanhMucTour> getListDM() {
		return listDM;
	}

	public void setListDM(ArrayList<DanhMucTour> listDM) {
		this.listDM = listDM;
	}

	public String getMaDanhMuc() {
		return maDanhMuc;
	}

	public void setMaDanhMuc(String maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}

	public String getTenDanhMuc() {
		return tenDanhMuc;
	}

	public void setTenDanhMuc(String tenDanhMuc) {
		this.tenDanhMuc = tenDanhMuc;
	}

	public String getMaTK() {
		return maTK;
	}

	public void setMaTK(String maTK) {
		this.maTK = maTK;
	}

	public String getMatKhau() {
		return matKhau;
	}

	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	public String getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getGioiTinh() {
		return gioiTinh;
	}

	public void setGioiTinh(int gioiTinh) {
		this.gioiTinh = gioiTinh;
	}

	public String getSoDienThoai() {
		return soDienThoai;
	}

	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}

	public String getSoThich() {
		return soThich;
	}

	public void setSoThich(String soThich) {
		this.soThich = soThich;
	}

	public int getTinhTrang() {
		return tinhTrang;
	}

	public void setTinhTrang(int tinhTrang) {
		this.tinhTrang = tinhTrang;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	

	public String getThongBao() {
		return thongBao;
	}

	public void setThongBao(String thongBao) {
		this.thongBao = thongBao;
	}

	public String getConfirmMatKhau() {
		return confirmMatKhau;
	}

	public void setConfirmMatKhau(String confirmMatKhau) {
		this.confirmMatKhau = confirmMatKhau;
	}

}
