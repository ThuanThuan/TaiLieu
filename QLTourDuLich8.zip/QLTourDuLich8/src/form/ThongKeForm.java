package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.ThongKe;
/**
 * ThongKeForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThongKeForm extends ActionForm{
	private String tenTour;
	private int soLuongDat;
	private String thang;
	private String doanhThu;
	private String queQuan;
	private String soLuongKhach;
	private String ngayBatDau;
	private String ngayKetThuc;
	private String xem;
	private ArrayList<ThongKe> listDoanhThu;
	private ArrayList<ThongKe> listSoLuongDat;
	private ArrayList<ThongKe> listDiemKhoiHanh;
	private ArrayList<ThongKe> listSoLuongDatTheoThang;
	
	
	public String getXem() {
		return xem;
	}
	public void setXem(String xem) {
		this.xem = xem;
	}
	public String getNgayBatDau() {
		return ngayBatDau;
	}
	public void setNgayBatDau(String ngayBatDau) {
		this.ngayBatDau = ngayBatDau;
	}
	public String getNgayKetThuc() {
		return ngayKetThuc;
	}
	public void setNgayKetThuc(String ngayKetThuc) {
		this.ngayKetThuc = ngayKetThuc;
	}
	public String getSoLuongKhach() {
		return soLuongKhach;
	}
	public void setSoLuongKhach(String soLuongKhach) {
		this.soLuongKhach = soLuongKhach;
	}
	public ArrayList<ThongKe> getListDiemKhoiHanh() {
		return listDiemKhoiHanh;
	}
	public void setListDiemKhoiHanh(ArrayList<ThongKe> listDiemKhoiHanh) {
		this.listDiemKhoiHanh = listDiemKhoiHanh;
	}
	
	public String getQueQuan() {
		return queQuan;
	}
	public void setQueQuan(String queQuan) {
		this.queQuan = queQuan;
	}
	public String getThang() {
		return thang;
	}
	public void setThang(String thang) {
		this.thang = thang;
	}
	public String getDoanhThu() {
		return doanhThu;
	}
	public void setDoanhThu(String doanhThu) {
		this.doanhThu = doanhThu;
	}
	public ArrayList<ThongKe> getListDoanhThu() {
		return listDoanhThu;
	}
	public void setListDoanhThu(ArrayList<ThongKe> listDoanhThu) {
		this.listDoanhThu = listDoanhThu;
	}
	
	public String getTenTour() {
		return tenTour;
	}
	public void setTenTour(String tenTour) {
		this.tenTour = tenTour;
	}
	public int getSoLuongDat() {
		return soLuongDat;
	}
	public void setSoLuongDat(int soLuongDat) {
		this.soLuongDat = soLuongDat;
	}
	public ArrayList<ThongKe> getListSoLuongDat() {
		return listSoLuongDat;
	}
	public void setListSoLuongDat(ArrayList<ThongKe> listSoLuongDat) {
		this.listSoLuongDat = listSoLuongDat;
	}
	public ArrayList<ThongKe> getListSoLuongDatTheoThang() {
		return listSoLuongDatTheoThang;
	}
	public void setListSoLuongDatTheoThang(ArrayList<ThongKe> listSoLuongDatTheoThang) {
		this.listSoLuongDatTheoThang = listSoLuongDatTheoThang;
	}
	
	
	
	
}
