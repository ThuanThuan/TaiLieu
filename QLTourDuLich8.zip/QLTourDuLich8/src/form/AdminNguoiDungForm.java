package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.TaiKhoan;


/**
 * AdminNguoiDungForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
@SuppressWarnings("serial")
public class AdminNguoiDungForm extends ActionForm {
	private String tenTaiKhoan;
	private ArrayList<TaiKhoan> listThanhVien;
	private String btnXuly;
	private String txtFind;
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	
	public String getTenTaiKhoan() {
		return tenTaiKhoan;
	}
	public void setTenTaiKhoan(String tenTaiKhoan) {
		this.tenTaiKhoan = tenTaiKhoan;
	}
	public ArrayList<TaiKhoan> getListThanhVien() {
		return listThanhVien;
	}
	public void setListThanhVien(ArrayList<TaiKhoan> listThanhVien) {
		int page = Integer.parseInt(this.page);
		int maxSize = listThanhVien==null?0:listThanhVien.size();
		int max = maxSize%10>0?maxSize/10+1:maxSize/10;
		this.maxPage = max + "";
		if(page==1) this.prev = null;
		if(page==max) this.next = null;
		if(page>1) this.prev = page-1+"";
		if(page<max) this.next = page+1+"";
		int index = (page-1)*10;
		int j=0;
		if(page<=max && maxSize>0) {
			this.listThanhVien = new ArrayList<TaiKhoan>();
			for(;index<maxSize && j<10; j++, index++){
				this.listThanhVien.add(listThanhVien.get(index));
			}
		} else {
			this.listThanhVien = null;
		}
	}
	public String getBtnXuly() {
		return btnXuly;
	}
	public void setBtnXuly(String btnXuly) {
		this.btnXuly = btnXuly;
	}
	public String getTxtFind() {
		return txtFind;
	}
	public void setTxtFind(String txtFind) {
		this.txtFind = txtFind;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	public String getResultOk() {
		return resultOk;
	}
	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}
	public String getResultError() {
		return resultError;
	}
	public void setResultError(String resultError) {
		this.resultError = resultError;
	}
	
}
