package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;

import model.bean.DanhMuc;
/**
 * ThemMoiBaiVietForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemMoiBaiVietForm extends ActionForm{
	private int maBaiViet;
	private int maDanhMuc;
	private String tenDanhMuc;
	private String textTieuDeBaiViet;
	private ArrayList<DanhMuc> listDanhMuc;
	private String textMoTa;
	private String textDiaChi;
	private String textEditor;
	private String submit="";
	FormFile file;
	FormFile file1;
	FormFile file2;
	public FormFile getFile1() {
		return file1;
	}
	public void setFile1(FormFile file1) {
		this.file1 = file1;
	}
	public FormFile getFile2() {
		return file2;
	}
	public void setFile2(FormFile file2) {
		this.file2 = file2;
	}
	public FormFile getFile() {
		return file;
	}
	public void setFile(FormFile file) {
		this.file = file;
	}
	
	public int getMaBaiViet() {
		return maBaiViet;
	}
	public void setMaBaiViet(int maBaiViet) {
		this.maBaiViet = maBaiViet;
	}
	public int getMaDanhMuc() {
		return maDanhMuc;
	}
	public void setMaDanhMuc(int maDanhMuc) {
		this.maDanhMuc = maDanhMuc;
	}
	public String getTenDanhMuc() {
		return tenDanhMuc;
	}
	public void setTenDanhMuc(String tenDanhMuc) {
		this.tenDanhMuc = tenDanhMuc;
	}
	public String getTextTieuDeBaiViet() {
		return textTieuDeBaiViet;
	}
	public void setTextTieuDeBaiViet(String textTieuDeBaiViet) {
		this.textTieuDeBaiViet = textTieuDeBaiViet;
	}
	public ArrayList<DanhMuc> getListDanhMuc() {
		return listDanhMuc;
	}
	public void setListDanhMuc(ArrayList<DanhMuc> listDanhMuc) {
		this.listDanhMuc = listDanhMuc;
	}
	public String getTextMoTa() {
		return textMoTa;
	}
	public void setTextMoTa(String textMoTa) {
		this.textMoTa = textMoTa;
	}
	public String getTextDiaChi() {
		return textDiaChi;
	}
	public void setTextDiaChi(String textDiaChi) {
		this.textDiaChi = textDiaChi;
	}
	public String getTextEditor() {
		return textEditor;
	}
	public void setTextEditor(String textEditor) {
		this.textEditor = textEditor;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	
	
	
}
