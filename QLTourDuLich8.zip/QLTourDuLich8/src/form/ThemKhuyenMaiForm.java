package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.KhuyenMai;
/**
 * ThemKhuyenMaiForm.java
 *
 * Version 1.0
 *
 * Date: 20-03-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-03-2017        	DatDN          Create
 */
public class ThemKhuyenMaiForm extends ActionForm {
	private ArrayList<KhuyenMai> listKhuyenMai;
	private String btnXuly;
	private String txtFind;
	private String page = "1";
	private String maxPage = "1";
	private String next = "1";
	private String prev = "1";
	private String resultOk;
	private String resultError;
	private String submit;
	private String tenKhuyenMai;
	private int maKhuyenMai;
	private String hinhThucKhuyenMai;
	public ArrayList<KhuyenMai> getListKhuyenMai() {
		return listKhuyenMai;
	}
	public void setListKhuyenMai(ArrayList<KhuyenMai> listKhuyenMai) {
		this.listKhuyenMai = listKhuyenMai;
	}
	public String getBtnXuly() {
		return btnXuly;
	}
	public void setBtnXuly(String btnXuly) {
		this.btnXuly = btnXuly;
	}
	public String getTxtFind() {
		return txtFind;
	}
	public void setTxtFind(String txtFind) {
		this.txtFind = txtFind;
	}
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getMaxPage() {
		return maxPage;
	}
	public void setMaxPage(String maxPage) {
		this.maxPage = maxPage;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	public String getResultOk() {
		return resultOk;
	}
	public void setResultOk(String resultOk) {
		this.resultOk = resultOk;
	}
	public String getResultError() {
		return resultError;
	}
	public void setResultError(String resultError) {
		this.resultError = resultError;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getTenKhuyenMai() {
		return tenKhuyenMai;
	}
	public void setTenKhuyenMai(String tenKhuyenMai) {
		this.tenKhuyenMai = tenKhuyenMai;
	}
	
	public int getMaKhuyenMai() {
		return maKhuyenMai;
	}
	public void setMaKhuyenMai(int maKhuyenMai) {
		this.maKhuyenMai = maKhuyenMai;
	}
	public String getHinhThucKhuyenMai() {
		return hinhThucKhuyenMai;
	}
	public void setHinhThucKhuyenMai(String hinhThucKhuyenMai) {
		this.hinhThucKhuyenMai = hinhThucKhuyenMai;
	}
	
}
