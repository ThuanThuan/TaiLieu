package model.bean;

/**
 * Khoa.java
 *
 * Version 1.0
 *
 * Date: Jan 19, 2015
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * Jan 19, 2015        		DaiLV2          Create
 */

public class Khoa {
	private String maKhoa;
	private String tenKhoa;
	
	public String getMaKhoa() {
		return maKhoa;
	}
	public void setMaKhoa(String maKhoa) {
		this.maKhoa = maKhoa;
	}
	public String getTenKhoa() {
		return tenKhoa;
	}
	public void setTenKhoa(String tenKhoa) {
		this.tenKhoa = tenKhoa;
	}
	
}

