package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.beans.Sach;
import model.bo.TimKiemSachBO;

/**
 * Servlet implementation class TimKiemSachServlet
 */
public class TimKiemSachServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TimKiemSachBO timKiemSachBO = new TimKiemSachBO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TimKiemSachServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String timKiem = request.getParameter("timKiem");
		if ("".equals(timKiem)) {
			
		} else {
			ArrayList<Sach> listSach = timKiemSachBO.timKiemSach(timKiem);
			request.setAttribute("listSach", listSach);
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
	}

}
