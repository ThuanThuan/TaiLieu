package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.Common;
import model.beans.Sach;
import model.bo.CheckLoginBO;
import model.bo.ListSachBO;

/**
 * Servlet implementation class LoginServlet
 */

public class CheckLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CheckLoginBO checkLoginBO = new CheckLoginBO();
	private ListSachBO listSachBO = new ListSachBO();
	int first = 0, last = 0, pages = 1;
	int total = 0, loop = 0, num = 0;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CheckLoginServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("pages") != null)
			pages = (int) Integer.parseInt(request.getParameter("pages"));
		pagination();
		ArrayList<Sach> arr = listSachBO.listSach(first, last);
		request.setAttribute("totalPages", loop);
		request.setAttribute("listSach", arr);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("pages") != null)
			pages = (int) Integer.parseInt(request.getParameter("pages"));
		pagination();
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		if ("".equals(userName) || "".equals(password)) {
			request.setAttribute("error", "Username or password couldn't be empty !");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
		} else if (checkLoginBO.isValidAccount(userName, password)) {
			request.setAttribute("totalPages", loop);

			HttpSession session = request.getSession();
			session.setAttribute("userName", userName);
			ArrayList<Sach> arr = listSachBO.listSach(first, last);
			request.setAttribute("listSach", arr);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response);
		} else {
			request.setAttribute("error", "Username or password incorrect !");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
		}
	}

	public void pagination() {
		total = listSachBO.countRowsSach();
		if (total <= 5) {
			first = 0;
			last = total;
		} else {
			first = (pages - 1) * 5;
			last = 5;
		}
		if ((total / 5) % 2 == 0) {
			num = total / 5;
		} else {
			num = (total + 1) / 5;
		}
		// Nếu total lẻ thêm 1
		if (total % 2 != 0) {
			loop = (total / 5) + 1;
		} else {
			// Nếu total chẵn nhỏ hơn fullpage và # fullPage thì thêm 1
			if (total < (num * 5) + 5 && total != num * 5) {
				loop = (total / 5) + 1;
			} else {
				// Nếu bằng fullPage thì không thêm
				loop = (total / 5);
			}
		}
	}
}
