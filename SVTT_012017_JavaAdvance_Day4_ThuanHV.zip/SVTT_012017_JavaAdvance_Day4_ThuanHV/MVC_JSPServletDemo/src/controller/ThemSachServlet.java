package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.ir.RuntimeNode.Request;
import model.beans.Sach;
import model.bo.ListSachBO;
import model.bo.ThemSachBO;
import model.dao.DataAccess;

/**
 * Servlet implementation class SachServlet
 */
public class ThemSachServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ThemSachBO themSachBO = new ThemSachBO();
	private ListSachBO listSachBO = new ListSachBO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ThemSachServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("actionSach", "ThemSachServlet");
		request.setAttribute("suasach", false);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/sach.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String maSach = request.getParameter("maSach");
		String tenSach = request.getParameter("tenSach");
		String tacGia = request.getParameter("tacGia");
		int soLuong = Integer.parseInt(request.getParameter("soLuong"));
		float donGia = Float.parseFloat(request.getParameter("donGia"));
		if ("".equals(maSach) || "".equals(tenSach) || "".equals(tacGia) || "".equals(soLuong + "")
				|| "".equals(donGia + "")) {
		} else {
			Sach s = new Sach(maSach, tenSach, tacGia, donGia, soLuong);
			try {
				themSachBO.themSach(s);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("listSach", listSachBO.listSach(0, 5));
		RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}

}
