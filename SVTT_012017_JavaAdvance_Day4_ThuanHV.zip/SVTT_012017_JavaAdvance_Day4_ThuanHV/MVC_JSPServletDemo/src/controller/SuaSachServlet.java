package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.beans.Sach;
import model.bo.ListSachBO;
import model.bo.SuaSachBO;
import model.dao.DataAccess;

/**
 * Servlet implementation class SuaSachServlet
 */
public class SuaSachServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SuaSachBO suaSachBO = new SuaSachBO();
	private ListSachBO listSachBO = new ListSachBO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SuaSachServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("suasach", true);
		request.setAttribute("actionSach", "SuaSachServlet");
		String maSach = request.getParameter("maSach");
		request.setAttribute("maSach", maSach);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/sach.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String maSach = request.getParameter("maSach");
		String tenSach = request.getParameter("tenSach");
		String tacGia = request.getParameter("tacGia");
		int soLuong = Integer.parseInt(request.getParameter("soLuong"));
		float donGia = Float.parseFloat(request.getParameter("donGia"));
		Sach sach = new Sach(maSach, tenSach, tacGia, donGia, soLuong);
		try {
			suaSachBO.suaSach(sach);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		request.setAttribute("listSach", listSachBO.listSach(0,5));
		RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}

}
