package model.bo;

import java.util.ArrayList;

import model.beans.Sach;
import model.dao.TimKiemSachDAO;

public class TimKiemSachBO {
	TimKiemSachDAO timKiemSachDAO = new TimKiemSachDAO();

	public ArrayList<Sach> timKiemSach(String timKiem) {
		return timKiemSachDAO.timKiemSach(timKiem);
	}

}
