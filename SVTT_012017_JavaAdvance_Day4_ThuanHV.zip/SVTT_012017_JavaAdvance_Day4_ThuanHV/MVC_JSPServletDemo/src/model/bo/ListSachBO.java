package model.bo;

import java.util.ArrayList;

import model.beans.Sach;
import model.dao.ListSachDAO;

public class ListSachBO {
	ListSachDAO listSachDAO = new ListSachDAO();

	public ArrayList<Sach> listSach(int first, int last) {
		return listSachDAO.listSach(first, last);
	}
	public int countRowsSach(){
		return listSachDAO.countRowsSach();
	}

}