package model.bo;

import model.dao.CheckLoginDAO;

public class CheckLoginBO {
	CheckLoginDAO checkLoginDAO = new CheckLoginDAO();

	public boolean isValidAccount(String userName, String password) {
		return checkLoginDAO.isValidAccount(userName, password);
	}

}
