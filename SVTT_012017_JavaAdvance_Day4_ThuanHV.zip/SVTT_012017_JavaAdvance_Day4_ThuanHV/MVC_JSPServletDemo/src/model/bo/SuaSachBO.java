package model.bo;

import java.sql.SQLException;

import model.beans.Sach;
import model.dao.SuaSachDAO;

public class SuaSachBO {
	private SuaSachDAO suaSachDAO = new SuaSachDAO();

	public void suaSach(Sach sach) throws SQLException {
		suaSachDAO.suaSach(sach);
	}

}
