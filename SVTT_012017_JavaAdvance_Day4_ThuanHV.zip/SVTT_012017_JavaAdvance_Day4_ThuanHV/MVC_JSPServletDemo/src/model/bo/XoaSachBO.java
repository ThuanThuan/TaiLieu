package model.bo;

import java.sql.SQLException;

import model.dao.XoaSachDAO;

public class XoaSachBO {
	private XoaSachDAO xoaSachDAO = new XoaSachDAO();

	public void xoaSach(String maSach) throws SQLException {
		xoaSachDAO.xoaSach(maSach);
	}

}
