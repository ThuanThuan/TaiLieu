package model.bo;

import java.sql.SQLException;

import model.beans.Sach;
import model.dao.ThemSachDAO;

public class ThemSachBO {
	ThemSachDAO themSachDAO = new ThemSachDAO();

	public void themSach(Sach s) throws SQLException {
		themSachDAO.themSach(s);
	}
}
