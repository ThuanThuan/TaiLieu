package model.dao;

import java.sql.SQLException;

public class XoaSachDAO {
	DataAccess da = new DataAccess();

	public void xoaSach(String maSach) throws SQLException {
		da.xoaSach(maSach);
	}

}
