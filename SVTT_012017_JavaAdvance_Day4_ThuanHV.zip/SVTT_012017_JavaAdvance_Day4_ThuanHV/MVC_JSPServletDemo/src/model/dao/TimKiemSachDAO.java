package model.dao;

import java.util.ArrayList;

import model.beans.Sach;

public class TimKiemSachDAO {
	DataAccess da = new DataAccess();

	public ArrayList<Sach> timKiemSach(String timKiem) {
		return da.timKiemSach(timKiem);
	}

}
