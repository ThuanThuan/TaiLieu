package model.dao;

import java.sql.SQLException;

import model.beans.Sach;

public class ThemSachDAO {
	DataAccess da = new DataAccess();

	public void themSach(Sach s) throws SQLException {
		da.themSach(s);
	}

}
