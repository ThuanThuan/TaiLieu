package model.dao;

import java.util.ArrayList;

import model.beans.Sach;

public class ListSachDAO {
	DataAccess da = new DataAccess();

	public ArrayList<Sach> listSach(int first, int last) {
		return da.listSach(first, last);
	}

	public int countRowsSach() {
		return da.countRowsSach();
	}

}
