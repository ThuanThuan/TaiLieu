package model.dao;

import java.sql.SQLException;

import model.beans.Sach;

public class SuaSachDAO {
	DataAccess da = new DataAccess();

	public void suaSach(Sach sach) throws SQLException {
		da.suaSach(sach);
	}

}
