package model.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.beans.Sach;
import model.beans.User;

public class DataAccess {
	Connection con = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	CallableStatement callstmt = null;
	ResultSet rs = null;

	public DataAccess() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(
					"jdbc:sqlserver://localhost:1433;databaseName=AssigmentJSPServlet; username=sa; password=12345678");
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Sach> listSach(int first, int last) {
		ArrayList<Sach> arr = new ArrayList<>();
		try {
			String sql = "select * from sach order by masach offset ? rows fetch next ? rows only";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, first);
			pstmt.setInt(2, last);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Sach s = new Sach();
				s.setMaSach(rs.getString("masach"));
				s.setTenSach(rs.getString("tensach"));
				s.setDonGia(rs.getFloat("dongia"));
				s.setSoLuong(rs.getInt("soluong"));
				s.setTacGia(rs.getString("tacgia"));
				arr.add(s);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return arr;
	}

	public void xoaSach(String maSach) throws SQLException {
		String sql = "delete from sach where masach = ?";
		try {
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, maSach);
			pstmt.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		}
		con.setAutoCommit(true);
	}

	public boolean isValidAccount(String userName, String password) {
		try {
			String sql = "select username,password from nguoidung where username= ? and password = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			return rs.next();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return true;
	}

	public void themSach(Sach sach) throws SQLException {
		String sql = "insert into sach(masach,tensach,tacgia,dongia,soluong) values(?,?,?,?,?)";
		try {
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, sach.getMaSach());
			pstmt.setString(2, sach.getTenSach());
			pstmt.setString(3, sach.getTacGia());
			pstmt.setFloat(4, sach.getDonGia());
			pstmt.setInt(5, sach.getSoLuong());
			pstmt.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		}
		con.setAutoCommit(true);
	}

	public void suaSach(Sach sach) throws SQLException {
		String sql = "update sach set tensach = ? ,tacgia = ?, dongia = ? ,soluong = ? where masach = ?";
		try {
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, sach.getTenSach());
			pstmt.setString(2, sach.getTacGia());
			pstmt.setFloat(3, sach.getDonGia());
			pstmt.setInt(4, sach.getSoLuong());
			pstmt.setString(5, sach.getMaSach());
			pstmt.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			con.rollback();
		}
		con.setAutoCommit(true);
	}

	public ArrayList<Sach> timKiemSach(String timKiem) {
		ArrayList<Sach> arr = new ArrayList<>();
		try {
			String sql = "select * from sach where maSach like ? or tenSach like ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + timKiem + "%");
			pstmt.setString(2, "%" + timKiem + "%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Sach s = new Sach();
				s.setMaSach(rs.getString("masach"));
				s.setTenSach(rs.getString("tensach"));
				s.setTacGia(rs.getString("tacgia"));
				s.setSoLuong(rs.getInt("soluong"));
				s.setDonGia(rs.getFloat("dongia"));
				arr.add(s);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return arr;
	}

	public int countRowsSach() {
		int count = 0;
		try {
			String sql = "select count(masach) from sach";
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return count;
	}

}