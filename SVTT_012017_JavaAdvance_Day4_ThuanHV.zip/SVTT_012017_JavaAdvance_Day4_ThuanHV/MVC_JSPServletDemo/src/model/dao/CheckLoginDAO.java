package model.dao;

public class CheckLoginDAO {
	DataAccess da = new DataAccess();

	public boolean isValidAccount(String userName, String password) {
		return da.isValidAccount(userName, password);
	}

}
